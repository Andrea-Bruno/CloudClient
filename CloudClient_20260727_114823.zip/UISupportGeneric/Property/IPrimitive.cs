﻿using System.Xml.Serialization;

namespace UISupportGeneric.Property
{
    /// <summary>
    /// Interface for custom properties managed by UI generator support
    /// </summary>
    internal interface IPrimitive
    {
        /// <summary>
        /// Method to set the value of an object from a value of type string
        /// </summary>
        /// <param name="value"></param>
        [XmlIgnore]
        string FromString { set; }


        //void FromString(string? value);


    }
}
