﻿using System.Globalization;
using System.Text;
using System.Xml.Serialization;

namespace UISupportGeneric.Property
{

    /// <summary>
    /// This custom property represents a color. Inserted in a project, it allows you to select and edit a color (for graphic purposes)
    /// </summary>
    public class Color : IPrimitive
    {
        /// <summary>
        /// Initializer
        /// </summary>
        public Color() { }

        /// <summary>
        /// Initializer
        /// </summary>
        /// <param name="Base">Derive the color from System.Drawing.Color</param>
        /// <returns>Instance of this object</returns>
        public Color(System.Drawing.Color color) { Base = color; OnChange?.Invoke(this, EventArgs.Empty); }

        /// <summary>
        /// Initialize the color from System.Drawing.Color
        /// </summary>
        /// <param name="hex"></param>
        public Color(string hex) { Hex = hex; }

        /// <summary>
        /// Event that is triggered when the color represented by this object changes (during editing for example)
        /// </summary>
        public event EventHandler OnChange;

        /// <summary>
        /// Use this method to set the color using a hexadecimal value in string
        /// </summary>
        /// <value></value>
        public string FromString { set => Hex = value; }

        /// <summary>
        /// Color converted to string 
        /// </summary>
        /// <returns></returns>
        public override string? ToString()
        {
            return "#" + ToHex(true);
        }

        /// <summary>
        /// Use this method to set the color using a hexadecimal value in string
        /// </summary>
        /// <param name="removeTransparency">Exclude transparency if true</param>
        /// <returns></returns>
        public string ToHex(bool removeTransparency = false)
        {
            return ((uint)Base.ToArgb() & (removeTransparency ? 0x00ffffff : 0xffffffff)).ToString("x6");
        }
        [XmlIgnore]
        public System.Drawing.Color Base;

        /// <summary>
        /// Hexadecimal value of the RGB color representation
        /// </summary>
        /// <value>Hexadecimal RGB</value>
        public string? Hex
        {
            get => ToHex();
            set
            {
                try
                {
                    var a = (uint)Base.ToArgb() & 0xff000000; // preserve opacity value (a);
                    var hex = RemoveNonHexChar(value) ?? "0";
                    var val = uint.Parse(hex, NumberStyles.HexNumber);
                    if ((val & 0xff000000) == 0)
                        val |= a; // preserve opacity value (a)
                    Base = System.Drawing.Color.FromArgb((int)val);
                    OnChange?.Invoke(this, EventArgs.Empty);
                }
                catch { }
            }
        }

        /// <summary>
        /// Remove a certain shade from the represented color
        /// </summary>
        /// <param name="color">Color to subtract</param>
        /// <returns></returns>
        public Color Subtract(System.Drawing.Color color)
        {
            return new Color(System.Drawing.Color.FromArgb(Base.A, FixC(Base.R - color.R), FixC(Base.G - color.G), FixC(Base.B - color.B)));
        }

        /// <summary>
        /// Add a certain gradation from the color represented
        /// </summary>
        /// <param name="color">Color to add</param>
        /// <returns></returns>
        public Color Add(System.Drawing.Color color)
        {
            return new Color(System.Drawing.Color.FromArgb(Base.A, FixC(Base.R + color.R), FixC(Base.G + color.G), FixC(Base.B + color.B)));
        }

        /// <summary>
        /// Obtain a gradation of this color, lighter or darker, depending on the color variation coefficient
        /// </summary>
        /// <param name="coefficient">color variation coefficient (from 0 to 2, values above one lighten, those below one darken)</param>
        /// <returns></returns>
        public Color Gradation(double coefficient)
        {
            return new Color(System.Drawing.Color.FromArgb(Base.A, XC(Base.R, coefficient), XC(Base.G, coefficient), XC(Base.B, coefficient)));
        }
        private int XC(int n, double c) { var r = (int)(n * c); return FixC(r); }
        private int FixC(int c)
        {
            c = c < 0 ? 0 : c; c = c > 255 ? 255 : c;
            return c;
        }
        private static string? RemoveNonHexChar(string? hex)
        {
            if (hex == null)
                return null;
            var sb = new StringBuilder();
            foreach (var c in hex)
            {
                var l = char.ToLower(c);
                if ((l >= 48 && l <= 57) || (l >= 97 && l <= 102))
                    sb.Append(l);
            }
            return sb.ToString();
        }
    }

}
