﻿namespace System
{
    /// <summary>
    /// Attribute that allows you to set a range of valid values ​​for numeric types
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, Inherited = false, AllowMultiple = false)]  
    public class RangeAttribute : Attribute
    {
        /// <summary>
        /// Gets or sets the minimum value allowed for the property.
        /// </summary>
        public double Min { get; }

        /// <summary>
        /// Gets or sets the maximum value allowed for the property.
        /// </summary>
        public double Max { get; }

        /// <summary>
        /// Gets or sets the step value for the property.
        /// </summary>
        public double Step { get; }

        /// <summary>
        /// Initializes a new instance of the RangeAttribute class.
        /// </summary>
        /// <param name="min">The minimum value allowed.</param>
        /// <param name="max">The maximum value allowed.</param>
        /// <param name="step">The step value allowed.</param>
        public RangeAttribute(double min, double max, double step)
        {
            Min = min;
            Max = max;
            Step = step;
        }
    }

}
