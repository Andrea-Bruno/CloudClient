﻿namespace System
{
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    public class AsQueryStringAttribute : Attribute
    {

        public AsQueryStringAttribute()
        {
        }
    }
}
