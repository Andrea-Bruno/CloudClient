﻿namespace System
{
    /// <summary>
    /// Email attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class EmailAttribute : Attribute
    {
        public static string Regex = @"^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}$";
        public EmailAttribute() { }
    }

    /// <summary>
    /// International phone number attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class InternationalPhoneAttribute : Attribute
    {
        public static string Regex = @"^\+?[0-9]{10,15}$";
        public InternationalPhoneAttribute() { }
    }

    /// <summary>
    /// ZIP code attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class ZipCodeAttribute : Attribute
    {
        public static string Regex = @"^[0-9]{5}$";
        public ZipCodeAttribute() { }
    }

    /// <summary>
    /// Alphanumeric postal code attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class AlphanumericPostalCodeAttribute : Attribute
    {
        public static string Regex = @"^[A-Z0-9]{2,4}\s?[A-Z0-9]{3}$";
        public AlphanumericPostalCodeAttribute() { }
    }

    /// <summary>
    /// URL attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class UrlAttribute : Attribute
    {
        public static string Regex = @"^https?:\/\/(www\.)?[\w-]+\.[\w-]+(\/[\w-]*)*$";
        public UrlAttribute() { }
    }

    /// <summary>
    /// Strong password attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class StrongPasswordAttribute : Attribute
    {
        public static string Regex = @"^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,}$";
        public StrongPasswordAttribute() { }
    }

    /// <summary>
    /// Letters only attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class LettersOnlyAttribute : Attribute
    {
        public static string Regex = @"^[a-zA-Z]+$";
        public LettersOnlyAttribute() { }
    }

    /// <summary>
    /// Numbers only attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class NumbersOnlyAttribute : Attribute
    {
        public static string Regex = @"^[0-9]+$";
        public NumbersOnlyAttribute() { }
    }

    /// <summary>
    /// Alphanumeric attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class AlphanumericAttribute : Attribute
    {
        public static string Regex = @"^[a-zA-Z0-9]+$";
        public AlphanumericAttribute() { }
    }

    /// <summary>
    /// Date (DD/MM/YYYY) attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class DateAttribute : Attribute
    {
        public static string Regex = @"^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$";
        public DateAttribute() { }
    }

    /// <summary>
    /// IPv4 address attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class IPv4Attribute : Attribute
    {
        public static string Regex = @"^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";
        public IPv4Attribute() { }
    }

    /// <summary>
    /// IPv6 address attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class IPv6Attribute : Attribute
    {
        public static string Regex = @"^([0-9a-fA-F]{1,4}:){7}([0-9a-fA-F]{1,4}|:)$";
        public IPv6Attribute() { }
    }

    /// <summary>
    /// Credit card number attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class CreditCardAttribute : Attribute
    {
        public static string Regex = @"^\d{16}$";
        public CreditCardAttribute() { }
    }

    /// <summary>
    /// Proper name attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class ProperNameAttribute : Attribute
    {
        public static string Regex = @"^[A-Z][a-z]+$";
        public ProperNameAttribute() { }
    }

    /// <summary>
    /// Positive decimal number attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class PositiveDecimalAttribute : Attribute
    {
        public static string Regex = @"^[0-9]*\.?[0-9]+$";
        public PositiveDecimalAttribute() { }
    }

    /// <summary>
    /// File name attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class FileNameAttribute : Attribute
    {
        public static string Regex = @"^[^<>:;,?\"" *|/]+$";
        public FileNameAttribute() { }
    }

    /// <summary>
    /// Italian tax code attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class ItalianTaxCodeAttribute : Attribute
    {
        public static string Regex = @"^[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]$";
        public ItalianTaxCodeAttribute() { }
    }

    /// <summary>
    /// Italian license plate attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class ItalianLicensePlateAttribute : Attribute
    {
        public static string Regex = @"^[A-Z]{2}\d{3}[A-Z]{2}$";
        public ItalianLicensePlateAttribute() { }
    }

    /// <summary>
    /// Time (24-hour format) attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class Time24HourFormatAttribute : Attribute
    {
        public static string Regex = @"^([01]?[0-9]|2[0-3]):[0-5][0-9]$";
        public Time24HourFormatAttribute() { }
    }

    /// <summary>
    /// ISBN-10 attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class ISBN10Attribute : Attribute
    {
        public static string Regex = @"^(\d{9}[\dX])$";
        public ISBN10Attribute() { }
    }

    /// <summary>
    /// ISBN-13 attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class ISBN13Attribute : Attribute
    {
        public static string Regex = @"^(978|979)\d{9}[\dX]$";
        public ISBN13Attribute() { }
    }

    /// <summary>
    /// Hex color code attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class HexColorCodeAttribute : Attribute
    {
        public static string Regex = @"^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$";
        public HexColorCodeAttribute() { }
    }

    /// <summary>
    /// MAC address attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class MACAddressAttribute : Attribute
    {
        public static string Regex = @"^([0-9A-Fa-f]{2}:){5}([0-9A-Fa-f]{2})$";
        public MACAddressAttribute() { }
    }

    /// <summary>
    /// US Social Security Number (SSN) attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class USSocialSecurityNumberAttribute : Attribute
    {
        public static string Regex = @"^\d{3}-\d{2}-\d{4}$";
        public USSocialSecurityNumberAttribute() { }
    }

    /// <summary>
    /// US phone number attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class USPhoneNumberAttribute : Attribute
    {
        public static string Regex = @"^\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$";
        public USPhoneNumberAttribute() { }
    }

    /// <summary>
    /// Currency format attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class CurrencyFormatAttribute : Attribute
    {
        public static string Regex = @"^\$?\d+(,\d{3})*(\.\d{2})?$";
        public CurrencyFormatAttribute() { }
    }

    /// <summary>
    /// Latin letters and spaces attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class LatinLettersAndSpacesAttribute : Attribute
    {
        public static string Regex = @"^[A-Za-z\s]+$";
        public LatinLettersAndSpacesAttribute() { }
    }

    /// <summary>
    /// HTML tag attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class HTMLTagAttribute : Attribute
    {
        public static string Regex = @"^<([a-z]+)([^<]+)*(?:>(.*)<\/\1>|\s+\/>)$";
        public HTMLTagAttribute() { }
    }

    /// <summary>
    /// Binary number attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class BinaryNumberAttribute : Attribute
    {
        public static string Regex = @"^[01]+$";
        public BinaryNumberAttribute() { }
    }

    /// <summary>
    /// Hexadecimal number attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class HexadecimalNumberAttribute : Attribute
    {
        public static string Regex = @"^[0-9A-Fa-f]+$";
        public HexadecimalNumberAttribute() { }
    }

    /// <summary>
    /// Slug (URL-friendly text) attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class SlugAttribute : Attribute
    {
        public static string Regex = @"^[a-z0-9]+(?:-[a-z0-9]+)*$";
        public SlugAttribute() { }
    }

    /// <summary>
    /// Percentage (0-100%) attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class PercentageAttribute : Attribute
    {
        public static string Regex = @"^100$|^[0-9]{1,2}$";
        public PercentageAttribute() { }
    }

    /// <summary>
    /// UUID attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class UUIDAttribute : Attribute
    {
        public static string Regex = @"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$";
        public UUIDAttribute() { }
    }

    /// <summary>
    /// Non-empty strings attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class NonEmptyStringsAttribute : Attribute
    {
        public static string Regex = @"^\S+$";
        public NonEmptyStringsAttribute() { }
    }

    /// <summary>
    /// Digits with thousands separator attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class DigitsWithThousandsSeparatorAttribute : Attribute
    {
        public static string Regex = @"^(\d{1,3})(,\d{3})*$";
        public DigitsWithThousandsSeparatorAttribute() { }
    }

    /// <summary>
    /// Multilingual text attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class MultilingualTextAttribute : Attribute
    {
        public static string Regex = @"^[\p{L}\s]+$";
        public MultilingualTextAttribute() { }
    }

    /// <summary>
    /// Floating-point number attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class FloatingPointNumberAttribute : Attribute
    {
        public static string Regex = @"^-?\d*\.?\d+$";
        public FloatingPointNumberAttribute() { }
    }

    /// <summary>
    /// Positive integers only attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class PositiveIntegersOnlyAttribute : Attribute
    {
        public static string Regex = @"^\d+$";
        public PositiveIntegersOnlyAttribute() { }
    }

    /// <summary>
    /// Negative integers only attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class NegativeIntegersOnlyAttribute : Attribute
    {
        public static string Regex = @"^-\d+$";
        public NegativeIntegersOnlyAttribute() { }
    }

    /// <summary>
    /// AlphaNumeric with spaces attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class AlphaNumericWithSpacesAttribute : Attribute
    {
        public static string Regex = @"^[a-zA-Z0-9\s]+$";
        public AlphaNumericWithSpacesAttribute() { }
    }

    /// <summary>
    /// Uppercase letters only attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class UppercaseOnlyAttribute : Attribute
    {
        public static string Regex = @"^[A-Z]+$";
        public UppercaseOnlyAttribute() { }
    }

    /// <summary>
    /// Lowercase letters only attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class LowercaseOnlyAttribute : Attribute
    {
        public static string Regex = @"^[a-z]+$";
        public LowercaseOnlyAttribute() { }
    }

    /// <summary>
    /// Floating-point number with 2 decimal places attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class TwoDecimalFloatingPointAttribute : Attribute
    {
        public static string Regex = @"^\d+\.\d{2}$";
        public TwoDecimalFloatingPointAttribute() { }
    }

    /// <summary>
    /// US ZIP+4 Code attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class USZipPlus4CodeAttribute : Attribute
    {
        public static string Regex = @"^\d{5}-\d{4}$";
        public USZipPlus4CodeAttribute() { }
    }

    /// <summary>
    /// File path attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class FilePathAttribute : Attribute
    {
        public static string Regex = @"^[a-zA-Z]:\\(?:[^\\/:*?""<>|\r\n]+\\)*[^\\/:*?""<>|\r\n]*$";
        public FilePathAttribute() { }
    }

    /// <summary>
    /// HTML comment attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class HTMLCommentAttribute : Attribute
    {
        public static string Regex = @"^<!--(.*?)-->$";
        public HTMLCommentAttribute() { }
    }

    /// <summary>
    /// Credit card expiration date (MM/YY) attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class CreditCardExpirationDateAttribute : Attribute
    {
        public static string Regex = @"^(0[1-9]|1[0-2])\/\d{2}$";
        public CreditCardExpirationDateAttribute() { }
    }

    /// <summary>
    /// Canadian postal code attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class CanadianPostalCodeAttribute : Attribute
    {
        public static string Regex = @"^[A-Za-z]\d[A-Za-z] ?\d[A-Za-z]\d$";
        public CanadianPostalCodeAttribute() { }
    }

    /// <summary>
    /// HTML color attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class HTMLColorAttribute : Attribute
    {
        public static string Regex = @"^#[A-Fa-f0-9]{6}$";
        public HTMLColorAttribute() { }
    }

    /// <summary>
    /// European date format (YYYY-MM-DD) attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class EuropeanDateAttribute : Attribute
    {
        public static string Regex = @"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$";
        public EuropeanDateAttribute() { }
    }

    /// <summary>
    /// Base64 string attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class Base64StringAttribute : Attribute
    {
        public static string Regex = @"^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$";
        public Base64StringAttribute() { }
    }

    /// <summary>
    /// YouTube video ID attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class YouTubeVideoIDAttribute : Attribute
    {
        public static string Regex = @"^[a-zA-Z0-9_-]{11}$";
        public YouTubeVideoIDAttribute() { }
    }

    /// <summary>
    /// IPv4 CIDR block attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class IPv4CIDRBlockAttribute : Attribute
    {
        public static string Regex = @"^(([0-9]{1,3}\.){3}[0-9]{1,3})\/([0-9]|[12][0-9]|3[0-2])$";
        public IPv4CIDRBlockAttribute() { }
    }

    /// <summary>
    /// Twitter username attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class TwitterUsernameAttribute : Attribute
    {
        public static string Regex = @"^@[A-Za-z0-9_]{1,15}$";
        public TwitterUsernameAttribute() { }
    }

    /// <summary>
    /// Instagram username attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class InstagramUsernameAttribute : Attribute
    {
        public static string Regex = @"^[A-Za-z0-9_.]{1,30}$";
        public InstagramUsernameAttribute() { }
    }

    /// <summary>
    /// LinkedIn profile URL attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class LinkedInProfileURLAttribute : Attribute
    {
        public static string Regex = @"^https?:\/\/(www\.)?linkedin\.com\/in\/[A-Za-z0-9-]+\/?$";
        public LinkedInProfileURLAttribute() { }
    }

    /// <summary>
    /// UUID with curly braces attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class UUIDWithBracesAttribute : Attribute
    {
        public static string Regex = @"^\{[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\}$";
        public UUIDWithBracesAttribute() { }
    }
}
