﻿using System.Reflection;
using static UISupportGeneric.Util;
namespace UISupportGeneric.UI
{
    /// <summary>
    /// Class used by the graphical interface, to represent a property of a class and modify its value
    /// </summary>
    public class ParametersUISupport : EditableUIMember
    {
        /// <summary>
        /// Create an instance of the class
        /// </summary>
        /// <param name="parameter">The property to be represented by the graphical interface</param>
        /// <param name="classInfo">Reference to the info class for this property</param>
        internal ParametersUISupport(ParameterInfo parameter, ClassInfo classInfo) : base(parameter.ParameterType, parameter.Name ?? "parameter", GetParameterDescription(out var order, parameter, classInfo.Xml, out _), order, classInfo, false, parameter.IsOut)
        {
            //base.Type = parameter.ParameterType;
            GetValue = () => FieldValue;
            SetValue = value => FieldValue = value;
            if (parameter.HasDefaultValue && parameter.DefaultValue != DBNull.Value)
            {
                FieldValue = parameter.DefaultValue;
            }
            else if (Type.IsValueType)
            {
                FieldValue = Activator.CreateInstance(Type);
            }
        }
        private object? FieldValue;
    }
}
