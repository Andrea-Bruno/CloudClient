﻿using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Xml.Linq;
using static UISupportGeneric.Util;

namespace UISupportGeneric.UI
{

    /// <summary>
    /// Gets a representation of a class, for a user interface. A graphical interface, through the instance of this element, can easily create a visual instance of an object so that it can be visualized and edited.
    /// </summary>
    public class ClassInfo : Element
    {

        /// <summary>
        /// Create an instance of the component
        /// </summary>
        /// <param name="staticClass">Object that you want to analyze</param>
        /// <param name="interfaceType">Specifies how the user interface will be used</param>
        /// <param name="onSave">You can specify an action to save the component. This action will be called automatically when the object needs to be saved</param>
        /// <param name="level">Node counter in the object branch</param>
        /// <param name="parent">Any class that contains this object, used to go to the root</param>
        internal ClassInfo(Type staticClass, InterfaceType interfaceType = InterfaceType.AutoSave, SaveAction? onSave = null, int level = 0, ClassInfo? parent = null) : base(staticClass.Name)
        {
            //if (staticClass.IsAbstract && staticClass.IsSealed)
            Initialize(staticClass, false, interfaceType, level, parent, onSave);
            Parent = parent;
            //else
            //    throw (new Exception("The class to use is not static: Pass an instance of this class to initialize, or pass a static class."));
        }
        /// <summary>
        /// Create an instance of the component
        /// </summary>
        /// <param name="classInstance">Object that you want to analyze</param>
        /// <param name="interfaceType">Specifies how the user interface will be used</param>
        /// <param name="onSave">You can specify an action to save the component. This action will be called automatically when the object needs to be saved</param>
        /// <param name="level">Node counter in the object branch</param>
        /// <param name="parent">Any class that contains this object, used to go to the root</param>
        internal ClassInfo(object classInstance, InterfaceType interfaceType = InterfaceType.RealTimeValidationNoSubmitButton, SaveAction? onSave = null, int level = 0, ClassInfo? parent = null) : base(classInstance.GetType().Name)
        {
            ClassInstance = classInstance;
            Initialize(ClassInstance.GetType(), false, interfaceType, level, parent, onSave);
        }
        private ClassInfo(Func<object?> getValue, MemberInfo member, bool isReadOnly, InterfaceType interfaceType, int level, SaveAction? onSave = null, ClassInfo? parent = null) : base(((PropertyInfo)member).PropertyType.Name)
        {
            GetValue = getValue;
            Initialize(((PropertyInfo)member).PropertyType, isReadOnly, interfaceType, level, parent, onSave);
            Description = GetMemberDescription(out Order, member, Xml, out _);
        }

        /// <summary>
        /// A unique identifier (ID) associated with this object
        /// </summary>
        public Guid Id { get; private set; }

        /// <summary>
        /// Parent class Id
        /// </summary>
        public Guid MemberOfId { get; private set; }

        private static readonly Dictionary<int, WeakReference<ClassInfo>> Instances = [];

        /// <summary>
        /// Returns the ClassInfo object with the id specified in the request
        /// </summary>
        /// <param name="InstanceId">ClassInfo Id</param>
        /// <param name="value">Returns the ClassInfo instance from request if found</param>
        /// <returns>True if the item was found</returns>
        public static bool TryGetInstance(int InstanceId, out ClassInfo? value)
        {
            lock (Instances)
            {
                if (Instances.TryGetValue(InstanceId, out var weakReference))
                {
                    if (weakReference.TryGetTarget(out value))
                    {
                        if (value.IsExpired)
                        {
                            Instances.Remove(InstanceId);
                            value = null;
                            return false;
                        }
                        return true;
                    }
                }
                value = null;
                return false;
            }
        }

        private int? InstanceId => IsStatic ? Type.GetHashCode() : ClassInstance?.GetHashCode();

        private static void CleanUpInstances()
        {
            var keysToRemove = new List<int>();
            lock (Instances)
            {
                foreach (var kvp in Instances)
                {
                    if (!kvp.Value.TryGetTarget(out var instance) || (instance != null && instance.IsExpired))
                        keysToRemove.Add(kvp.Key);
                }
                foreach (var key in keysToRemove)
                    Instances.Remove(key);
            }
        }

        /// <summary>
        /// Value that is set by the client application if it uses sessions, to indicate that this object is no longer needed and all references to it should be deleted so that garbage collection can delete it.
        /// </summary>
        public bool IsExpired
        {
            get => _isExpired; set
            {
                if (value == false)
                    throw new Exception("The object cannot be set to not expired, it can only be set to expired.");
                if (IsStatic)
                    throw new Exception("The object cannot be set to expired, it is static!");
                _isExpired = value;
            }
        }
        private bool _isExpired = false;

        private static readonly HashSet<Guid> StaticClassLoaded = [];
        //private WeakReference? MonitoringOnChangeMember;

        /// <summary>
        /// any class that contains this object, used to go to the root
        /// </summary>
        private ClassInfo? Parent;
        /// <summary>
        /// Initialize the class information
        /// </summary>
        /// <param name="type">Type of the class</param>
        /// <param name="isReadOnly">Indicates if the class is read-only</param>
        /// <param name="interfaceType">Specifies how the user interface will be used</param>
        /// <param name="level">Node counter in the object branch</param>
        /// <param name="parent">Any class that contains this object, used to go to the root</param>
        /// <param name="onSave">Action to save the component</param>
        private void Initialize(Type type, bool isReadOnly, InterfaceType interfaceType, int level, ClassInfo? parent, SaveAction? onSave)
        {
            ClassInfo = this;
#if DEBUG
            if ((parent == null && level != 0) || parent != null && level == 0)
                Debugger.Break(); // Inconsistency (code must be verified)
#endif
            Type = type;
            Parent = parent;
            IsStatic = IsStaticClass(type);

            if (InstanceId != null)
            {
                lock (Instances)
                {
                    Instances.Remove((int)InstanceId);
                    Instances.Add((int)InstanceId, new WeakReference<ClassInfo>(this));
                }
            }
            CleanUpInstances();

            IsReadOnly = isReadOnly;
            if (Level == 0 && interfaceType.HasFlag(InterfaceType.AutoSave) && onSave == null)
            {
                if (IsStatic)
                {
                    //load last save value
                    lock (StaticClassLoaded)
                    {
                        if (!StaticClassLoaded.Contains(type.GUID))
                        {
                            StaticClassLoaded.Add(type.GUID);
                            Load(type);
                        }
                    }
                    //void save(object? classInstance, string? validationErrorReport) => Save(type);
                    onSave = (_, _) => Save(type);
                }
                else
                    throw new Exception("The component was initialized with the auto save setting, but no method was set for saving the class.");
            }

            Level = level;
            OnSave = onSave;
            InterfaceType = interfaceType;
            Id = type.GUID;


            if (type.DeclaringType != null) MemberOfId = type.DeclaringType.GUID;
            if (!InterfaceType.HasFlag(InterfaceType.AutoSave))
            {
                Submit = () =>
                {
                    var sb = new StringBuilder();
                    UpdateAll(sb);
                    return sb.Length == 0 ? null : sb.ToString();
                };
            }
            Xml = GetXmlOfAssembly(type);
            if (Xml != null)
                Description = GetClassDescription(out Order, type, Xml);
            _elements = [];
            // For the static class object edit only static element (Because there is no instance)
            var members = IsStatic ? type.GetMembers(BindingFlags.Static | BindingFlags.Public) : type.GetMembers(BindingFlags.Instance | BindingFlags.Public);
            foreach (var member in members)
            {
                //if (member.Name == "InvoiceIssuedTo")
                //    Debugger.Break();


                if (BaseUISupport.IsSupportedMember(member))
                {
                    if (member is PropertyInfo property)
                    {
                        if (IsReadOnly == false)
                            IsReadOnly = member.GetCustomAttributes(false).OfType<ReadOnlyAttribute>().Any(a => a.IsReadOnly);
                        Type? elementType = null;
                        bool isEnumerable = false;

                        // Check if the property is an array
                        if (property.PropertyType.IsArray)
                        {
                            elementType = property.PropertyType.GetElementType();
                            isEnumerable = true;
                        }
                        // Check if the property implements IEnumerable<>
                        else if (property.PropertyType.GetInterface(typeof(IEnumerable<>).Name) != null)
                        {
                            elementType = property.PropertyType.GetGenericArguments().FirstOrDefault();
                            isEnumerable = true;
                        }
                        // Check if the property implements IEnumerable (non-generic)
                        else if (typeof(System.Collections.IEnumerable).IsAssignableFrom(property.PropertyType))
                        {
                            // For non-generic IEnumerable, we'll use object as the element type
                            elementType = typeof(object);
                            isEnumerable = true;
                        }

                        if (isEnumerable && elementType != null)
                        {
                            //var isReadOnlyMember = member.GetCustomAttributes(false).Any(a => a is ReadOnlyAttribute);
                            bool isEditable = false;
                            var isOnSelect = IsOnSelectTable(property.Name, type, out var onSelecyAction);
                            if (!IsReadOnly && !isOnSelect)
                            {
                                if (IsSupportedType(elementType))
                                {
                                    isEditable = IsEditable(property);
                                }
                                else
                                {
                                    var records = TableUISupport.RecordFields(elementType, false);
                                    isEditable = records.Find(x => x is PropertyInfo property && IsEditable(property) | x is MethodInfo) != null;
                                }
                            }
                            _elements.Add(isEditable ? new ObjectsCollection(property, this, interfaceType, onSave, level + 1) : new TableUISupport(property, this, onSelecyAction));
                        }


                        else if (IsSupportedType(property.PropertyType))

                            _elements.Add(new PropertyUISupport(property, this));
                        else if (level < 4)
                        {
                            object? promise() => ClassInstance == null && !IsStatic ? null : property.GetValue(ClassInstance);
                            var classInfo = new ClassInfo(promise, member, !IsEditable(property), InterfaceType, level + 1, onSave, this);
                            _elements.Add(classInfo);
                        }
                    }
                    else if (member is TypeInfo typeInfo)
                    {
                        if (typeInfo.IsClass)
                        {
                            var classType = typeInfo.UnderlyingSystemType;
                            if (classType != null && IsStaticClass(classType))
                            {
                                var classInfo = new ClassInfo(classType, InterfaceType, onSave = null, level + 1, this);
                                if (!classInfo.IsEmpty)
                                {
                                    classInfo.Description = GetMemberDescription(out var order, member, Xml, out _);
                                    classInfo.Order = order;
                                    _elements.Add(classInfo);
                                }
                            }
                        }
                    }
                    else if (member is MethodInfo method)
                    {
                        _elements.Add(new MethodUISupport(method, this));
                    }
                }
            }
            _elements.Sort((x, y) => x.Order - y.Order);

            var redirectField = type.GetField(nameof(Event.EventType.Redirect), BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance);
            if (redirectField != null && redirectField.FieldType == typeof(Uri))
            {
                _EventRedirect = new EventRedirect(this, redirectField);
            }
        }

        /// <summary>
        /// Set the value of a field that is marked with the AsQueryString attribute
        /// </summary>
        /// <param name="fieldName">Field name</param>
        /// <param name="value">Value to assign</param>
        public void SetQueryString(string fieldName, string value)
        {
            var type = ClassInstance?.GetType() ?? Type;
            var fieldInfo = type.GetField(fieldName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance);
            if (fieldInfo != null)
            {
                var asQueryString = fieldInfo.GetCustomAttributes(false).Any(a => a is AsQueryStringAttribute);
                if (asQueryString)
                {
                    try
                    {
                        var convertedValue = Convert.ChangeType(value, fieldInfo.FieldType);
                        if (fieldInfo.IsStatic)
                        {
                            fieldInfo.SetValue(null, convertedValue);
                        }
                        else
                        {
                            if (ClassInstance == null)
                            {
                                throw new InvalidOperationException($"Cannot set value for instance field '{fieldName}' because ClassInstance is null.");
                            }
                            fieldInfo.SetValue(ClassInstance, convertedValue);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidOperationException($"Failed to set value for field '{fieldName}'. Expected type: {fieldInfo.FieldType}, provided value: '{value}'.", ex);
                    }
                }
            }
        }

        private EventRedirect _EventRedirect;
        /// <summary>
        /// If set, the rendering engine must redirect the User to the GUI, at the specified Uri. This matches the current GUI with the one corresponding to the URI address.
        /// </summary>
        public Uri? RedirectTo => _EventRedirect?.RedirectTo;

        private bool IsOnSelectTable(string propertyName, Type type, out Action<int>? onSelected)
        {
            foreach (var method in type.GetMethods(BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public))
                if (OnSelectKeywords.Any(Keyword => string.Compare(method.Name, Keyword + propertyName, StringComparison.OrdinalIgnoreCase) == 0 || string.Compare(method.Name, propertyName + Keyword, StringComparison.OrdinalIgnoreCase) == 0))
                {
                    onSelected = (index) =>
                    {
                        try
                        {
                            method.Invoke(ClassInstance, [index]);
                        }
                        catch (Exception) { }
                    };
                    return true;
                }
            onSelected = null;
            return false;
        }

        /// <summary>
        /// Keywords that distinguish a method that is activated when selecting an element from a list (array)
        /// </summary>
        internal readonly string[] OnSelectKeywords = ["OnSelect", "OnSelect_", "_OnSelect", "OnSelected"];

        internal Type Type;

        /// <summary>
        /// The possible base for a filename, concerning the class. It is typically used to associate an md (Markdown) file with the class in order to associate a descriptive document with the class. This is a base for a namefile, so it has no extension.
        /// </summary>
        public string? PathFileBase
        {
            get
            {
                if (Type?.FullName == null)
                    return null;
                var parts = Type.FullName.Split(".");
                parts[0] = ".";
                return string.Join(Path.DirectorySeparatorChar, parts);
            }
        }

        internal object? GetPropertyValue(string propertyName)
        {
            var instance = ClassInstance;
            if (instance != null)
                return GetMemberValue(ClassInstance, propertyName);
            return GetMemberValue(Type, propertyName);
        }

        /// <summary>
        /// Attribute that if True, indicates that the element will be hidden in the GUI
        /// </summary>
        public override bool? Hidden
        {
            get
            {
                var hidden = GetPropertyValue(nameof(Hidden));
                var result = hidden is bool hiddenBool ? hiddenBool : base.Hidden;
                if (_hidden != result)
                {
                    if (_hidden != null)
                        Refresh();
                    _hidden = result;
                }
                return result;
            }
        }

        /// <summary>
        /// Last value 
        /// </summary>
        internal bool? _hidden;

        private static object? GetMemberValue(object? obj, string propertyName)
        {
            if (obj == null || string.IsNullOrEmpty(propertyName))
                return null;
            var type = obj.GetType();
            var propertyInfo = type.GetProperty(propertyName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (propertyInfo != null)
                return propertyInfo.GetValue(obj);
            var fieldInfo = type.GetField(propertyName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (fieldInfo != null)
                return fieldInfo.GetValue(obj);
            return null;
        }

        private static object? GetMemberValue(Type staticType, string memberName)
        {
            // Ensure the provided type is a static class
            if (staticType == null || !staticType.IsClass || !staticType.IsAbstract || !staticType.IsSealed)
                return null;
            // Try to find the member as a property (public or private)
            var propertyInfo = staticType.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (propertyInfo != null)
                return propertyInfo.GetValue(null); // Retrieve the property value
            // Try to find the member as a field (public or private)
            var fieldInfo = staticType.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (fieldInfo != null)
                return fieldInfo.GetValue(null); // Retrieve the field value
            return null;
        }


        /// <summary>
        /// Detect if the element has changes
        /// </summary>
        /// <param name="restrictedToReadOnly">Indicates if the detection is restricted to read-only elements</param>
        /// <param name="propagation">Indicates if the detection should propagate to child elements</param>
        internal void DetectIfElementIsChanges(bool restrictedToReadOnly, bool propagation = false)
        {
            PerformDetectChanges(GetValue, restrictedToReadOnly, IsReadOnly);
            if (!propagation && Parent != null)
            {
                Parent.DetectIfElementIsChanges(restrictedToReadOnly);
            }
            else
            {
                foreach (var element in _elements)
                {
                    if (element is PropertyUISupport property)
                        property.DetectIfElementIsChanges(restrictedToReadOnly);
                    else if (element is ClassInfo obj)
                        obj.DetectIfElementIsChanges(restrictedToReadOnly, true);
                    else if (element is ObjectsCollection collection)
                        collection.DetectIfElementIsChanges(restrictedToReadOnly, true);
                }
            }
        }
        /// <summary>
        /// Specifies how the user interface will be used
        /// </summary>
        public InterfaceType InterfaceType { get; private set; }
        private List<Element> _elements;
        /// <summary>
        /// List of elements that have a visual appearance for the GUI. These can be of type: ClassInfo, PropertyUISupport, Methods
        /// </summary>
        public List<Element> Elements
        {
            get
            {
                if (!IsStatic && ClassInstance == null)
                {
                    return []; // empty list
                }
                MonitoringOnChangeMember.AddReference(this);
                return _elements;
            }
        }

        internal bool Validate(Dictionary<string, string>? errors)
        {
            errors ??= [];
            foreach (var element in Elements)
            {
                if (element is PropertyUISupport property)
                {
                    if (!property.IsReadOnly)
                    {
                        var error = property.GetValidateError();
                        if (error != null)
                        {
                            errors.Add(property.Label, error.ToString());
                        }
                    }
                }
                else if (element is ClassInfo classInfo)
                {
                    classInfo.Validate(errors);
                }
            }
            return errors.Count == 0;
        }

        /// <summary>
        /// True if the class has no elements or sub elements to represent in the UI
        /// </summary>
        internal bool IsEmpty => _elements?.Count == 0;

        internal static bool IsSupportedType(Type type)
        {
            return (type.IsPrimitive || ManagedTypes.Contains(type) || IsCustomType(type) || type.IsEnum || HasCustomToString(type));
        }

        private static bool HasCustomToString(Type type)
        {
            var methods = type?.GetMethods();
            if (methods != null)
                foreach (var method in methods)
                {
                    if (method.Name == "ToString")
                    {
                        var declarationType = method.DeclaringType;
                        if (declarationType?.Name == "System")
                            return true;
                    }
                }
            return false;
        }

        internal static bool IsCustomType(Type type)
        {
            return type.GetProperty("FromString") != null;
        }
        /// <summary>
        /// True if the represented class is static. Static classes cannot have multiple instances and therefore not even multiple user sessions (these are therefore classes shared among all users)
        /// </summary>
        public bool IsStatic { get; private set; }
        internal bool IsReadOnly;
        private static readonly Type[] ManagedTypes = [typeof(char), typeof(string), typeof(Color), typeof(DateTime)];
        internal readonly Func<object?> GetValue;
        internal object? ClassInstance { get { return GetValue != null ? GetValue() : _ClassInstance; } private set { _ClassInstance = value; } }
        private object? _ClassInstance;
        internal XDocument? Xml;
        internal int Level;

        /// <summary>
        /// Delegate for the function that is called what needs to be saved
        /// </summary>
        /// <param name="classInstance">Object the user is editing</param>
        /// <param name="validationErrorReport">A textual report of validation errors. Null if there are no validation errors.</param>
        public delegate void SaveAction(object? classInstance, string? validationErrorReport);
        /// <summary>
        /// Action to call when the user has modified the object and needs to be saved
        /// </summary>
        internal SaveAction? OnSave { get; set; }

        /// <summary>
        /// Function to call to save the changes made to the class.
        /// This function is not available for AutoSave type interfaces (Because this type of management does not have the submit button as the saving is automatic)
        /// </summary>
        public Func<string?>? Submit { get; private set; }

        /// <summary>
        /// Update all values and call save function if defined
        /// </summary>
        internal void UpdateAll(StringBuilder errorLog, bool lookForParent = true)
        {
            if (lookForParent && Parent != null)
            {
                Parent.UpdateAll(errorLog);
            }
            else
            {
                lookForParent = false;
                foreach (var element in _elements)
                {
                    if (element is PropertyUISupport property)
                        property.UpdateValues(errorLog);
                    else if (element is ClassInfo obj)
                        obj.UpdateAll(errorLog, lookForParent);
                    else if (element is ObjectsCollection collection)
                        collection.UpdateAll(errorLog, lookForParent);
                }
                if (Level == 0)
                {
                    OnSave?.Invoke(ClassInstance, errorLog.Length == 0 ? null : errorLog.ToString());
                }
            }
        }
    }

    /// <summary>
    /// Specifies how the user interface will be used
    /// </summary>
    [Flags]
    public enum InterfaceType
    {
        /// <summary>
        /// It performs field validation in real time, while the user enters data.
        /// </summary>
        RealTimeValidation = 1,
        /// <summary>
        /// Like RealRimeValidation in addition, the data will be saved with each modification.
        /// Using this parameter the GUI does not have the submit button as it is not necessary
        /// This is the default.
        /// </summary>
        AutoSave = 3,
        /// <summary>
        /// the object being edited will be updated even if with non-validated values (If the property of the object allows it).
        /// </summary>
        AcceptInvalidValues = 4,
        /// <summary>
        /// The class will be rendered without a submit button, there is no validation and the save event is not handled. The class must provide the submit and user interaction methods.
        /// </summary>
        NoSubmitButton = 8,
        /// <summary>
        /// The class will be rendered without a submit button, there is no validation and the save event is not handled. The class must provide the submit and user interaction methods.
        /// </summary>
        RealTimeValidationNoSubmitButton = 9,
    }

    /// <summary>
    /// HTML input type equivalent
    /// </summary>
    public enum InputType
    {
#pragma warning disable
        button,
        checkbox,
        color,
        date,
        datetimeLocal,
        email,
        file,
        hidden,
        image,
        month,
        number,
        password,
        radio,
        range,
        reset,
        search,
        submit,
        tel,
        text,
        time,
        url,
        week,
        textarea,
#pragma warning restore
    }
}