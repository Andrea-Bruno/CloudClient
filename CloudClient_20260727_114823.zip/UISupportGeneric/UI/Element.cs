﻿using System.Diagnostics;
using System.Reflection;
using static UISupportGeneric.Util;
namespace UISupportGeneric.UI
{
    /// <summary>
    /// Basic element that exposes the basic properties that describe an object / class / instance
    /// </summary>
    public abstract class Element
    {
        /// <summary>
        /// Instance initializer
        /// </summary>
        /// <param name="name"></param>
        /// <param name="description"></param>
        /// <param name="order">Represents the order in which the elements of the code were defined. This value is inferred based on the position of the element description in the xml file</param>
        /// <param name="classInfo">Reference to the info class for this property</param>
        /// <param name="property">In case of property this value is passed to get the custom [attributes] associated with it.</param>
        internal Element(string name, string? description = null, int order = 0, ClassInfo? classInfo = null, PropertyInfo? property = null)
        {
            Property = property;
            Order = order;
            Name = name;
            Description = description;
            ClassInfo = classInfo;
        }

        internal ClassInfo? ClassInfo;
        internal readonly PropertyInfo? Property;

        private Icons.OpenIonic? IconValue { get; set; }
        /// <summary>
        /// Represents an icon that can be used to represent this element (the icon is generated automatically based on the other values of this element)
        /// </summary>
        public Icons.OpenIonic Icon
        {
            get
            {
                lock (this)
                {
                    if (IconValue == null)
                    {
                        var ois = FindEnumerator(typeof(Icons.OpenIonicSynonyms), Label, Description);
                        if (ois != null)
                            IconValue = (Icons.OpenIonic)(int)ois;
                        IconValue ??= (Icons.OpenIonic?)FindEnumerator(typeof(Icons.OpenIonic), Label, Description);
                        IconValue ??= Name.Last() == 's' ? Icons.OpenIonic.list_rich : Icons.OpenIonic.plus;
                    }
                }
                return (Icons.OpenIonic)IconValue;
            }
            internal set => IconValue = value;
        }

        /// <summary>
        /// Represents the order in which the elements of the code were defined. This value is inferred based on the position of the element description in the xml file
        /// </summary>
        internal int Order;

        /// <summary>
        /// The description of element (if it has been set in the source code in the form of a comment)
        /// </summary>
        public string? Description { get; internal set; }
        /// <summary>
        /// The name of the element
        /// </summary>
        public string Name { get; internal set; }
        private string? LabelValue;
        /// <summary>
        /// The name suitable for the label (Show this in the GUI!)
        /// </summary>
        public string Label
        {
            get
            {
                if (LabelValue == null)
                {
                    LabelValue = NameToLabel(Name);
                }
                return LabelValue;
            }
        }


        // ============= OnChange Detection Code =============


        /// <summary>
        /// Function that is called at intervals to check if the value has changed and then update the UI
        /// </summary>
        /// <param name="GetValue">Regerence to get value function</param>
        /// <param name="restrictedToReadOnly">If true then it is a timer calling, if false it means it is a user interacting</param>
        internal void PerformDetectChanges(Func<object?>? GetValue, bool restrictedToReadOnly, bool IsReadOnly)
        {
            if (OnChangeList == null || OnChangeList.Count == 0) return;
            // Limit timer if request requires CPU
            var refreshEvery = (restrictedToReadOnly && ExecutionTimer.Milliseconds > 0)
                ? TimeSpan.FromMinutes(1)
                : TimeSpan.FromSeconds(1);
            if (DateTime.Now - TimeDetectIfElementIsChanges < refreshEvery) return;
            TimeDetectIfElementIsChanges = DateTime.UtcNow;
            if ((restrictedToReadOnly && !IsReadOnly) || GetValue == null) return; // GetValue is null for parameters
            var timer = new System.Diagnostics.Stopwatch();
            timer.Start();
            var currentValue = GetValue?.Invoke();
            timer.Stop();
            ExecutionTimer = timer.Elapsed;
            var hashCurrentValue = GetHashValue(currentValue);
            if (hashCurrentValue != HashLastValue)
            {
                HashLastValue = hashCurrentValue;
                Refresh();
            }
        }

        internal int GetHashValue(object? value)
        {
            return value == null ? 0 : value.GetHashCode();
        }


        internal int HashLastValue;
        private DateTime TimeDetectIfElementIsChanges;
        private TimeSpan ExecutionTimer;


        /// <summary>
        /// Event that is executed when the value represented by this element changes
        /// Use UnsubscribeOnChange when destroying the UI to unsubscribe from the event!
        /// </summary>
        public Action? OnChange
        {
            set
            {
                OnChangeList ??= [];
                if (value != null)
                {
                    lock (OnChangeList)
                    {
                        if (!OnChangeList.Contains(value))
                        {
                            OnChangeList.Add(value);
                        }
                    }
                }
            }
        }

        internal void Refresh()
        {
            if (OnChangeList == null)
                return;
            lock (OnChangeList)
            {
                OnChangeList.ToList().ForEach(action => action.Invoke());
            }
        }

        /// <summary>
        /// Attribute that if True, indicates that the element will be hidden in the GUI
        /// </summary>
        public virtual bool? Hidden
        {
            get
            {
                var refName = Property?.GetCustomAttribute<HiddenBindAttribute>()?.Ref;
                refName ??= Name + "_" + nameof(Hidden);
                var result = ClassInfo?.GetPropertyValue(refName);
                return result is bool ? (bool)result : null;
            }
        }

        /// <summary>
        /// It allows to remove the OnChange event when the user interface will be closed. Otherwise events will continue to be generated to refresh interfaces that no longer exist!
        /// </summary>
        /// <param name="onChange">OnChange Action to remove</param>
        public void UnsubscribeOnChange(Action onChange)
        {
            if (OnChangeList != null)
            {
                lock (OnChangeList)
                {
                    OnChangeList.Remove(onChange);
                }
            }
        }
        internal List<Action>? OnChangeList;

    }
}