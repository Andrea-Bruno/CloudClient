﻿//using SkiaSharp.QrCode.Image;
//using SkiaSharp;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using UISupportGeneric.Resources;
using static UISupportGeneric.Util;
using QRCoder;
using System.Globalization;
using System.Reflection;

namespace UISupportGeneric.UI
{
    /// <summary>
    /// Class used by the graphical interface, to represent a property of a class and modify its value
    /// </summary>
    public abstract class EditableUIMember : BaseUISupport
    {
        /// <summary>
        /// Create an instance of the class
        /// </summary>
        /// <param name="type">Member type</param>
        /// <param name="name">Name of this member</param>
        /// <param name="description">Description of this member</param>
        /// <param name="order">Represents the order in which the elements of the code were defined. This value is inferred based on the position of the element description in the xml file</param>
        /// <param name="classInfo">Reference to the info class for this property</param>
        /// <param name="canBeSaved">If true, then the element cannot be edited</param>
        /// <param name="isReadyOnly">If true, then the element cannot be edited</param>
        /// <param name="property">In case of property this value is passed to get the custom [attributes] associated with it.</param>
        internal EditableUIMember(Type type, string name, string? description, int order, ClassInfo classInfo, bool canBeSaved = true, bool isReadyOnly = false, PropertyInfo? property = null) : base(name, description, order, classInfo, property)
        {
            IsReadOnly = isReadyOnly;
            Type = type;
            CanBeSaved = !isReadyOnly && canBeSaved;
            LLabel = Label.ToLower();
            LDescription = Description?.ToLower();
            if (type.IsEnum)
            {
                SettableValues = [];
                foreach (var item in Enum.GetNames(type))
                    SettableValues.Add(new EnumeratorMember(item, this));
            }
        }

        /// <summary>
        /// If true it indicates that the represented property cannot be changed
        /// </summary>
        public bool IsReadOnly { get; private set; }

        /// <summary>
        /// Type for this element
        /// </summary>
        internal readonly Type Type;

        /// <summary>
        /// Represents a member of a list of selectable enumerators
        /// </summary>
        public class EnumeratorMember
        {
            internal EnumeratorMember(string name, EditableUIMember memberOf)
            {
                Value = name;
                MemberOf = memberOf;
            }
            private readonly EditableUIMember MemberOf;
            /// <summary>
            /// label to show as an entry in the selectable list in the user interface
            /// </summary>
            public string Description => NameToLabel(Value);

            /// <summary>
            /// the value that comes can be selected
            /// </summary>
            public string Value { get; set; }
            /// <summary>
            /// Indicates if it is selected
            /// </summary>
            public bool Selected => Value == MemberOf.LiteralValue;

            /// <summary>
            /// Indicates if it is selected through a string that represents this value ("selected"), otherwise null
            /// </summary>
            public string? SelectedLiteral => Selected ? "selected" : null;
        }
        /// <summary>
        /// For enumerable properties, this is the list of elements
        /// </summary>
        public readonly List<EnumeratorMember>? SettableValues;

        /// <summary>
        /// Indicates if you are editing an object that can be saved.
        /// </summary>
        private readonly bool CanBeSaved;

        /// <summary>
        /// Function to call to save the changes made to the class.
        /// </summary>
        public void UpdateValues(StringBuilder? errorValidationLog = null) => ValidateValue(errorValidationLog);
        //private readonly System.Timers.Timer? DelayValidation;
        private readonly string LLabel;
        private readonly string? LDescription;

        /// <summary>
        /// Returns true if the value can represent a boolean of true value
        /// </summary>
        public bool IsTrue
        {
            get
            {
                var value = Value;
                if (Type == typeof(string) || Type == typeof(char))
                    return string.IsNullOrEmpty(value as string);
                if (Type.IsPrimitive && Type.IsValueType)
                {
                    try
                    {
                        return Convert.ToBoolean(value);
                    }
                    catch (Exception)
                    {
                        Debug.Write("value not convertible to bool");
                    }
                }
                return value != null;
            }
        }

        /// <summary>
        /// In case a range is represented this is the Min value, otherwise null
        /// </summary>
        /// <returns>Double value</returns>
        public double? Min
        {
            get
            {
                var min = Property?.GetCustomAttribute<RangeAttribute>()?.Min;
                if (min != null)
                    return min;
                var result = ClassInfo?.GetPropertyValue(Name + "_" + nameof(Min));
                return result != null && IsNumeric(result.GetType()) ? Convert.ToDouble(result) : null;
            }
        }

        /// <summary>
        /// In case a range is represented this is the Max value, otherwise null
        /// </summary>
        /// <returns>Double value</returns>
        public double? Max
        {
            get
            {
                var max = Property?.GetCustomAttribute<RangeAttribute>()?.Max;
                if (max != null)
                    return max;
                var result = ClassInfo?.GetPropertyValue(Name + "_" + nameof(Max));
                return result != null && IsNumeric(result.GetType()) ? Convert.ToDouble(result) : null;
            }
        }

        /// <summary>
        /// In case a range is represented this is the Step value, otherwise null
        /// </summary>
        /// <returns>Double value</returns>
        public double? Step
        {
            get
            {
                var step = Property?.GetCustomAttribute<RangeAttribute>()?.Step;
                if (step != null)
                    return step;
                var result = ClassInfo?.GetPropertyValue(Name + "_" + nameof(Step));
                return result != null && IsNumeric(result.GetType()) ? Convert.ToDouble(result) : null;
            }
        }

        /*         private int GetHashValue(object? value)
                {
                    _ = ObjectToLiteral(value, out int hashCode);
                    return hashCode;
                }
         */
        /// <summary>
        /// Function that is called at intervals to check if the value has changed and then update the UI
        /// </summary>
        /// <param name="restrictedToReadOnly">If true then it is a timer calling, if false it means it is a user interacting</param>
        internal void DetectIfElementIsChanges(bool restrictedToReadOnly)
        {
            PerformDetectChanges(GetValue, restrictedToReadOnly, IsReadOnly);
        }

        /// <summary>
        /// The value of the property
        /// </summary>
        internal object? Value
        {
            get
            {
                if (TmpValue != null)
                    return TmpValue;
                return GetValue?.Invoke();
            }
            set
            {
                if (IsReadOnly)
                    return;
                lock (this)
                {
                    //SetValue?.Invoke(value); 
                    TmpValue = value;
                    if (ClassInfo.InterfaceType.HasFlag(InterfaceType.RealTimeValidation))
                        ExecuteRealTimeValidation();
                }
            }
        }

        /// <summary>
        /// If the member is an image (photo or drawing), it returns the binary image, in png format
        /// </summary>
        [DebuggerHidden] // Don't break at throw
        public byte[]? Image
        {
            get
            {
                if (ImageType == ImageSourceType.QRcode)
                {
                    try
                    {
                        var literalValue = LiteralValue;
                        if (literalValue == null)
                            return null;

                        using var qrGenerator = new QRCodeGenerator();
                        using var qrCodeData = qrGenerator.CreateQrCode(literalValue, QRCodeGenerator.ECCLevel.Q);
                        using var qrCode = new PngByteQRCode(qrCodeData);
                        byte[] qrCodeImage = qrCode.GetGraphic(10); // 10 pixels for a single square
                        return qrCodeImage;

                        //using MemoryStream ms = new();
                        //var qrCode = new QrCode(literalValue, new Vector2Slim(256, 256), SKEncodedImageFormat.Png);
                        //// output to file
                        //qrCode.GenerateImage(ms);
                        //return ms.ToArray();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
                return null;
            }
        }

        /// <summary>
        /// If the member is an image (photo or drawing), it returns the image data encoded in base64, in png format
        /// </summary>
        public string ImageBase64
        {
            get
            {
                var image = Image;
                return image == null ? null : Convert.ToBase64String(image);
            }
        }

        /// <summary>
        /// The value of the property represented as a literary string, in order to be displayed in a user interface.
        /// Use this to display and edit a value from the GUI.
        /// </summary>
        public string? LiteralValue
        {
            get
            {
                var result = ObjectToLiteral(Value);
                HashLastValue = GetHashValue(Value);
                return result;
            }
            set
            {
                if (IsReadOnly)
                    return;
                HashLastValue = GetHashValue(value);
                Value = value;
                if (GetValue != null) // exclude parameters
                    ClassInfo.DetectIfElementIsChanges(false);
            }
        }

        /// <summary>
        /// Returns a literary description of the element
        /// </summary>
        /// <param name="value">The element</param>
        /// <returns>Text</returns>
        private string? ObjectToLiteral(object? value)
        {
            string? result;
            if (value == null)
            {
                //hashCode = 0;
                return null;
            }
            if (value is Color color)
                result = "#" + BitConverter.ToString(BitConverter.GetBytes(color.ToArgb())[..3]).Replace("-", "");
            else if (value is DateTime dateTime)
            {
                if (InputType == InputType.time)
                    result = dateTime.ToString("HH:mm:ss");
                else if (InputType == InputType.date)
                    result = dateTime.ToString("yyyy-MM-dd");
                else
                    result = dateTime.ToString("yyyy-MM-dd") + "T" + dateTime.ToString("HH:mm:ss"); // https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#local_date_and_time_strings
            }
            else
            {
                if (value is IFormattable formattable)
                    result = formattable.ToString(null, CultureInfo.InvariantCulture);
                else
                    result = value.ToString();
            }

            //hashCode = result == null ? 0 : result.GetHashCode();
            return result;
        }

        internal Func<object?>? GetValue;
        internal Action<object?>? SetValue;

        /// <summary>new
        /// Used to catch validation errors;
        /// </summary>
        /// <param name="error">Description of the error, or null if there is no error</param>
        public delegate void OnValidation(string? error);
        /// <summary>
        /// Event that is generated when the validation status of the inserted property value changes
        /// </summary>
        public event OnValidation? OnValidationChangeStatus;

        private void ExecuteRealTimeValidation()
        {
            var errorValidationLog = new StringBuilder();
            var valueHasBeenChanged = ValidateValue(errorValidationLog);                // NOTE ValidateValue(true) Return if the value has been changed
            if (CanBeSaved && valueHasBeenChanged && ClassInfo.InterfaceType.HasFlag(InterfaceType.AutoSave))
            {
                ClassInfo?.OnSave?.Invoke(ClassInfo.ClassInstance, errorValidationLog.ToString());
            }
        }
        private object? TmpValue;
        private int HashLastTmpValue;

        /// <summary>
        /// Validates an entered value and updates it in the property if specified in the parameter
        /// </summary>
        /// <param name="errorValidationLog">Append to errorLog the validation errors, if any</param>
        /// <returns>True if the value has changed</returns>
        private bool ValidateValue(StringBuilder? errorValidationLog = null)
        {
            if (TmpValue == null)
                return false;
            var HashTmpValue = TmpValue.GetHashCode();
            var hasChanged = HashLastTmpValue != HashTmpValue;
            HashLastTmpValue = HashTmpValue;
            string? validationError = null;
            Exception = null;
            try
            {
                validationError = Validate(TmpValue.ToString(), out var ex);
                Exception = ex;
                if (validationError == null || ClassInfo.InterfaceType.HasFlag(InterfaceType.AcceptInvalidValues))
                {
                    if (ClassInfo.IsCustomType(Type))
                    {
                        var propInfo = Type.GetProperty("FromString");
                        propInfo?.SetValue(GetValue?.Invoke(), TmpValue, null);
                    }
                    else
                    {
                        object? val;
                        if (!ConvertSpecificTypes(TmpValue, out val))
                            if (Type.IsEnum)
                                val = Enum.Parse(Type, (string)TmpValue);
                            else if (Type.BaseType == typeof(ValueType) && (TmpValue == null || (TmpValue is string text && text == "")))
                                val = default; // then field is empty (then the valued is Zero)
                            else
                                val = Convert.ChangeType(TmpValue, Type, CultureInfo.InvariantCulture);
                        SetValue?.Invoke(val);
                    }
                    TmpValue = null;
                }
            }
            catch (Exception ex)
            {
                Exception = ex;
            }
            if (validationError != null && errorValidationLog != null)
                errorValidationLog.AppendLine(Label + ": " + validationError);
            if (validationError != ValidationError)
            {
                ValidationError = validationError;
                OnValidationChangeStatus?.Invoke(Error);
            }
            return hasChanged;
        }

        internal string? GetValidateError()
        {
            ValidationError = Validate(LiteralValue, out _);
            return ValidationError;
        }

        private string? Validate(string? value, out Exception? exception)
        {
            string? validationError = null;
            try
            {
                // validation
                var literal = value;
                validationError = ValidateCustomProperty(literal);
                if (validationError == null && literal != null)
                {
                    if (validationError == null)
                    {
                        var input = InputType;
                        if (input == InputType.tel)
                            validationError = Regex.Match(literal, @"^\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$").Success ? null : Dictionary.InvalidValue;
                        else if (input == InputType.email)
                            validationError = Regex.Match(literal, @"^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$").Success ? null : Dictionary.InvalidValue;
                        else if (input == InputType.url)
                            validationError = Uri.TryCreate(literal, UriKind.Absolute, out _) ? null : Dictionary.InvalidValue;
                        else if (input == InputType.password)
                        {
                            var vulnerabiliy = CheckPasswordStrength(literal);
                            validationError = vulnerabiliy == 0 ? null : Dictionary.VulnerabilityLevel + " " + (int)vulnerabiliy;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                exception = ex;
            }
            exception = null;
            return validationError;
        }


        /// <summary>
        /// Check if a custom validation is set and perform the validation
        /// </summary>
        /// <param name="value"></param>
        /// <returns>Returns null if the validation test passes, otherwise returns an error string</returns>
        private string? ValidateCustomProperty(string? value)
        {
            if (Property == null)
                return null;
            var attribute = Property.GetCustomAttribute<RegexAttribute>();
            var regex = attribute?.Pattern;
            regex ??= Property.GetCustomAttribute<EmailAttribute>() != null ? EmailAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<EmailAttribute>() != null ? EmailAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<InternationalPhoneAttribute>() != null ? InternationalPhoneAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<ZipCodeAttribute>() != null ? ZipCodeAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<AlphanumericPostalCodeAttribute>() != null ? AlphanumericPostalCodeAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<UrlAttribute>() != null ? UrlAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<StrongPasswordAttribute>() != null ? StrongPasswordAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<LettersOnlyAttribute>() != null ? LettersOnlyAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<NumbersOnlyAttribute>() != null ? NumbersOnlyAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<AlphanumericAttribute>() != null ? AlphanumericAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<DateAttribute>() != null ? DateAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<IPv4Attribute>() != null ? IPv4Attribute.Regex : null;
            regex ??= Property.GetCustomAttribute<IPv6Attribute>() != null ? IPv6Attribute.Regex : null;
            regex ??= Property.GetCustomAttribute<CreditCardAttribute>() != null ? CreditCardAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<ProperNameAttribute>() != null ? ProperNameAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<PositiveDecimalAttribute>() != null ? PositiveDecimalAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<FileNameAttribute>() != null ? FileNameAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<ItalianTaxCodeAttribute>() != null ? ItalianTaxCodeAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<ItalianLicensePlateAttribute>() != null ? ItalianLicensePlateAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<Time24HourFormatAttribute>() != null ? Time24HourFormatAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<ISBN10Attribute>() != null ? ISBN10Attribute.Regex : null;
            regex ??= Property.GetCustomAttribute<ISBN13Attribute>() != null ? ISBN13Attribute.Regex : null;
            regex ??= Property.GetCustomAttribute<HexColorCodeAttribute>() != null ? HexColorCodeAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<MACAddressAttribute>() != null ? MACAddressAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<USSocialSecurityNumberAttribute>() != null ? USSocialSecurityNumberAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<USPhoneNumberAttribute>() != null ? USPhoneNumberAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<CurrencyFormatAttribute>() != null ? CurrencyFormatAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<LatinLettersAndSpacesAttribute>() != null ? LatinLettersAndSpacesAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<HTMLTagAttribute>() != null ? HTMLTagAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<BinaryNumberAttribute>() != null ? BinaryNumberAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<HexadecimalNumberAttribute>() != null ? HexadecimalNumberAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<SlugAttribute>() != null ? SlugAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<PercentageAttribute>() != null ? PercentageAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<UUIDAttribute>() != null ? UUIDAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<NonEmptyStringsAttribute>() != null ? NonEmptyStringsAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<DigitsWithThousandsSeparatorAttribute>() != null ? DigitsWithThousandsSeparatorAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<MultilingualTextAttribute>() != null ? MultilingualTextAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<FloatingPointNumberAttribute>() != null ? FloatingPointNumberAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<PositiveIntegersOnlyAttribute>() != null ? PositiveIntegersOnlyAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<NegativeIntegersOnlyAttribute>() != null ? NegativeIntegersOnlyAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<AlphaNumericWithSpacesAttribute>() != null ? AlphaNumericWithSpacesAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<UppercaseOnlyAttribute>() != null ? UppercaseOnlyAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<LowercaseOnlyAttribute>() != null ? LowercaseOnlyAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<TwoDecimalFloatingPointAttribute>() != null ? TwoDecimalFloatingPointAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<USZipPlus4CodeAttribute>() != null ? USZipPlus4CodeAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<FilePathAttribute>() != null ? FilePathAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<HTMLCommentAttribute>() != null ? HTMLCommentAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<CreditCardExpirationDateAttribute>() != null ? CreditCardExpirationDateAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<CanadianPostalCodeAttribute>() != null ? CanadianPostalCodeAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<HTMLColorAttribute>() != null ? HTMLColorAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<EuropeanDateAttribute>() != null ? EuropeanDateAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<Base64StringAttribute>() != null ? Base64StringAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<YouTubeVideoIDAttribute>() != null ? YouTubeVideoIDAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<IPv4CIDRBlockAttribute>() != null ? IPv4CIDRBlockAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<TwitterUsernameAttribute>() != null ? TwitterUsernameAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<InstagramUsernameAttribute>() != null ? InstagramUsernameAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<LinkedInProfileURLAttribute>() != null ? LinkedInProfileURLAttribute.Regex : null;
            regex ??= Property.GetCustomAttribute<UUIDWithBracesAttribute>() != null ? UUIDWithBracesAttribute.Regex : null;

            if (regex != null)
            {
                if (!Regex.IsMatch(value ?? string.Empty, regex))
                {
                    return Dictionary.InvalidValue;
                }
            }
            return null;
        }

        private bool ConvertSpecificTypes(object stringValue, out object? val)
        {
            if (stringValue is string literal && stringValue != null)
            {
                if (Type == typeof(Color))
                {
                    var argb = BitConverter.GetBytes(ColorTranslator.FromHtml(literal).ToArgb());
                    if (literal.Length == 7) // The color definition does not contain A
#pragma warning disable
                        argb[3] = ((Color)Value).A; // keep transparency as in the original (A value)
#pragma warning restore
                    val = Color.FromArgb(BitConverter.ToInt32(argb));
                    return true;
                }
                else if (Type == typeof(DateTime))
                {
                    // format of literal is  https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#local_date_and_time_strings
                    var dt = DateTime.Parse(literal, CultureInfo.InvariantCulture); // https://learn.microsoft.com/it-it/dotnet/api/system.datetime.parse?view=net-7.0
                    if (InputType == InputType.date)
                        val = new DateTime(dt.Year, dt.Month, dt.Day);
                    else if (InputType == InputType.time)
                        val = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, dt.Hour, dt.Minute, dt.Second);
                    else
                        val = dt;
                    return true;
                }
            }
            val = null;
            return false;
        }

        private InputType? _InputType;
        /// <summary>
        /// The type of input that the graphical interface must show to display this property (these are input types used in html interfaces)
        /// </summary>
        public InputType InputType
        {
            get
            {
                if (_InputType == null)
                    _InputType = DetectInputType();
                return (InputType)_InputType;
            }
        }
        private enum ImageSourceType
        {
            None,
            QRcode,
        }
        private ImageSourceType ImageType;
        private InputType DetectInputType()
        {
            if (Type.IsEnum)
                return InputType.text; // Need to show <select /> and not <input />
            if (IsNumeric(Type))
            {
                return Min == null && Max == null && Step == null ? InputType.number : InputType.range;
            }
            if (Type == typeof(bool))
                return InputType.checkbox;
            string[] wheres = (LDescription != null) ? [LLabel, LDescription] : [LLabel];
            if (Type == typeof(DateTime))
            {
                if (GetValue?.Invoke() is DateTime date)
                {
                    var isDete = date.Year != DateTime.MinValue.Year || date.Month != DateTime.MinValue.Month || date.Day != DateTime.MinValue.Day;
                    var isTime = date.Hour != DateTime.MinValue.Hour || date.Minute != DateTime.MinValue.Minute || date.Second != DateTime.MinValue.Second;
                    if (isDete && isTime)
                        return InputType.datetimeLocal;
                    else if (isDete)
                        return InputType.date;
                    else if (isTime)
                        return InputType.time;
                    else if (ContainsOneOfTheseWords(wheres, [nameof(InputType.date)]))
                        return InputType.date;
                    else if (ContainsOneOfTheseWords(wheres, [nameof(InputType.time)]))
                        return InputType.time;
                }
                return InputType.datetimeLocal;
            }
            foreach (var where in wheres)
            {
                if (ContainsOneOfTheseWords(where, [nameof(InputType.password)]))
                    return InputType.password;
                if (ContainsOneOfTheseWords(where, [nameof(InputType.date)]))
                    return InputType.date;
                if (ContainsOneOfTheseWords(where, [nameof(InputType.color)]))
                    return InputType.color;
                if (ContainsOneOfTheseWords(where, [nameof(InputType.email), "e-mail"]))
                    return InputType.email;
                if (ContainsOneOfTheseWords(where, [nameof(InputType.tel), "phone"]))
                    return InputType.tel;
                if (ContainsOneOfTheseWords(where, [nameof(InputType.time)]))
                    return InputType.time;
            }
            if (Type == typeof(string))
            {
                if (ContainsWord(LLabel, "qr"))
                {
                    ImageType = ImageSourceType.QRcode;
                    return InputType.image;
                }
                if (ContainsOneOfTheseWords([LLabel], MultilineFieldNames))
                {
                    return InputType.textarea;
                }
            }
            return InputType.text;
        }

        /// <summary>
        /// Provides a list of field names that are commonly used to represent multiline or formatted text content.
        /// </summary>
        /// <remarks>The <see cref="MultilineFieldNames"/> array includes names for fields that typically
        /// contain text spanning multiple lines, such as chat messages, documentation, prompts, or code snippets. This
        /// list can be used to identify or filter fields that may require special handling for multiline input or
        /// display.</remarks>
        public static readonly string[] MultilineFieldNames =
        {
            "chat",
            "history",
            "conversation",
            "dialogue",
            "example",
            "prompt",
            "reasoning",
            "response",
            "schema",
            "document",
            "readme",
            "changelog",
            "notes",
            "message",
            "patch",
            "architecture",
            "spec",
            "story",
            "criteria",
            "terms",
            "condition",
            "policy",
            "license",
            "agreement",
            "contract",
            "clause",
            "disclaimer",
            "notice",
            "eula",
            "lesson",
            "lecture",
            "tutorial",
            "guide",
            "howto",
            "exercise",
            "assignment",
            "question",
            "answer",
            "solution",
            "explanation",
            "proof",
            "theorem",
            "script",
            "lyrics",
            "poem",
            "verse",
            "monologue",
            "interview",
            "plan",
            "proposal",
            "pitch",
            "proposition",
            "analysis",
            "summary",
            "statement",
            "definition",
            "variables",
            "manifest",
            "actions",
            "workflow",
            "markdown",
            "md",
            "test",
            "scenario",
            "report",
            "expected",
            "behavior",
            "faq",
            "knowledge",
            "troubleshooting",
            "help",
            "support",
            "issue",
            "query",
            "abstract",
            "introduction",
            "method",
            "function",
            "code",
            "conclusion",
            "bibliography",
            "citation",
            "hypothesis",
            "localized",
            "translation",
            "content",
            "text",
            "data",
            "list",
            "procedure",
            "checklist",
            "todo",
            "placeholder",
            "notification",
            "toast",
            "new",
            "quest",
            "tree",
            "items",
            "observation",
            "research",
            "protocol",
            "forecast",
            "note",
            "details",
            "requirements",
            "letter",
            "feedback",
            "multiline",
            "rich",
            "formatted",
            "mainframe",
            "description",
            "documentation",
            "request",
            "config",
            "insight",
            "detailed",
            "full",
            "prompt",
            "comment",
            "body",
            "overview",
            "detail",
            "background",
            "feedback",
            "remark",
            "annotation",
            "excerpt",
            "snippet",
            "template",
            "draft",
            "outline",
            "synopsis",
            "recap",
            "review",
            "critique",
            "assessment",
            "evaluation",
            "suggestion",
            "recommendation",
            "objective",
            "goal",
            "mission",
            "strategy",
            "plan",
            "schedule",
            "agenda",
            "minutes",
            "survey",
            "poll",
            "thread",
            "exchange",
            "discussion",
            "debate",
            "argument",
            "claim",
            "objection",
            "concern",
            "symptom",
            "diagnosis",
            "guideline",
            "standard",
            "feature",
            "flow",
            "state",
            "event",
            "trigger",
            "step",
            "instruction",
            "order",
            "demo",
            "illustration",
            "diagram",
            "graph",
            "chart",
            "legend",
            "glossary",
            "index",
            "type",
            "class",
            "module",
            "service",
            "route",
            "job",
            "task",
            "phase",
            "risk",
            "backup",
            "prerequisite",
            "reference",
            "article",
            "announcement",
            "bug",
            "improvement",
            "spike",
            "mockup",
            "tradeoff",
            "comparison"
        };

        /// <summary>
        /// Text string indicating the type of input that the graphical interface must show to display this property (these are input types used in html interfaces)
        /// </summary>
        public string InputTypeText
        {
            get
            {
                var inputType = InputType;
                return inputType == InputType.datetimeLocal ? "datetime-local" : inputType.ToString();
            }
        }
    }

}