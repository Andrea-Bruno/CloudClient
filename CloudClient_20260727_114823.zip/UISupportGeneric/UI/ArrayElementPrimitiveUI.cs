﻿using System.Collections;

namespace UISupportGeneric.UI
{
    /// <summary>
    /// Class used by the graphical interface, to represent a member of a collection and modify its value
    /// </summary>
    public class ArrayElementPrimitiveUI : EditableUIMember
    {
        private readonly IEnumerable _collection;
        private readonly int _elementIndex;
        private IList _listCache;

        /// <summary>
        /// Create an instance of the class
        /// </summary>
        /// <param name="collection">The collection that contains the element you want to represent</param>
        /// <param name="elementIndex">The index of the element you want to represent</param>
        internal ArrayElementPrimitiveUI(IEnumerable collection, int elementIndex)
            : base(GetElementType(collection), (elementIndex + 1).ToString(), null, 0, null, isReadyOnly: false)
        {
            _collection = collection ?? throw new ArgumentNullException(nameof(collection));
            _elementIndex = elementIndex;

            GetValue = () =>
            {
                try
                {
                    if (_collection is Array array)
                        return array.GetValue(_elementIndex);

                    if (_listCache == null && _collection is IList list)
                        _listCache = list;

                    if (_listCache != null)
                        return _listCache[_elementIndex];

                    // Fallback for non-indexed collections
                    int current = 0;
                    foreach (var item in _collection)
                    {
                        if (current == _elementIndex)
                            return item;
                        current++;
                    }
                    throw new IndexOutOfRangeException($"Index {_elementIndex} is out of range");
                }
                catch (Exception ex)
                {
                    Exception = ex;
                    return null;
                }
            };

            SetValue = value =>
            {
                try
                {
                    if (_collection is Array array)
                    {
                        array.SetValue(value, _elementIndex);
                        return;
                    }

                    if (_listCache == null && _collection is IList list)
                        _listCache = list;

                    if (_listCache != null)
                    {
                        _listCache[_elementIndex] = value;
                        return;
                    }

                    throw new NotSupportedException("Collection doesn't support indexed access");
                }
                catch (Exception ex)
                {
                    Exception = ex;
                    throw;
                }
            };
        }

        private static Type GetElementType(IEnumerable collection)
        {
            if (collection is Array array)
                return array.GetType().GetElementType();

            Type collectionType = collection.GetType();

            // Handle generic IEnumerable<T>
            var enumerableInterface = collectionType.GetInterfaces()
                .FirstOrDefault(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IEnumerable<>));

            if (enumerableInterface != null)
            {
                return enumerableInterface.GetGenericArguments()[0];
            }

            // Fallback to object type for non-generic collections
            return typeof(object);
        }
    }
}