﻿using System.Reflection;
using UISupportGeneric.Resources;
using static UISupportGeneric.Terminal;
using static UISupportGeneric.Util;
namespace UISupportGeneric.UI
{
    /// <summary>
    /// Class used to give GUI access to the methods of an object
    /// </summary>
    public class MethodUISupport : BaseUISupport
    {
        /// <summary>
        /// Create an instance of the class
        /// </summary>
        /// <param name="method">The method to be represented by the graphical interface</param>
        /// <param name="classInfo">Reference to the info class for this property</param>
        internal MethodUISupport(MethodInfo method, ClassInfo classInfo) : base(GetMethodDisplayName(method), GetMemberDescription(out var order, method, classInfo.Xml, out _), order, classInfo)
        {
            Method = method;
            Parameters = [];
            foreach (var parameter in method.GetParameters())
                Parameters.Add(new ParametersUISupport(parameter, classInfo));
        }

        /// <summary>
        /// Gets the display name for a method, removing the "Async" suffix if present for async methods
        /// </summary>
        /// <param name="method">The method to get the display name for</param>
        /// <returns>The display name without "Async" suffix</returns>
        private static string GetMethodDisplayName(MethodInfo method)
        {
            var name = method.Name;
            // Check if method is async and has "Async" suffix
            if (method.ReturnType.IsGenericType && method.ReturnType.GetGenericTypeDefinition() == typeof(Task<>) || method.ReturnType == typeof(Task))
            {
                return name.Replace("Async", "");
            }
            return name;
        }

        private readonly MethodInfo Method;

        private int Running;

        /// <summary>
        /// Execute the method represented by this object
        /// </summary>
        public async void Execute()
        {
            if (Running != 0)
                return;
            Running++;
            var param = new List<object?>();
            foreach (var p in Parameters)
            {
                param.Add(p.Value);
            }
            try
            {
                var result = Method.Invoke(ClassInfo.ClassInstance, param.ToArray());
                if (result is Task task)
                {
                    // Use await instead of Wait() to avoid deadlock
                    await task.ConfigureAwait(false);
                    var taskType = task.GetType();

                    // Verify if is a type Task<T>
                    if (taskType.IsGenericType)
                    {
                        var resultProperty = taskType.GetProperty("Result");
                        if (resultProperty != null)
                        {
                            result = resultProperty.GetValue(task);
                        }
                    }
                    else
                    {
                        result = Dictionary.CommandSuccessfully;
                    }
                }

                if (Method.ReturnType == typeof(void))
                    ResultValue = Dictionary.CommandSuccessfully;
                else
                {
                    if (result is System.Collections.IEnumerable enumerable && result is not string)
                    {
                        TableResult = new TableUISupport(enumerable, ClassInfo);
                    }
                    ResultValue = result;
                }
                Exception = null;
            }
            catch (Exception ex)
            {
                ResultValue = null;
                Exception = ex;
            }
            ShowResult = true;
            _ = ClassInfo?.Hidden; // force refresh if Hidden property is changed
            Running--;
        }
        /// <summary>
        /// FLag which is set to true when the method is executed
        /// </summary>
        /// <value></value>
        public bool ShowResult { get; private set; }

        /// <summary>
        /// List of parameters that the method receives as input
        /// </summary>
        public readonly List<ParametersUISupport> Parameters;

        /// <summary>
        /// Result of the execution of the method: If the method is a function, when executed, this value represents the result returned by the method
        /// </summary>
        private object? ResultValue { get; set; }

        /// <summary>
        /// Literal result of the execution of the method: If the method is a function, when executed, this value represents the literal result returned by the method
        /// </summary>
        public string? Result { get { return ObjToString(ResultValue); } }

        /// <summary>
        /// If the method returns an array, here is its representation
        /// </summary>
        public TableUISupport TableResult { get; private set; }
    }
}