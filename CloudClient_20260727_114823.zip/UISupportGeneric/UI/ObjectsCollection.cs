﻿using System.Collections;
using System.Reflection;
using System.Text;
using static UISupportGeneric.UI.ClassInfo;

namespace UISupportGeneric.UI
{
    /// <summary>
    /// Represents a collection of editable objects, for display in the GUI
    /// </summary>
    public class ObjectsCollection : BaseUISupport
    {
        private readonly PropertyInfo _propertyInfo;
        private readonly InterfaceType _interfaceType;
        private readonly SaveAction? _onSave;
        private readonly int _level;
        private readonly Type _elementType;
        private List<Element> _objects;

        /// <summary>
        /// Create an instance of the class
        /// </summary>
        /// <param name="propertyInfo">Info of the enumerable property</param>
        /// <param name="classInfo">Reference to the info class for this collection</param>
        /// <param name="interfaceType">Specifies how the user interface will be used</param>
        /// <param name="onSave">Action to save the component</param>
        /// <param name="level">Used to limit the depth of analysis</param>
        internal ObjectsCollection(PropertyInfo propertyInfo, ClassInfo classInfo, InterfaceType interfaceType = InterfaceType.AutoSave, SaveAction? onSave = null, int level = 0) : base(propertyInfo.Name, Util.GetMemberDescription(out var order, propertyInfo, classInfo.Xml, out _), order, classInfo)
        {
            _propertyInfo = propertyInfo;
            _interfaceType = interfaceType;
            _onSave = onSave;
            _level = level;
            _elementType = GetElementType(propertyInfo.PropertyType);
            _objects = [];
        }

        private Type GetElementType(Type collectionType)
        {
            // Handle arrays
            if (collectionType.IsArray)
                return collectionType.GetElementType();

            // Handle generic IEnumerable<T>
            var genericEnumerable = collectionType.GetInterfaces()
                .FirstOrDefault(i => i.IsGenericType &&
                                   i.GetGenericTypeDefinition() == typeof(IEnumerable<>));

            if (genericEnumerable != null)
                return genericEnumerable.GetGenericArguments()[0];

            // Fallback for non-generic IEnumerable
            if (typeof(IEnumerable).IsAssignableFrom(collectionType))
                return typeof(object);

            throw new ArgumentException("The provided type is not a collection", nameof(collectionType));
        }

        internal void UpdateAll(StringBuilder errorLog, bool lookForParent = true)
        {
            if (_objects != null)
            {
                foreach (var element in _objects.ToArray())
                {
                    if (element is ClassInfo classInfo)
                        classInfo.UpdateAll(errorLog, lookForParent);
                }
            }
        }

        internal void DetectIfElementIsChanges(bool restrictedToReadOnly, bool propagation = false)
        {
            if (_objects != null)
            {
                foreach (var element in _objects.ToArray())
                {
                    if (element is ClassInfo classInfo)
                        classInfo.DetectIfElementIsChanges(restrictedToReadOnly, propagation);
                }
            }
        }

        /// <summary>
        /// The objects that are part of this collection.
        /// The return type can be ArrayElementPrimitiveUI or ClassInfo.
        /// For objects that have multiple properties to be represented, ClassInfo is returned.
        /// For primitive objects that represent a single value, ArrayElementPrimitiveUI is returned.
        /// </summary>
        public Element[] Elements
        {
            get
            {
                lock (this)
                {
                    var collection = _propertyInfo.GetValue(ClassInfo.ClassInstance) as IEnumerable;
                    if (collection == null)
                    {
                        _objects.Clear();
                        return _objects.ToArray();
                    }

                    var currentItems = new List<object>();
                    foreach (var item in collection)
                    {
                        currentItems.Add(item);
                    }

                    // Reuse existing elements if possible
                    if (_objects.Count == currentItems.Count)
                    {
                        bool canReuse = true;
                        for (int i = 0; i < currentItems.Count; i++)
                        {
                            var existingElement = _objects[i];
                            var currentItem = currentItems[i];

                            if (existingElement is ArrayElementPrimitiveUI primitive)
                            {
                                if (!Equals(primitive.GetValue(), currentItem))
                                {
                                    canReuse = false;
                                    break;
                                }
                            }
                            else if (existingElement is ClassInfo classInfo)
                            {
                                if (!ReferenceEquals(classInfo.ClassInstance, currentItem))
                                {
                                    canReuse = false;
                                    break;
                                }
                            }
                        }

                        if (canReuse)
                            return _objects.ToArray();
                    }

                    // Create new elements list
                    _objects.Clear();
                    bool isSupportedType = ClassInfo.IsSupportedType(_elementType);

                    for (int i = 0; i < currentItems.Count; i++)
                    {
                        object item = currentItems[i];
                        if (isSupportedType)
                        {
                            _objects.Add(new ArrayElementPrimitiveUI(collection, i));
                        }
                        else
                        {
                            _objects.Add(new ClassInfo(item, _interfaceType, _onSave, _level + 1, ClassInfo));
                        }
                    }
                    return _objects.ToArray();
                }
            }
        }
    }


}