﻿using System.Reflection;

namespace UISupportGeneric.UI
{
    public abstract class Event
    {
        internal Event(EventType eventType, ClassInfo classInfo, FieldInfo? field = null)
        {
            ClassInfo = classInfo;
            Field = field;
        }

        internal ClassInfo ClassInfo;

        internal FieldInfo? Field;
        public enum EventType
        {
            Redirect,
        }
    }
}
