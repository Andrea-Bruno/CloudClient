﻿using System.Reflection;
using static UISupportGeneric.Util;
namespace UISupportGeneric.UI
{
    /// <summary>
    /// Class used by the graphical interface, to represent a property of a class and modify its value
    /// </summary>
    public class PropertyUISupport : EditableUIMember
    {
        /// <summary>
        /// Create an instance of the class
        /// </summary>
        /// <param name="property">The property to be represented by the graphical interface</param>
        /// <param name="classInfo">Reference to the info class for this property</param>
        internal PropertyUISupport(PropertyInfo property, ClassInfo classInfo) : base(property.PropertyType, property.Name, GetMemberDescription(out var order, property, classInfo.Xml, out _), order, classInfo, isReadyOnly: !IsEditable(property) || classInfo.IsReadOnly, property: property)
        {
            GetValue = () =>
            {
                try
                {
                    return property.GetValue(ClassInfo.ClassInstance);
                }
                catch (Exception ex)
                {
                    Exception = ex;
                    return null;
                }
            };
            SetValue = value => property.SetValue(ClassInfo.ClassInstance, value);
        }
    }
}