﻿using System.Net.Http.Headers;
using System.Reflection;

namespace UISupportGeneric.UI
{
    /// <summary>
    /// Read only table:
    /// Object that represents a collection and allows it to be easily displayed in a user interface
    /// </summary>
    public class TableUISupport : BaseUISupport
    {
        /// <summary>
        /// Create an instance which represents a read-only table
        /// </summary>
        /// <param name="propertyInfo">Info of collection</param>
        /// <param name="classInfo">Reference to the info class for this collection</param>
        /// <param name="onSelected">Method that must be called from the UI when the user has selected an element of the collection</param>
        internal TableUISupport(PropertyInfo propertyInfo, ClassInfo classInfo, Action<int>? onSelected) : base(propertyInfo.Name, Util.GetMemberDescription(out var order, propertyInfo, classInfo.Xml, out _), order, classInfo)
        {
            PropertyInfo = propertyInfo;
            OnSelected = onSelected;
            //Init();
        }

        /// <summary>
        /// Create an instance which represents a read-only table
        /// </summary>
        /// <param name="collection">Collection to represent</param>
        /// <param name="classInfo">Reference to the info class for this collection</param>
        internal TableUISupport(System.Collections.IEnumerable collection, ClassInfo classInfo)
            : base(collection.GetType().Name, null, 0, classInfo)
        {
            Collection = collection;
            //Init();
        }

        //void Init()
        //{
        //    IsSelector = SelectWords.Any(x => Name.ToLower().Contains(x)) || (Description != null && Util.ContainsOneOfTheseWords(Description.ToLower(), SelectWords));
        //}

        //private static readonly string[] SelectWords = { "select", "choose" };
        private readonly System.Collections.IEnumerable? Collection;
        private readonly PropertyInfo? PropertyInfo;

        /// <summary>
        /// Indicates whether the collection represents a list in which the user can select an element (true), or it is a simple list to be shown in the UI without user interaction (false)
        /// </summary>
        public bool IsSelector => OnSelected != null;

        /// <summary>
        /// Method that must be called from the UI when the user has selected an element of the collection
        /// </summary>
        /// <param name="recordIndex">Base 0 index of record selected by user</param>
        public void SetSelected(int recordIndex, Action? onSelectFeedback = null)
        {
            OnSelected?.Invoke(recordIndex);
            onSelectFeedback?.Invoke();
        }

        /// <summary>
        /// Method that is executed when an element is selected
        /// The method that is called must have the name "OnSelect+CollectionName"
        /// </summary>
        private Action<int>? OnSelected { get; set; }

        /// <summary>
        /// Heading of the table with the names of the fields in the records
        /// </summary>
        public IEnumerable<string> Titles
        {
            get
            {
                if (TitlesList != null)
                    return TitlesList;
                Cache = Records; // refresh TitlesList
                return TitlesList ?? [];
            }
        }
        private List<string>? TitlesList;
        //private List<IEnumerable<string?>?>? RecordList;

        internal static List<MemberInfo> RecordFields(Type elementType, bool restrict = true)
        {
            var filter = restrict ? BindingFlags.GetField | BindingFlags.GetProperty : BindingFlags.Default;
            var supportedMembers = elementType.GetMembers(BindingFlags.Instance | BindingFlags.Public | filter).ToList().FindAll(x => IsSupportedMember(x));
            return restrict ?
                supportedMembers.FindAll(member => member is PropertyInfo property && ClassInfo.IsSupportedType(property.PropertyType)) :
                supportedMembers;
        }

        /// <summary>
        /// The records in the table
        /// </summary>
        public IEnumerable<IEnumerable<string?>> Records
        {
            get
            {
                if (Cache != null)
                {
                    var result = Cache;
                    Cache = null;
                    return result;
                }

                var recordList = new List<IEnumerable<string?>>();
                object? value;
                try
                {
                    value = PropertyInfo?.GetValue(ClassInfo.ClassInstance) ?? Collection;
                }
                catch (Exception ex)
                {
                    value = ex.Message;
                }
                if (value is System.Collections.IEnumerable enumerable)
                {
                    var elementType = enumerable.GetType().GetElementType();
                    elementType ??= enumerable.GetType().GetGenericArguments().FirstOrDefault();
                    if (elementType != null)
                    {
                        if (ClassInfo.IsSupportedType(elementType))
                        {
                            TitlesList ??= [Util.NameToLabel(Name)];
                            foreach (var item in enumerable)
                            {
                                recordList.Add([item?.ToString()]);
                            }
                        }
                        else if (elementType.IsValueType && elementType.IsGenericType && elementType.GetGenericTypeDefinition() == typeof(ValueTuple<,>))
                        {
                            // Elements is a ValueTuple
                            var fields = elementType.GetFields();
                            TitlesList ??= fields.Select(f => Util.NameToLabel(f.Name)).ToList();

                            foreach (var item in enumerable)
                            {
                                var newRecord = fields.Select(f => f.GetValue(item)?.ToString()).ToList();
                                recordList.Add(newRecord);
                            }
                        }
                        else
                        {
                            var members = RecordFields(elementType);
                            TitlesList ??= members.Select(member => Util.NameToLabel(member.Name)).ToList();
                            foreach (var item in enumerable)
                            {
                                var newRecord = members.Select(member =>
                                {
                                    if (member is PropertyInfo prop)
                                        return prop.GetValue(item)?.ToString();
                                    if (member is FieldInfo fld)
                                        return fld.GetValue(item)?.ToString();
                                    return null;
                                }).ToList();
                                recordList.Add(newRecord);
                            }
                        }
                    }
                }
                return recordList;
            }
        }
        private IEnumerable<IEnumerable<string?>>? Cache;
    }
}
