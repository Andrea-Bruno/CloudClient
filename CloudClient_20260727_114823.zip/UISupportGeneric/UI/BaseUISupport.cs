﻿using System.Reflection;
using System.Xml.Serialization;

namespace UISupportGeneric.UI
{
    /// <summary>
    /// Base class for elements representing the GUI
    /// </summary>
    public abstract class BaseUISupport : Element
    {
        internal BaseUISupport(string name, string? description, int order, ClassInfo classInfo, PropertyInfo? property = null) : base(name, description, order, classInfo, property)
        {
        }
        /// <summary>
        /// Unique identifier
        /// </summary>
        public string Id => GetHashCode().ToString("x8");

        private Exception? _exception;
        internal Exception? Exception
        {
            get => _exception;
            set
            {
                _exception = value;
                if (value == null)
                {
                    Error = null;
                    Tooltip = null;
                    return;
                }
                if (value.InnerException != null)
                    value = value.InnerException;
                Error = value?.Message + Environment.NewLine + value?.TargetSite?.Name;
                Tooltip = value?.ToString();
            }
        }
        /// <summary>
        /// Returns a real time validation error while editing an element
        /// </summary>
        /// <value>Description of the validation error</value>
        public string? ValidationError { get; internal set; }

        /// <summary>
        /// Validation error message of the entered value, if an invalid value has been entered
        /// </summary>
        public string? Error { get; internal set; }

        /// <summary>
        /// True if there is no error
        /// </summary>
        public bool Successful => Error == null;


        /// <summary>
        /// Additional information that can be viewed in the user interface
        /// </summary>
        public string? Tooltip { get; internal set; }

        /// <summary>
        /// Check if it can be represented in the user interface
        /// </summary>
        /// <param name="member">True if supported</param>
        /// <returns></returns>
        internal static bool IsSupportedMember(MemberInfo member)
        {
            var xmlIgnore = member.GetCustomAttributes(false).Any(a => a is XmlIgnoreAttribute);
            var hiddenFromGUI = member.GetCustomAttributes(false).Any(a => a is HiddenFromGUIAttribute);
            if (xmlIgnore || hiddenFromGUI)
            {
                return false;
            }

            if (member is PropertyInfo property)
            {
                if (!property.CanRead)
                    return false;
                if (ClassInfo.IsCustomType(property.PropertyType))
                    return true;
            }
            else if (member is MethodInfo method)
            {
                if (!(method.IsPublic && method.GetParameters().All(p => ClassInfo.IsSupportedType(p.ParameterType))))
                    return false;

            }
            return !member.Name.StartsWith("get_") && !member.Name.StartsWith("set_") && !(member.ReflectedType?.Namespace != null && member.ReflectedType.Namespace.StartsWith("System.")) && member?.DeclaringType != typeof(object);
        }
    }
}
