﻿using System.Reflection;

namespace UISupportGeneric.UI
{
    public class EventRedirect : Event
    {
        internal EventRedirect(ClassInfo classInfo, FieldInfo? field = null) : base(EventType.Redirect, classInfo, field)
        {
        }

        /// <summary>
        /// If set, the rendering engine must redirect the User to the GUI, at the specified Uri. This matches the current GUI with the one corresponding to the URI address.
        /// </summary>
        public Uri RedirectTo
        {
            get
            {
                if (Field?.IsStatic == true)
                {
                    // For static fields
                    return (Uri)Field.GetValue(null);
                }
                else
                {
                    // For instance fields
                    return (Uri)Field.GetValue(ClassInfo.ClassInstance);
                }
            }
        }

    }
}
