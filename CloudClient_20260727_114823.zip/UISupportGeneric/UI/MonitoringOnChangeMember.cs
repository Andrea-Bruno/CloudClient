using System.Diagnostics;

namespace UISupportGeneric.UI;

internal static class MonitoringOnChangeMember
{
    static MonitoringOnChangeMember()
    {
        // Timer = new Timer(CheckChanges);
        References = [];
    }

    private const int RefreshMs = 1000;
    public static bool AutoRefreshUIOnDataChange { get; set; } = true;
    private static void CheckChanges(object? state)
    {
        //Timer.Change(Timeout.Infinite, Timeout.Infinite);
        if (AutoRefreshUIOnDataChange == false)
            return;
        Thread.CurrentThread.Name = "UIMonitoring";
        lock (References)
        {
            foreach (var reference in References.ToArray())
            {
                if (reference.TryGetTarget(out var classInfo))
                {
                    if (classInfo.IsExpired)
                    {
                        References.Remove(reference);
                        continue;
                    }
                    classInfo.DetectIfElementIsChanges(true);
                }
                else
                {
                    References.Remove(reference);
                }
            }
        }
        //if (References.Count > 0)
            // Timer.Change(RefreshMs, Timeout.Infinite);
    }

    internal static void AddReference(ClassInfo classInfo)
    {
        lock (References)
        {
            if (References.Count == 0)
            {
                Run();
                // Timer.Change(RefreshMs, Timeout.Infinite);
            }
            var alreadyExists = false;
            foreach (var item in References)
            {
                if (!item.TryGetTarget(out var ci)) continue;
                if (ci != classInfo) continue;
                alreadyExists = true;
                break;
            }
            if (!alreadyExists)
                References.Add(new WeakReference<ClassInfo>(classInfo));
        }
    }

    private static void Run()
    {
        Task.Run(async () =>
        {
            while (true)
            {
                if (References.Count > 0)
                {
                    var start = DateTime.UtcNow;
                    CheckChanges(null);
                    var elapsed = (int)(DateTime.UtcNow - start).TotalMilliseconds;
                    var delay = RefreshMs - elapsed;
                    if (delay > 0)
                        await Task.Delay(delay);
                }
                else
                {
                    await Task.Delay(RefreshMs);
                }
            }
        });
    }


    private static readonly List<WeakReference<ClassInfo>> References;
    // private static readonly Timer Timer;
}