﻿
namespace System
{
    /// <summary>
    /// Do not display the item in the GUI
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class HiddenFromGUIAttribute : Attribute
    {
        public string Reason { get; }

        public HiddenFromGUIAttribute(string reason = "")
        {
            Reason = reason;
        }
    }

}