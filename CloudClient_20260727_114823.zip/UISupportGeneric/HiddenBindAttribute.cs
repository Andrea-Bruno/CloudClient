﻿namespace System
{
    /// <summary>
    /// The HiddenBindAttribute class allows properties in the GUI to be linked to a boolean element by name.
    /// If the referenced boolean is true, the GUI element associated with this property will be hidden.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, Inherited = false, AllowMultiple = false)]
    public class HiddenBindAttribute : Attribute
    {
        /// <summary>
        /// Gets the name of the boolean reference.
        /// </summary>
        public string Ref { get; }

        /// <summary>
        /// Initializes a new instance of the HiddenAttribute class with the specified reference name.
        /// </summary>
        /// <param name="ref">The name of the boolean reference.</param>
        public HiddenBindAttribute(string @ref)
        {
            Ref = @ref; // Sets the Ref property with the specified reference name.
        }
    }
}
