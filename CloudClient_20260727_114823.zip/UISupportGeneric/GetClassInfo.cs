﻿using UISupportGeneric.UI;
using static UISupportGeneric.UI.ClassInfo;

namespace UISupportGeneric
{
    public static partial class Util
    {

        /// <summary>
        /// Get a structure to represent and modify an object in a graphical interface
        /// </summary>
        /// <param name="instance">The class instance to analyze or type of static class</param>
        /// <param name="interfaceType">Specifies how the user interface will be used</param>
        /// <param name="onSave">You can specify an action to save the component. This action will be called automatically when the object needs to be saved</param>
        /// <returns>Object structure</returns>
        public static ClassInfo GetClassInfo(object instance, InterfaceType interfaceType = InterfaceType.RealTimeValidationNoSubmitButton, SaveAction? onSave = null)
        {
            return instance is Type type ? new ClassInfo(type, interfaceType, onSave) : new ClassInfo(instance, interfaceType, onSave);
        }

        /// <summary>
        /// Get a structure to represent and modify an static class in a graphical interface
        /// </summary>
        /// <param name="staticClass">The type of static class to analyze</param>
        /// <param name="interfaceType">Specifies how the user interface will be used</param>
        /// <param name="onSave">You can specify an action to save the component. This action will be called automatically when the object needs to be saved</param>
        /// <returns>Object structure</returns>
        public static ClassInfo GetClassInfo(Type staticClass, InterfaceType interfaceType = InterfaceType.AutoSave, SaveAction? onSave = null)
        {
            return new ClassInfo(staticClass, interfaceType, onSave);
        }
    }
}
