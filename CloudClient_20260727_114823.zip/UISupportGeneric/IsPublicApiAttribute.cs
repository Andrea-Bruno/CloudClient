﻿namespace System
{
    /// <summary>
    /// If set in a method used in APIs, disables RSA validation so that APIs are publicly accessible to anyone.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public class IsPubblicAPIAttribute : Attribute
    {
    }
}