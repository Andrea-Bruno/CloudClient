using System.Reflection;
using System.Xml.Linq;
using static UISupportGeneric.Util;

namespace UISupportGeneric;

public static class Analyzer
{
        /// <summary>
        /// Returns the md + json description of the methods in type
        /// </summary>
        /// <param name="type">The type containing the methods to analyze.</param>
        /// <param name="filter">An optional filter to apply to the method names.</param>
        /// <returns>A string containing the md + json description of the methods.</returns>
        public static string GeToolDefinitions(Type? type, string? filter = null)
        {
            if (type == null) return string.Empty;

            System.Xml.Linq.XDocument? Xml = GetXmlOfAssembly(type);

            bool IsPrimitiveType(Type returnType) => returnType == typeof(string) || returnType == typeof(decimal) || returnType.IsPrimitive;
            string GetReturnType(Type type) => IsPrimitiveType(type) ? type.Name : "JsonDocument";
            string GetJsonElementMethod(Type type) => type.Name switch
            {
                "Int32" => "Int32",
                "UInt32" => "UInt32",
                "Int64" => "Int64",
                "UInt64" => "UInt64",
                "Single" => "Single",
                "Double" => "Double",
                "Decimal" => "Decimal",
                "Boolean" => "Boolean",
                _ => "String"
            };

            System.Text.StringBuilder codeBuilder = new System.Text.StringBuilder();
            string className = $"{Assembly.GetEntryAssembly()?.GetName().Name}{type.Name}Client";

            // Helper: convert CamelCase/PascalCase to snake_case (simple approach)
            static string ToSnakeCase(string name)
            {
                if (string.IsNullOrEmpty(name)) return name;
                var sb = new System.Text.StringBuilder();
                for (int i = 0; i < name.Length; i++)
                {
                    var c = name[i];
                    if (char.IsUpper(c))
                    {
                        if (i > 0) sb.Append('_');
                        sb.Append(char.ToLowerInvariant(c));
                    }
                    else sb.Append(c);
                }
                return sb.ToString();
            }

            // Map parameter types to a simple json-type label used in placeholders
            static string ParamTypeLabel(Type t)
            {
                if (t == typeof(string)) return "string";
                if (t == typeof(bool)) return "boolean";
                if (t == typeof(int) || t == typeof(long) || t == typeof(short) || t == typeof(byte)) return "integer";
                if (t == typeof(float) || t == typeof(double) || t == typeof(decimal)) return "number";
                if (t.IsArray || (t.IsGenericType && typeof(System.Collections.IEnumerable).IsAssignableFrom(t))) return "array";
                return "object";
            }

            // Generate the requested md + json scheme per method (one blank line between entries)
            foreach (var method in type.GetMethods().Where(m => m.DeclaringType == type))
            {
                var parameters = method.GetParameters();
                string methodName = method.Name;
                bool isVoid = method.ReturnType == typeof(void);

                    System.Xml.Linq.XElement? xmlElement = null;
                int order;
                string? methodDescription = Xml != null ? GetMemberDescription(out order, method, Xml, out xmlElement) : null;

                // Header: method name in snake_case prefixed with '#'
                codeBuilder.AppendLine("#" + ToSnakeCase(methodName));

                // Method description lines
                if (string.IsNullOrWhiteSpace(methodDescription))
                {
                    codeBuilder.AppendLine($"Executes {methodName} API call.");
                }
                else
                {
                    var lines = methodDescription.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var line in lines)
                    {
                        codeBuilder.AppendLine(line.Trim());
                    }
                }

                // Return value description
                var returns = xmlElement?.Element("returns")?.Value;
                if (!string.IsNullOrWhiteSpace(returns))
                {
                    codeBuilder.AppendLine(returns.Trim());
                }
                else if (isVoid)
                {
                    codeBuilder.AppendLine("True if the operation was successful");
                }
                else
                {
                    codeBuilder.AppendLine($"Returns a {GetReturnType(method.ReturnType)} representation");
                }

                // json scheme:
                codeBuilder.AppendLine("json scheme:");
                var jsonObj = new System.Text.StringBuilder();
                jsonObj.AppendLine("{");
                // method entry
                jsonObj.AppendLine($"\"method\": \"{ToSnakeCase(methodName)}\",");

                // parameters
                for (int i = 0; i < parameters.Length; i++)
                {
                    var p = parameters[i];
                    // Try to get a param description from XML
                    string? paramDesc = Xml != null ? GetParameterDescription(out order, p, Xml, out xmlElement) : null;
                    var label = ParamTypeLabel(p.ParameterType);
                    var descText = !string.IsNullOrWhiteSpace(paramDesc) ? paramDesc.Trim() : p.Name;
                    var placeholder = $"{{{{{label}: {descText}}}}}"; // e.g. {{string: recipient email}}
                    var comma = i == parameters.Length - 1 ? string.Empty : ",";
                    jsonObj.AppendLine($"\"{p.Name}\": \"{placeholder}\"{comma}");
                }

                jsonObj.AppendLine("}");

                // Indent json block properly in the output
                foreach (var line in jsonObj.ToString().Split(new[] { "\r\n", "\n" }, StringSplitOptions.None))
                {
                    codeBuilder.AppendLine(line);
                }

                // Separate methods with an empty line
                codeBuilder.AppendLine();
            }

            return codeBuilder.ToString();
        }
}
