﻿using System.ComponentModel;
using System.Diagnostics;
using System.Net;
using System.Net.Mail;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;
using System.Xml.Serialization;
using UISupportGeneric.UI;
using static System.Environment;

namespace UISupportGeneric
{
    /// <summary>
    /// Collection of utilities: Useful functions for creating and managing both graphical and terminal user interfaces
    /// </summary>
    public static partial class Util
    {
        /// <summary>
        /// Generates a new RSA key pair for asymmetric encryption and digital signatures
        /// </summary>
        /// <param name="keySize">RSA key size in bits (default: 2048, recommended: 2048 or 4096 for enhanced security)</param>
        /// <returns>A tuple containing (PrivateKey, PublicKey) in PEM format ready for use</returns>
        /// <example>
        /// <code>
        /// // Generate a new key pair
        /// var (privateKey, publicKey) = UISupportGeneric.Util.GenerateRsaKeyPair();
        /// 
        /// // Store privateKey securely on client side for signing API requests
        /// // Store publicKey on server side for signature verification
        /// 
        /// Console.WriteLine("Private Key (keep secret):");
        /// Console.WriteLine(privateKey);
        /// Console.WriteLine("\nPublic Key (share with server):");
        /// Console.WriteLine(publicKey);
        /// </code>
        /// </example>
        public static (string PrivateKey, string PublicKey) GenerateRsaKeyPair(int keySize = 2048)
        {
            using var rsa = RSA.Create(keySize);
            var privateKey = rsa.ExportRSAPrivateKeyPem();
            var publicKey = rsa.ExportRSAPublicKeyPem();
            return (privateKey, publicKey);
        }

        internal static string? GetMemberDescription(out int order, MemberInfo member, XDocument? xml, out XElement? xmlElement)
        {
            xmlElement = GetXElement(out order, member, xml);
            return XElementDescription(xmlElement);
            //  return GetElementDescription(xmlElement);
        }

        private static readonly Dictionary<string, XDocument> CacheXmlOfAssembly = [];

        internal static XDocument? GetXmlOfAssembly(Type type)
        {

            var assem = Assembly.GetAssembly(type);
            var dll = assem?.Location;
            var xmlNameFile = dll?[..^3] + "xml";
            return GetXmlOfAssembly(xmlNameFile);
        }

        private static XDocument? GetXmlOfAssembly(string xmlNameFile)
        {
            lock (CacheXmlOfAssembly)
            {
                if (CacheXmlOfAssembly.ContainsKey(xmlNameFile))
                    return CacheXmlOfAssembly[xmlNameFile];
                XDocument? xml = null;
                try
                {
                    if (File.Exists(xmlNameFile))
                        xml = XDocument.Load(xmlNameFile);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex);
                    Debugger.Break();
                }

                if (xml != null)
                    CacheXmlOfAssembly.Add(xmlNameFile, xml);
                return xml;
            }
        }

        /// <summary>
        /// Get if the type is used to represent numeric values
        /// </summary>
        /// <param name="type">Type</param>
        /// <returns>True if the type is used to represent numeric values</returns>
        internal static bool IsNumeric(Type type)
        {
            return type.IsPrimitive && type != typeof(char) && type != typeof(bool);
        }

        internal static XElement? GetXElement(out int order, MemberInfo member, XDocument? xml)
        {
            if (xml != null)
            {
                string? add = null;
                if (member as MethodInfo != null)
                {
                    foreach (var param in ((MethodInfo)member).GetParameters())
                    {
                        if (add != null)
                            add += ",";
                        add += TypeToXmlDocName(param.ParameterType);
                    }

                    if (add != null)
                        add = "(" + add + ")";
                }

                var suffix = member.MemberType.ToString()[0] + ":";
                var memberName = suffix + member.DeclaringType?.FullName?.Replace('+', '.') + "." + member.Name + add;
                return GetXElementByName(out order, xml, memberName);
            }

            order = 0;
            return null;
        }

        /// <summary>
        /// Converts a <see cref="Type"/> to its XML documentation-compatible string representation.
        /// Reflection's <c>Type.ToString()</c> uses backtick+square-bracket notation for generics
        /// (e.g. <c>List`1[System.String]</c>) and plus signs for nested types (<c>Outer+Inner</c>),
        /// while the compiler-generated XML doc file uses curly braces (<c>List{System.String}</c>)
        /// and dots (<c>Outer.Inner</c>). This method bridges the gap so that
        /// <see cref="GetXElement"/> can find the matching member in the XML doc file.
        /// </summary>
        private static string TypeToXmlDocName(Type type)
        {
            if (type.IsGenericType)
            {
                var mainName = type.GetGenericTypeDefinition().FullName ?? type.Name;
                var backtickIndex = mainName.IndexOf('`');
                if (backtickIndex > 0)
                    mainName = mainName[..backtickIndex];
                var args = string.Join(",", type.GetGenericArguments().Select(TypeToXmlDocName));
                return $"{mainName}{{{args}}}";
            }
            if (type.IsNested)
                return $"{type.DeclaringType!.FullName}.{type.Name}";
            return type.FullName ?? type.Name;
        }

        private static XElement? GetXElementByName(out int order, XDocument xml, string memberName)
        {
            order = 0;
            var xMembers = xml.Element("doc")?.Element("members");
            if (xMembers != null)
                foreach (var xMember in xMembers.Elements())
                {
                    order++;
                    if (xMember.Attribute("name")?.Value == memberName)
                    {
                        return xMember;
                    }
                }

            order = 0;
            return null;
        }

        /// <summary>
        /// Get a member's description
        /// </summary>
        /// <param name="xmlElement">Return back the XElement of member</param>
        /// <returns>A textual description</returns>
        private static string? GetElementDescription(XElement? xmlElement)
        {
            string? description = null;
            if (xmlElement != null)
            {
                var summary = xmlElement.Element("summary")?.Value;
                description = Trim(summary);
                var returns = xmlElement.Element("returns")?.Value;
                if (returns != null)
                    description += "\n\treturns: " + Trim(returns);
            }

            return description;
        }

        internal static string? XElementDescription(XElement? xNode)
        {
            if (xNode == null)
                return null;
            var block = xNode.Name.LocalName == "param" ? xNode : xNode.Element("summary");
            if (block == null)
                return null;

            // Walk child nodes to convert <see cref="T:TypeName" /> → "TypeName"
            // and <paramref name="foo" /> → "foo" instead of stripping them silently.
            var resultText = new StringBuilder();
            foreach (var node in block.Nodes())
            {
                switch (node)
                {
                    case XText text:
                        resultText.Append(text.Value);
                        break;
                    case XElement elem when elem.Name == "see":
                        var cref = elem.Attribute("cref")?.Value;
                        if (cref != null)
                        {
                            // cref format: "M:Namespace.Class.Method(...)" or "T:Namespace.Type"
                            // Extract just the member/type name (last segment before parenthesis)
                            var lastSegment = cref.Split('.')[^1];
                            var parenIdx = lastSegment.IndexOf('(');
                            resultText.Append(parenIdx > 0 ? lastSegment[..parenIdx] : lastSegment);
                        }
                        break;
                    case XElement elem when elem.Name == "paramref":
                        resultText.Append(elem.Attribute("name")?.Value ?? "");
                        break;
                    case XElement elem when elem.Name == "inheritdoc":
                        // Keep existing behaviour for inheritdoc
                        goto default;
                    default:
                        // For any other element, include its text content
                        if (node is XElement other)
                            resultText.Append(other.Value);
                        break;
                }
            }

            // Convert the node-walked result to a string for the remaining processing
            var result = resultText.ToString();

            var elements = block.Elements();
            foreach (var node in elements)
                if (node.Name == "inheritdoc")
                {
                    var cref = node.Attribute("cref")?.Value;
                    if (cref != null)
                    {
                        // var preamble = cref.Substring(0, 2);
                        var parts = cref.Substring(2).Split('.');
                        var xmlFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, parts[0] + ".xml");
                        var xml = GetXmlOfAssembly(xmlFile);
                        if (xml != null)
                        {
                            var element = GetXElementByName(out var _, xml, cref);
                            result += GetElementDescription(element);
                        }
                    }
                }

            return string.Join("\r\n",
                result.Replace("\r", "")
                    .Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)); // trim each line
        }

        /// <summary>
        /// Get a property's description
        /// </summary>
        /// <param name="order">Position of the element in the xml structure</param>
        /// <param name="parameter">Parameter info</param>
        /// <param name="xml">The xml generated by the compiler and loaded into an XDocument instance</param>
        /// <param name="xmlElement">Return back the XElement of member</param>
        /// <returns>A textual description</returns>
        internal static string? GetParameterDescription(out int order, ParameterInfo parameter, XDocument? xml, out XElement? xmlElement)
        {
            xmlElement = GetXElement(out order, parameter.Member, xml);
            if (xmlElement != null)
            {
                var elements = xmlElement.Elements("param");
                foreach (var param in elements)
                    if (param.Attribute("name")?.Value == parameter.Name)
                    {
                        return XElementDescription(param);
                        //return param.Value;
                    }
            }

            return null;
        }

        /// <summary>
        /// Get the class comment inserted in the source code
        /// </summary>
        /// <param name="order">Position of the element in the xml structure</param>
        /// <param name="type">Type of class</param>
        /// <param name="xml">The xml generated by the compiler and loaded into an XDocument instance</param>
        /// <returns>A textual description</returns>
        internal static string? GetClassDescription(out int order, Type type, XDocument? xml = null)
        {
            order = 0;
            xml ??= GetXmlOfAssembly(type);
            if (xml == null)
                return null;
            var memberName = "T:" + type.FullName?.Replace('+', '.');
            var xMembers = xml.Element("doc")?.Element("members");
            XElement? element = null;
            var elements = xMembers?.Elements();
            if (elements != null)
                foreach (var x in elements)
                {
                    order++;
                    if (x.Attribute("name")?.Value == memberName)
                    {
                        element = x;
                        break;
                    }
                }

            order = element == null ? 0 : order;
            return Trim(element?.Element("summary")?.Value);
        }

        /// <summary>
        /// Password vulnerability levels
        /// </summary>
        public enum PasswordVulnerabilityLevel
        {
#pragma warning disable
            VeryStrong = 0,
            Strong = 1,
            Medium = 2,
            Weak = 3,
            VeryWeak = 4,
            Blank = 5,
#pragma warning restore
        }

        /// <summary>
        /// Evaluate the vulnerability of a password to a brute force attack
        /// </summary>
        /// <param name="password"></param>
        /// <returns>Vulnerability level</returns>
        public static PasswordVulnerabilityLevel CheckPasswordStrength(string? password)
        {
            if (string.IsNullOrEmpty(password))
                return (PasswordVulnerabilityLevel)5;
            int score = 0;
            if (password.Length >= 8)
                score++;
            if (password.Length >= 12)
                score++;
            if (password.Any(char.IsDigit))
                score++;
            if (password.Any(char.IsUpper))
                score++;
            if (password.Any(char.IsLower))
                score++;
            if (password.Any(c => !char.IsLetterOrDigit(c)))
                score++;
            int vulnerabilityLevel = 5 - Math.Min(score, 5);

            return (PasswordVulnerabilityLevel)vulnerabilityLevel;
        }

        private static string? Trim(string? text)
        {
            if (text == null) return null;
            var lines = text.Split(['\r', '\n']);
            var result = new StringBuilder();
            foreach (var line in lines)
            {
                var trimmed = line.Trim();
                if (trimmed.Length > 0)
                    result.AppendLine(trimmed);
            }
            return result.ToString();
        }


        /// <summary>
        /// Converts a variable or class name in camel case to a label. Example "EntryPoint" -> "Entry point" 
        /// </summary>
        /// <param name="name">Name in CamelCase</param>
        /// <param name="firstUpper">Returns a string with the first letter capitalized</param>
        /// <returns>Text for label</returns>
        public static string NameToLabel(string name, bool firstUpper = true)
        {
            var endUpper = new StringBuilder();
            for (var i = name.Length - 1; i >= 0; i--)
            {
                var c = name[i];
                if (char.IsUpper(c))
                    endUpper.Insert(0, c);
                else
                    break;
            }

            if (endUpper.Length > 0)
            {
                name = name.Substring(0, name.Length - endUpper.Length);
                endUpper.Insert(0, ' ');
            }

            var sb = new StringBuilder();
            bool l0;
            bool? l1 = null;
            bool? l2 = null;
            foreach (var c in name)
            {
                l0 = char.IsUpper(c);
                if (l0)
                {
                    if (l1 != null)
                        sb.Append(' ');
                }
                else
                {
                    if (l1 == true & l2 == true)
                        sb.Insert(sb.Length - 1, ' ');
                }

                if (c == '_')
                {
                    if (sb.Length > 0)
                        sb.Append(' ');
                }
                else
                    sb.Append(char.ToLower(c));

                l2 = l1;
                l1 = l0;
            }

            if (firstUpper && sb.Length > 0)
                sb[0] = char.ToUpper(sb[0]);
            return sb + endUpper.ToString();
        }

        public enum SecurityType
        {
            None,      // No encryption
            Ssl_Tls,   // SSL/TLS encryption
            StartTls   // STARTTLS encryption
        }


        /// <summary>
        /// Routine for sending an e-mail
        /// </summary>
        /// <param name="from">The sender's email address</param>
        /// <param name="to">The recipient's email address</param>
        /// <param name="subject">The subject of the email</param>
        /// <param name="body">The body content of the email</param>
        /// <param name="username">Optional: Username for SMTP server authentication</param>
        /// <param name="password">Optional: Password for SMTP server authentication</param>
        /// <param name="smtpServer">Optional: The SMTP server address</param>
        /// <param name="port">The port used for the SMTP connection (default is 587)</param>
        /// <param name="securityType">The type of security for the SMTP connection</param>
        /// <param name="attachments">Optional list of attachments as file name and byte array</param>
        public static void SendEmail(
        string from,
        string to,
        string subject,
        string body,
        string? username = null,
        string? password = null,
        string? smtpServer = null,
        int port = 587,
        SecurityType securityType = SecurityType.StartTls,
        IEnumerable<(string FileName, byte[] Data)>? attachments = null)
        {
            using var mailMessage = new MailMessage(from, to, subject, body);
            if (attachments != null)
            {
                foreach (var attachment in attachments)
                {
                    var stream = new MemoryStream(attachment.Data);
                    mailMessage.Attachments.Add(new Attachment(stream, attachment.FileName));
                }
            }
            using var client = new SmtpClient(smtpServer, port);
            if (!string.IsNullOrEmpty(username) || !string.IsNullOrEmpty(password))
            {
                client.Credentials = new NetworkCredential(username, password);
            }
            client.EnableSsl = securityType != SecurityType.None;
            client.Send(mailMessage);
        }

        /// <summary>
        /// Get all the classes that are in a namespace.
        /// Useful function when you want to display a whole series of panels corresponding to static classes under a single namespace.
        /// </summary>
        /// <param name="nameSpace">Root namespace of the classes to search for.</param>
        /// <param name="assembly">The assembly in which the namespace is contained. Tip: Use Assembly.GetExecutingAssembly() to get the current assembly.</param>
        /// <param name="onlyStatic">Filter static classes only</param>
        /// <returns></returns>
        internal static Type[] GetAllClassesInNamespace(string nameSpace, Assembly? assembly = default, bool onlyStatic = true)
        {
            //if (assembly == null)
            //    CallerAssemblyNamespace(out assembly, ref nameSpace);

            Type[]? classes;
            if (assembly == null)
            {
                return Array.Empty<Type>();
            }

            var key = assembly.ManifestModule.ModuleVersionId + " " + nameSpace;
            lock (CacheTypesAtNamespace)
            {
                if (!CacheTypesAtNamespace.TryGetValue(key, out classes))
                {
                    List<Type> list = [];
                    foreach (var t in assembly.GetTypes())
                    {
                        if ((!onlyStatic || IsStaticClass(t)) && t.IsClass && string.Equals(t.Namespace, nameSpace, StringComparison.Ordinal)) list.Add(t);
                    }
                    classes = list.ToArray();
                    CacheTypesAtNamespace.Add(key, classes);
                }
            }
            return classes;
        }

        private static readonly Dictionary<string, Type[]> CacheTypesAtNamespace = [];

        /// <summary>
        /// NOTE: This function does not work in all cases when compiled in release mode
        /// </summary>
        /// <param name="assembly"></param>
        /// <param name="nameSpace"></param>
        private static void CallerAssemblyNamespace(out Assembly? assembly, ref string? nameSpace)
        {

            Assembly? callerAssembly = null;
            var thisAssembly = Assembly.GetExecutingAssembly();
            StackFrame? sf = null;
            foreach (var frame in new StackTrace().GetFrames()
                         .Where(x =>
                         {
                             var method = x.GetMethod();
                             callerAssembly = method?.DeclaringType?.Assembly;
                             return callerAssembly != thisAssembly;
                         }))
            {
                sf = frame;
                break;
            }
            assembly = callerAssembly;
            nameSpace ??= sf?.GetMethod()?.DeclaringType?.Namespace;
        }

        /// <summary>
        /// Get class information suitable for creating panels, from a specific namespace.
        /// Useful function when you want to display a whole series of panels corresponding to static classes under a single namespace.
        /// </summary>
        /// <param name="nameSpace">Root namespace of the classes to search for.</param>
        /// <param name="assembly">The assembly in which the namespace is contained. Tip: Use Assembly.GetExecutingAssembly() to get the current assembly.</param>
        /// <returns></returns>
        public static List<ClassInfo> GetAllClassInfoInNamespace(string nameSpace, Assembly assembly)
        {

            lock (CacheClassAtNameSpace)
            {
                if (assembly == null)
                {
                    assembly = NamespaceToAssembly(nameSpace);
                    // assembly = Assembly.GetEntryAssembly();
                    // CallerAssemblyNamespace(out assembly, ref nameSpace);
                }
                var key = assembly?.ManifestModule.ModuleVersionId + " " + nameSpace;
                if (CacheClassAtNameSpace.TryGetValue(key, out var classes))
                {
                    return classes;
                }

                var result = (from type in GetAllClassesInNamespace(nameSpace, assembly)
                              where type.DeclaringType == null
                              select new ClassInfo(type)
                    into classInfo
                              where !classInfo.IsEmpty
                              select classInfo).ToList();
                CacheClassAtNameSpace.Add(key, result);
                return result;
            }
        }

        /// <summary>
        /// Get the most likely assembly for a namespace
        /// </summary>
        /// <param name="nameSpace"></param>
        /// <returns></returns>
        public static Assembly? NamespaceToAssembly(string nameSpace)
        {
            var ns = nameSpace.Split('.').First();
            var result = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(x => x.GetName().Name == ns);
            if (result != null)
                return result;
            // Per .NET Core 3.0+ e .NET 5+
            AssemblyLoadContext defaultContext = AssemblyLoadContext.Default;
            return defaultContext.LoadFromAssemblyName(new AssemblyName(ns));
        }

        private static readonly Dictionary<string, List<ClassInfo>> CacheClassAtNameSpace = [];

        private static string ClassFileName(Type type)
        {
            // NOTE: The suitable SpecialFolder.CommonApplicationData get a error administrative permission in Linux with WSL
            // and the symbol SpecialFolder.ApplicationData don't get a valid path
            var commonPath = Path.Combine(GetFolderPath(SpecialFolder.LocalApplicationData), nameof(UISupportGeneric));
            if (!Directory.Exists(commonPath))
                Directory.CreateDirectory(commonPath);
            var fileName = type.GUID.ToString();
            return Path.Combine(commonPath, fileName);
        }

        /// <summary>
        /// Load the saved values of a static class
        /// </summary>
        /// <param name="staticClass"></param>
        /// <returns>Outcome of the operation</returns>
        public static bool Load(Type? staticClass = null)
        {
            var callerType = staticClass ?? new StackTrace().GetFrames()[1].GetMethod()?.DeclaringType;
            var fileName = callerType == null ? null : ClassFileName(callerType);
            if (callerType == null || !IsStaticClass(callerType))
                throw new Exception(IsNotStaticClass);
            try
            {
                if (!File.Exists(fileName))
                    return false;
                //string xml;
                //using (var stream = File.OpenText(fileName))
                //{
                //    xml = stream.ReadToEnd();
                //}
                var xDoc = XDocument.Load(fileName);
                XmlToClass(callerType, xDoc);
                return true;
            }
            catch (Exception ex)
            {
#if DEBUG
                if (fileName != null)
                    File.Delete(fileName);
#endif
                Debugger.Break();
                Console.Write(ex);
            }

            return false;
        }

        /// <summary>
        /// Save the values of a static class
        /// </summary>
        /// <param name="staticClass"></param>
        /// <returns>Outcome of the operation</returns>
        public static bool Save(Type? staticClass = null)
        {
            try
            {
                var callerType = staticClass ?? new StackTrace().GetFrames()[1].GetMethod()?.DeclaringType;
                if (callerType == null)
                    return false;
                if (!IsStaticClass(callerType))
                    throw new Exception(IsNotStaticClass);
                var xDoc = ClassToXml(callerType);
                xDoc?.Save(ClassFileName(callerType));
                return true;
            }
            catch (Exception ex)
            {
                Console.Write(ex);
            }

            return false;
        }

        /// <summary>
        /// Serialize a static type into an xml structure
        /// </summary>
        /// <param name="type">Static type class</param>
        /// <param name="instance">Class instance (leave null if class is static)</param>
        /// <param name="restrictTo">Specifies whether to consider: static, non-static or both members (default both)</param>
        /// <param name="x">Used internally for recursive purposes (leave null)</param>
        private static XDocument? ClassToXml(Type type, object? instance = null,
            BindingFlags restrictTo = BindingFlags.Instance | BindingFlags.Static, XElement? x = null)
        {
            restrictTo |= BindingFlags.Public;
            XDocument? doc = null;
            if (x == null)
            {
                x = new XElement("root");
                doc = new XDocument(x);
            }

            foreach (var member in type.GetProperties(restrictTo))
            {
                var xmlIgnore = member.GetCustomAttributes(false).Any(a => a is XmlIgnoreAttribute);
                if (!xmlIgnore)
                {
                    if (!(member.PropertyType == typeof(string)) && member.PropertyType.IsClass && member.CanRead)
                    {
                        var node = new XElement(member.Name);
                        x?.Add(node);
                        ClassToXml(member.PropertyType, member.GetValue(instance), restrictTo, node);
                    }
                    else if (member.CanRead && member.CanWrite)
                    {
                        var value = member?.GetValue(instance)?.ToString();
                        if (member == null) continue;
                        var element = new XElement(member.Name, value);
                        x?.Add(element);
                        if (value == null)
                            element.SetAttributeValue("IsNull", true);
                    }
                }
            }

            return doc;
        }

        /// <summary>
        /// Deserialize a static type from xml structure
        /// </summary>
        /// <param name="type">Static type class</param>
        /// <param name="x">The xml structure from which to retrieve values to restore a static class</param>
        /// <param name="instance">Class instance (leave null if class is static)</param>
        /// <param name="restrictTo">Specifies whether to consider: static, non-static or both members (default both)</param>
        private static void XmlToClass(Type type, XContainer x, object? instance = null,
            BindingFlags restrictTo = BindingFlags.Instance | BindingFlags.Static)
        {
            restrictTo |= BindingFlags.Public;
            if (x is XDocument doc)
            {
                if (doc.Root != null)
                    x = doc.Root;
            }

            var elements = x.Nodes().ToList();
            foreach (var member in type.GetProperties(restrictTo))
            {
                var xmlIgnore = member.GetCustomAttributes(false).Any(a => a is XmlIgnoreAttribute);
                if (!xmlIgnore)
                {
                    if (!(member.PropertyType == typeof(string)) && member.PropertyType.IsClass && member.CanRead)
                    {
                        if (elements.Find(item => ((XElement)item).Name == member.Name) is XElement element)
                        {
                            XmlToClass(member.PropertyType, element, member.GetValue(instance), restrictTo);
                        }
                    }
                    else if (member.CanRead && member.CanWrite)
                    {
                        if (elements.Find(item => ((XElement)item).Name == member.Name) is XElement element)
                        {
                            object? val = null;
                            if (element.Attribute("IsNull") == null)
                            {
                                if (member.PropertyType.IsEnum)
                                    val = Enum.Parse(member.PropertyType, element.Value);
                                else
                                    val = Convert.ChangeType(element.Value, member.PropertyType);
                            }
                            try
                            {
                                member.SetValue(instance, val);
                            }
                            catch (Exception ex)
                            {
                                Debug.Write(ex.Message);
                            }
                        }
                    }
                }
            }
        }

        private const string IsNotStaticClass = "The type is not a static class";

        /// <summary>
        /// Determines if the type is a static class
        /// </summary>
        /// <param name="type"></param>
        /// <returns>True, if it is a static class</returns>
        public static bool IsStaticClass(Type type)
        {
            return type.IsAbstract && type.IsSealed && type.IsClass;
        }

        /// <summary>
        /// Finds the enumerator whose name is contained in either the name or description
        /// </summary>
        /// <param name="enumType"></param>
        /// <param name="name"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        internal static object? FindEnumerator(Type enumType, string name, string? description)
        {
            var wordsList = new List<Tuple<object, string[]>>();
            foreach (var item in Enum.GetValues(enumType))
            {
                var words = Enum.GetName(enumType, item)?.Split('_');
                if (words != null)
                    wordsList.Add(new Tuple<object, string[]>(item, words));
            }

            wordsList.Sort((x, y) => x.Item2.Length - y.Item2.Length);
            Tuple<object, string[]>? result = null;
            name = name.ToLower();
            result = wordsList.FirstOrDefault(x => ContainsOneOfTheseWords(name, x.Item2, true));
            if (result == null && description != null)
            {
                description = description.ToLower();
                result = wordsList.FirstOrDefault(x => ContainsOneOfTheseWords(description, x.Item2, true));
            }

            return result?.Item1;
        }

        internal static bool ContainsOneOfTheseWords(string[] wheresLowercase, string[] findLowercase, bool startWith = false)
        {
            foreach (var whereLowercase in wheresLowercase)
            {
                if (ContainsOneOfTheseWords(whereLowercase, findLowercase, startWith))
                    return true;
            }
            return false;
        }

        internal static bool ContainsOneOfTheseWords(string whereLowercase, string[] findLowercase, bool startWith = false)
        {
            return findLowercase.Any(x => ContainsWord(whereLowercase, x, startWith));
        }

        internal static bool ContainsWord(string? textLowercase, string wordLowercase, bool startWith = false)
        {
            if (textLowercase == null)
                return false;
            var p = textLowercase.IndexOf(wordLowercase, StringComparison.Ordinal);
            if (p != -1)
            {
                if (p == 0 || !char.IsLetter(textLowercase[p - 1]))
                {
                    if (startWith)
                        return true;
                    var e = p + wordLowercase.Length;
                    if (e >= textLowercase.Length || !char.IsLetter(textLowercase[e]))
                        return true;
                }
            }
            return false;
        }

        static internal bool IsEditable(PropertyInfo property)
        {
            var isReadOnly = property.GetCustomAttributes(false).OfType<ReadOnlyAttribute>().Any(a => a.IsReadOnly);
            return isReadOnly ? false : property.CanWrite && (property.SetMethod != null && property.SetMethod.IsPublic);
        }


        /// <summary>
        /// Get the icon in svg format (vector image)
        /// </summary>
        /// <param name="icon">The icon</param>
        /// <param name="style">Additional style attributes</param>
        /// <returns>svg vector data</returns>
        public static string GetIcon(Icons.OpenIonic icon, string style = null)
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourcePath = $"{assembly.GetName().Name.Replace("/", ".")}.{"Icons." + icon.ToString().Replace("_", "-") + ".svg"}";

            using Stream stream = assembly.GetManifestResourceStream(resourcePath);
            using StreamReader reader = new StreamReader(stream);
            var svgContent = reader.ReadToEnd();
            if (!string.IsNullOrEmpty(style))
                svgContent = svgContent.Replace("<svg", $"<svg style=\"{style}\"");
            return svgContent;
        }

        /// <summary>
        /// Validate an instance of an object
        /// </summary>
        /// <param name="ClassInstance">Instance of class to validate</param>
        /// <param name="validationErrorsReport">A validation error report consisting of a dictionary with the field name and the error message</param>
        /// <returns>True the field validation was successful</returns>
        public static bool ValidateClass(object ClassInstance, out Dictionary<string, string> validationErrorsReport)
        {
            return ValidateClass(ClassInstance.GetHashCode(), out validationErrorsReport);
        }


        /// <summary>
        /// Validate an instance of an object
        /// </summary>
        /// <param name="staticType">Type of static class to validate</param>
        /// <param name="validationErrorsReport">A validation error report consisting of a dictionary with the field name and the error message</param>
        /// <returns>True the field validation was successful</returns>
        public static bool ValidateClass(Type staticType, out Dictionary<string, string> validationErrorsReport)
        {
            if (!IsStaticClass(staticType))
                throw new Exception("The class is not static!");
            return ValidateClass(staticType.GetHashCode(), out validationErrorsReport);
        }

        private static bool ValidateClass(int id, out Dictionary<string, string> validationErrorsReport)
        {
            validationErrorsReport = [];
            if (ClassInfo.TryGetInstance(id, out var classInfo))
            {
                return classInfo.Validate(validationErrorsReport);
            }
            return false;
        }

        /// <summary>
        /// Get the namespace that ends as specified part
        /// </summary>
        /// <param name="assembly">Assembly</param>
        /// <param name="endWith">End part of namespace</param>
        /// <returns>Namespace that ends as specified part or null if not found</returns>
        public static string? GetNamespace(Assembly assembly, string endWith = ".Panels")
        {
            try
            {
                Type[] types = assembly.GetTypes();
                foreach (Type type in types)
                {
                    if (type.Namespace != null && type.Namespace.EndsWith(endWith))
                    {
                        return type.Namespace;
                    }
                }
            }
            catch
            {
            }
            return null;
        }
    }




}
