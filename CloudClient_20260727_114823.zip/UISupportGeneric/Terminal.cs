﻿using System.Diagnostics;
using System.Reflection;
using System.Text.Json;
using System.Xml.Linq;
using UISupportGeneric.Resources;

namespace UISupportGeneric
{
    /// <summary>
    /// Class for the creation of a terminal capable of executing the methods contained in the classes via the command line,
    /// </summary>
    public static class Terminal
    {
        private static IEnumerable<MethodInfo> GetMethods(Type type) => type.GetMethods().Where(x => x.IsPublic && x.DeclaringType != typeof(object));

        /// <summary>
        /// Execute a method of a class calling it by name. Useful function for executing commands from the terminal.
        /// </summary>
        /// <param name="command">Method name</param>
        /// <param name="type">Class type of method to execute</param>
        /// <returns>If the method is a function, then it returns the result</returns>
        public static string? ExecuteMethod(string command, Type? type)
        {
            type ??= new StackTrace().GetFrames()[1].GetMethod()?.DeclaringType;
            if (type == null)
                return null;
            var parts = SplitCommand(command);
            if (parts.Length == 0)
                return null;
            if (parts.Last() == "?")
            {
                var list = new List<string>(parts);
                list.RemoveAt(list.Count - 1);
                list.Insert(0, "?");
                parts = list.ToArray();
            }
            var methodName = parts[0];
            if (methodName.Trim() == "?")
                methodName = "Help";
            var parameters = parts.Skip(1).ToArray();
            var method = type.GetMethod(methodName);
            if (method == null)
                foreach (var item in type.GetMethods())
                    if (string.Compare(item.Name, methodName, StringComparison.OrdinalIgnoreCase) == 0)
                    {
                        method = item;
                        break;
                    }
            var param = new List<object?>();
            var n = 0;
            if (method == null)
                return "command does not exist";
            foreach (var p in method.GetParameters())
            {
                if (n < parameters.Length)
                {
                    var paramLiteral = parameters[n];
                    if (paramLiteral == "")
                        param.Add(null);
                    else
                    {
                        paramLiteral = paramLiteral.Trim('"');
                        param.Add(Convert.ChangeType(paramLiteral, p.ParameterType));
                    }
                }
                else
                {
                    param.Add(null);
                }
                n++;
            }
            object? result;
                try
                {
                    result = method?.Invoke(null, param.ToArray());
                    if (result == null)
                        return "null (No value)";
                }
                catch (Exception ex)
                {
                    return Dictionary.Error + ": " + ex.Message;
                }
            //var resultType = result.GetType();
            //var resultTypeInfo = resultType?.GetTypeInfo();
            return ObjToString(result);
        }

        internal static string? ObjToString(object? obj)
        {
            //if (obj is Task task)
            //{
            //    object result = null;
            //    var taskType = task.GetType();
            //    if (taskType.IsGenericType)
            //    {
            //        var resultProperty = taskType.GetProperty("Result");
            //        if (resultProperty != null)
            //        {
            //            result = resultProperty.GetValue(task);
            //        }
            //    }
            //    obj = result;
            //}
            if (obj == null)
                return null;
            var resultType = obj.GetType();
            if (resultType == typeof(void))
                return Dictionary.CommandSuccessfully;
            var resultTypeInfo = resultType.GetTypeInfo();

            if (resultType == typeof(string) || (resultTypeInfo.IsPrimitive))
                return Convert.ChangeType(obj, typeof(string)) as string;
            return JsonSerializer.Serialize(obj);
        }

        private static string[] SplitCommand(string command)
        {
            command = command.TrimStart();

            var result = new List<string>();
            if (!string.IsNullOrEmpty(command))
            {
                var part = "";
                var inside = false;
                foreach (var c in command)
                {
                    if (c == '"')
                        inside = !inside;
                    else
                    {
                        if (inside)
                            part += c;
                        else
                        {
                            if (c == ' ')
                            {
                                result.Add(part);
                                part = "";
                            }
                            else
                                part += c;
                        }
                    }
                }
                result.Add(part);
            }
            return result.ToArray();
        }

        /// <summary>
        /// Ask for information on the commands available from the terminal
        /// </summary>
        /// <param name="commandName">The name of the order you want information about. If this parameter is omitted, a list of all available commands will be obtained</param>
        /// <param name="type">Class type</param>
        /// <returns>Returns the list of commands and their syntax</returns>
        public static string? Help(string? commandName, Type? type = null)
        {
            type ??= new StackTrace().GetFrames()[1].GetMethod()?.DeclaringType;
            return type == null ? null : GetMethodInfo(type, commandName?.Trim());
        }

        /// <summary>
        /// Get an array with all method names
        /// </summary>
        /// <param name="type">Class type</param>
        /// <returns>String array with all method names</returns>
        public static string[] GetNameMethods(Type type)
        {
            return GetMethods(type).Select(m => m.Name).ToArray();
        }

        /// <summary>
        /// Get a description of the method for use from the terminal
        /// </summary>
        /// <param name="method">Method</param>
        /// <param name="xml">The xml generated by the compiler and loaded into an XDocument instance</param>
        /// <returns>A textual description</returns>
        private static string GetMethodInfo(MethodInfo method, XDocument? xml)
        {
            var description = Util.GetMemberDescription(out var _, method, xml, out var xmlElement);
            description = "\n\t" + description;
            string? result = null;
            foreach (var parameter in method.GetParameters())
            {
                if (xmlElement != null)
                    foreach (var member in xmlElement.Elements())
                        if (member.Name.LocalName == "param")
                            if (member.Attribute("name")?.Value == parameter.Name)
                            {
                                description += "\n\t" + parameter.Name + ": " + member.Value;
                                break;
                            }

                if (result != null)
                    result += " ";
                result += "\"" + parameter.Name + "\"";
            }
            if (result != null)
                result += " (insert the parameter in quotes if it contains spaces)";
            result = "syntax: " + method.Name + " " + result;
            result += description + "\n\n";
            return result;
        }

        /// <summary>
        /// Gets a description of a class's method
        /// </summary>
        /// <param name="type">The type of class</param>
        /// <param name="methodName">The method mentioned if you want to get the description. If null then a general description will be returned with the list of methods of the class. The method mentioned if you want to get the description. If null then a general description will be returned with the list of methods of the class.</param>
        /// <returns>The textual description of the method or methods of the class, as requested by parameters</returns>
        private static string GetMethodInfo(Type type, string? methodName)
        {
            var result = "";
            if (string.IsNullOrEmpty(methodName))
            {
                result = "The available commands are: " + string.Join(", ", GetNameMethods(type)) + "\n";
                result += "Use 'Help Command' or 'Command ?' to get the syntax of the command to use, and 'Help all' to get the syntax list of all available commands.\n";
                result += "Run a command using the following syntax:" + "\n";
                result += "Command Parameter1 Parameter2 Parameter3 etc..." + "\n";
                result += "Leave a single space between one parameter and the next, two consecutive spaces therefore indicate an empty parameter, if the parameter includes spaces, then insert them between the quotes \"in this way\".\n";
                return result;
            }

            if (String.Compare(methodName, "all", StringComparison.OrdinalIgnoreCase) == 0)
            {
                return GetMethodsInfo(type);
            }
            var xml = Util.GetXmlOfAssembly(type);
            foreach (var method in GetMethods(type))
                if (String.Compare(method.Name, methodName, StringComparison.OrdinalIgnoreCase) == 0)
                    result += GetMethodInfo(method, xml);
            return result;
        }
        /// <summary>
        /// Get the description of all the methods of a class. The description is taken from the source code comments.
        /// </summary>
        /// <param name="type">Class type</param>
        /// <returns>The description A textual description of all the methods of the class</returns>
        private static string GetMethodsInfo(Type type)
        {
            var xml = Util.GetXmlOfAssembly(type);
            var result = "";
            if (xml != null)
                foreach (var method in GetMethods(type))
                    result += GetMethodInfo(method, xml);
            return result;
        }

    }
}