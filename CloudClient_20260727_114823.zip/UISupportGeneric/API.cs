﻿using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using static UISupportGeneric.Util;
namespace UISupportGeneric
{
    public static class API
    {
        public enum HttpStatus
        {
            OK = 200,
            BadRequest = 400,
            Unauthorized = 401,
            Forbidden = 403,
            NotFound = 404,
            InternalServerError = 500
        }

        private class ErrorResponse
        {
            public HttpStatus Status { get; set; }
            public string Error { get; set; }
            public string Message { get; set; }
            public string Timestamp { get; set; }
        }

        /// <summary>
        /// Invokes a method on an instance of the given type using reflection,
        /// matching parameters from the JSON string. If no instance is provided
        /// and the method is not static, an instance is created automatically
        /// via <see cref="Activator.CreateInstance(Type)"/>.
        /// </summary>
        /// <param name="type">The type containing the method to invoke.</param>
        /// <param name="methodName">Name of the method to execute.</param>
        /// <param name="jsonString">JSON string with parameter values.</param>
        /// <param name="instance">
        /// Optional existing instance. When omitted, a new instance is created
        /// for non-static methods. Reuse this parameter across calls to preserve
        /// object state.
        /// </param>
        /// <returns>JSON string with the method result or an error.</returns>
        public static string CallMethod(Type? type, string? methodName, string jsonString, object? instance = null)
        {
            if (type == null)
                return ErrorJson("Type is required.", HttpStatus.BadRequest);

            if (string.IsNullOrEmpty(methodName))
                return ErrorJson("methodName is required.", HttpStatus.BadRequest);

            if (string.IsNullOrEmpty(jsonString))
                return ErrorJson("jsonString is required.", HttpStatus.BadRequest);

            try
            {
                using JsonDocument doc = JsonDocument.Parse(jsonString);
                var rootElement = doc.RootElement;

                // Find the best matching method (uses GetMethodInfo shared with ExecuteMethod)
                // Use a temp variable because GetMethodInfo may overwrite it from the JSON "method" property
                var searchName = methodName;
                MethodInfo? bestMethod = GetMethodInfo(doc, ref searchName, type);

                // If not found, try converting snake_case to PascalCase
                if (bestMethod == null && methodName != null)
                {
                    var pascalName = SnakeToPascalCase(methodName);
                    if (!string.Equals(pascalName, methodName, StringComparison.Ordinal))
                    {
                        searchName = pascalName;
                        bestMethod = GetMethodInfo(doc, ref searchName, type);
                        if (bestMethod != null)
                            methodName = pascalName; // update for error messages
                    }
                }

                if (bestMethod == null)
                    return ErrorJson($"Method '{methodName}' not found on type '{type.Name}'.", HttpStatus.NotFound);

                // Create instance for non-static methods if none was provided
                if (!bestMethod.IsStatic && instance == null)
                {
                    instance = Activator.CreateInstance(type);
                }

                // Prepare parameter values from the JSON document
                var parameterValues = new List<object?>();
                foreach (var p in bestMethod.GetParameters())
                {
                    if (rootElement.TryGetPropertyCaseInsensitive(p.Name, out JsonElement jsonParam))
                    {
                        parameterValues.Add(ConvertJsonToParamValue(jsonParam, p.ParameterType));
                    }
                    else if (p.HasDefaultValue)
                    {
                        parameterValues.Add(p.DefaultValue);
                    }
                    else
                    {
                        // Parameter not found in JSON and has no default — pass null / default
                        parameterValues.Add(p.ParameterType.IsValueType
                            ? Activator.CreateInstance(p.ParameterType)
                            : null);
                    }
                }

                // Invoke the method
                object? result;
                try
                {
                    result = bestMethod.Invoke(instance, parameterValues.ToArray());
                }
                catch (TargetInvocationException ex)
                {
                    var innerMessage = ex.InnerException?.Message ?? ex.Message;
                    return ErrorJson($"Error executing '{methodName}': {innerMessage}", HttpStatus.InternalServerError);
                }

                return ObjToString(result);
            }
            catch (JsonException jsonEx)
            {
                return ErrorJson($"JSON Parsing Error: {jsonEx.Message}", HttpStatus.BadRequest);
            }
            catch (Exception ex)
            {
                return ErrorJson($"General Error: {ex.Message}", HttpStatus.InternalServerError);
            }
        }

        /// <summary>
        /// Converts a <see cref="JsonElement"/> value to the specified target type,
        /// handling <c>List&lt;T&gt;</c>, <c>Nullable&lt;T&gt;</c>, enums, and primitive types.
        /// </summary>
        private static object? ConvertJsonToParamValue(JsonElement jsonParam, Type targetType)
        {
            // string — direct
            if (targetType == typeof(string))
                return jsonParam.GetString();

            // List<T> — deserialize JSON array
            if (targetType.IsGenericType && targetType.GetGenericTypeDefinition() == typeof(List<>))
            {
                if (jsonParam.ValueKind == JsonValueKind.Array)
                {
                    var listType = typeof(List<>).MakeGenericType(targetType.GetGenericArguments()[0]);
                    return JsonSerializer.Deserialize(jsonParam.GetRawText(), listType);
                }
                return null;
            }

            // Nullable<T> — unwrap and parse the underlying type
            var underlyingType = Nullable.GetUnderlyingType(targetType);
            if (underlyingType != null)
            {
                if (jsonParam.ValueKind == JsonValueKind.Null)
                    return null;
                return ConvertJsonToParamValue(jsonParam, underlyingType);
            }

            // Enum — parse from string
            if (targetType.IsEnum)
            {
                if (jsonParam.ValueKind == JsonValueKind.String)
                    return Enum.Parse(targetType, jsonParam.GetString()!, ignoreCase: true);
                if (jsonParam.ValueKind == JsonValueKind.Number)
                    return Enum.ToObject(targetType, jsonParam.GetInt32());
                return null;
            }

            // DateTime — parse from string (handle ISO 8601 and culture-specific formats)
            if (targetType == typeof(DateTime) && jsonParam.ValueKind == JsonValueKind.String)
            {
                var strValue = jsonParam.GetString()!;
                if (DateTime.TryParse(strValue, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
                    return dt;
                return DateTime.Parse(strValue, CultureInfo.CurrentCulture);
            }

            // Primitive types — use Convert.ChangeType
            if (jsonParam.ValueKind == JsonValueKind.String)
            {
                var strValue = jsonParam.GetString()!;
                return Convert.ChangeType(strValue, targetType);
            }

            var rawText = jsonParam.GetRawText();
            return Convert.ChangeType(rawText, targetType);
        }

        /// <summary>
        /// Process a JSON request received from a POST method, and provide a response in JSON format in response to the client request.
        /// </summary>
        /// <param name="type">Class type of method to execute.</param>
        /// <param name="methodName">Name of the method to execute.</param>
        /// <param name="jsonString">JSON data sent by remote client.</param>
        /// <param name="response">Data response in JSON format.</param>
        /// <returns>HttpStatus indicating the result of the operation.</returns>
        public static HttpStatus Post(Type? type, string? methodName, string jsonString, out string response)
        {
            try
            {
                if (string.IsNullOrEmpty(jsonString))
                {
                    response = GenerateCsharpAPIConsumerCode(type);
                    return HttpStatus.OK;
                }
                else
                {
                    using JsonDocument doc = JsonDocument.Parse(jsonString);
                    return ExecuteMethod(doc, methodName, type, out response);
                }
            }
            catch (JsonException jsonEx)
            {
                response = ErrorJson($"JSON Parsing Error: {jsonEx.Message}", HttpStatus.BadRequest);
                return HttpStatus.BadRequest;
            }
            catch (Exception ex)
            {
                response = ErrorJson($"General Error: {ex.Message}", HttpStatus.InternalServerError);
                return HttpStatus.InternalServerError;
            }
        }

        /// <summary>
        /// Process a request received from a GET method, and provide a response.
        /// </summary>
        /// <param name="type">Class type of method to execute.</param>
        /// <param name="response">Data response.</param>
        /// <returns>HttpStatus indicating the result of the operation.</returns>
        public static HttpStatus Get(Type? type, out string response)
        {
            try
            {
                response = GenerateCsharpAPIConsumerCode(type);
                return HttpStatus.OK;
            }
            catch (Exception ex)
            {
                response = ErrorJson($"General Error: {ex.Message}", HttpStatus.InternalServerError);
                return HttpStatus.InternalServerError;
            }
        }
       
        /// <summary>
        /// Generates a C# class that acts as an API consumer for the specified type.
        /// </summary>
        /// <param name="type">The type containing the API methods.</param>
        /// <returns>The generated C# class code as a string.</returns>
        public static string GenerateCsharpAPIConsumerCode(Type? type, string apiEntryPoint = "http://localhost/api")
        {
            if (type == null) return string.Empty;

            XDocument? Xml = GetXmlOfAssembly(type);

            bool IsPrimitiveType(Type returnType) => returnType == typeof(string) || returnType == typeof(decimal) || returnType.IsPrimitive;
            string GetReturnType(Type type) => IsPrimitiveType(type) ? type.Name : "JsonDocument";
            string GetJsonElementMethod(Type type) => type.Name switch
            {
                "Int32" => "Int32",
                "UInt32" => "UInt32",
                "Int64" => "Int64",
                "UInt64" => "UInt64",
                "Single" => "Single",
                "Double" => "Double",
                "Decimal" => "Decimal",
                "Boolean" => "Boolean",
                _ => "String"
            };

            StringBuilder codeBuilder = new StringBuilder();
            string className = $"{Assembly.GetEntryAssembly()?.GetName().Name}{type.Name}Client";

            codeBuilder.AppendLine("using System;");
            codeBuilder.AppendLine("using System.Net.Http;");
            codeBuilder.AppendLine("using System.Security.Cryptography;");
            codeBuilder.AppendLine("using System.Text;");
            codeBuilder.AppendLine("using System.Text.Json;");
            codeBuilder.AppendLine("using System.Threading.Tasks;");
            codeBuilder.AppendLine("using Microsoft.Extensions.DependencyInjection;");
            codeBuilder.AppendLine();
            codeBuilder.AppendLine("namespace API");
            codeBuilder.AppendLine("{");
            // Generate the APIClientFactory
            codeBuilder.AppendLine("    /// <summary>");
            codeBuilder.AppendLine("    /// API Client Factory to manage HttpClient instances efficiently.");
            codeBuilder.AppendLine("    /// </summary>");
            codeBuilder.AppendLine("    public class APIClientFactory");
            codeBuilder.AppendLine("    {");
            codeBuilder.AppendLine("        private readonly IHttpClientFactory _httpClientFactory;");
            codeBuilder.AppendLine();
            codeBuilder.AppendLine("        public APIClientFactory()");
            codeBuilder.AppendLine("        {");
            codeBuilder.AppendLine("            var services = new ServiceCollection();");
            codeBuilder.AppendLine("            services.AddHttpClient();");
            codeBuilder.AppendLine("            var serviceProvider = services.BuildServiceProvider();");
            codeBuilder.AppendLine("            _httpClientFactory = serviceProvider.GetRequiredService<IHttpClientFactory>();");
            codeBuilder.AppendLine("        }");
            codeBuilder.AppendLine();
            codeBuilder.AppendLine("        public HttpClient CreateClient() => _httpClientFactory.CreateClient();");
            codeBuilder.AppendLine("    }");
            codeBuilder.AppendLine();

            // Generate the API Consumer Client
            codeBuilder.AppendLine("    /// <summary>");
            codeBuilder.AppendLine($"    /// API consumer client for interacting with {type.Name} methods.");
            codeBuilder.AppendLine("    /// </summary>");
            codeBuilder.AppendLine("    public class " + className);
            codeBuilder.AppendLine("    {");
            codeBuilder.AppendLine("        private readonly APIClientFactory _clientFactory;");
            codeBuilder.AppendLine("        private readonly string _apiEntryPoint;");
            codeBuilder.AppendLine("        private readonly string _apiPrivateKey;");
            codeBuilder.AppendLine();
            codeBuilder.AppendLine($"        /// <summary>");
            codeBuilder.AppendLine($"        /// Initializes a new instance of <see cref=\"{className}\"/>.");
            codeBuilder.AppendLine($"        /// </summary>");
            codeBuilder.AppendLine($"        /// <param name=\"apiEntryPoint\">Base API URL.</param>");
            codeBuilder.AppendLine($"        /// <param name=\"apiPrivateKey\">RSA private key in PEM format for request signing (optional).</param>");
            codeBuilder.AppendLine("        public " + className + "(string apiEntryPoint, string apiPrivateKey = null)");
            codeBuilder.AppendLine("        {");
            codeBuilder.AppendLine("            _clientFactory = new APIClientFactory();");
            codeBuilder.AppendLine("            _apiEntryPoint = apiEntryPoint;");
            codeBuilder.AppendLine("            _apiPrivateKey = apiPrivateKey;");
            codeBuilder.AppendLine("        }");
            codeBuilder.AppendLine();

            foreach (var method in type.GetMethods().Where(m => m.DeclaringType == type))
            {
                var parameters = method.GetParameters();
                string methodName = method.Name;
                bool isVoid = method.ReturnType == typeof(void);
                string returnType = isVoid ? "Task<bool>" : $"Task<{GetReturnType(method.ReturnType)}>";
                string paramList = string.Join(", ", parameters.Select(p => $"{p.ParameterType.Name} {p.Name}"));

                XElement? xmlElement = null;
                int order;
                string? methodDescription = Xml != null ? GetMemberDescription(out order, method, Xml, out xmlElement) : null;

                // Generate XML comments for the method
                codeBuilder.AppendLine("        /// <summary>");
                if (string.IsNullOrEmpty(methodDescription))
                {
                    codeBuilder.AppendLine("        /// " + $"Executes {methodName} API call.");
                }
                else
                {
                    string[] lines = methodDescription.Split(["\r\n", "\r", "\n"], StringSplitOptions.RemoveEmptyEntries);
                    foreach (var line in lines)
                    {
                        codeBuilder.AppendLine("        /// " + line);
                    }
                }
                codeBuilder.AppendLine("        /// </summary>");
                foreach (var param in parameters)
                {
                    string? paramDescription = Xml != null ? GetParameterDescription(out order, param, Xml, out xmlElement) : null;
                    if (!string.IsNullOrEmpty(paramDescription))
                    {
                        codeBuilder.AppendLine($"        /// <param name=\"{param.Name}\">{paramDescription}</param>");
                    }
                }
                var returns = xmlElement?.Element("returns")?.Value;
                if (!string.IsNullOrEmpty(returns))
                {
                    codeBuilder.AppendLine($"        /// <returns>{returns}</returns>");
                }
                else if (isVoid) // Add return description for void methods converted to Task<bool>
                {
                    codeBuilder.AppendLine("        /// <returns>True if the operation was successful</returns>");
                }

                codeBuilder.AppendLine($"        public async {returnType} {methodName}({paramList})");
                codeBuilder.AppendLine("        {");
                codeBuilder.AppendLine("            using var httpClient = _clientFactory.CreateClient();");
                codeBuilder.AppendLine("            string jsonString;");
                codeBuilder.AppendLine("            if (!string.IsNullOrEmpty(_apiPrivateKey)) {");

                if (parameters.Length > 0)
                {
                    codeBuilder.AppendLine("                var requestData = new {");
                    foreach (var param in parameters)
                    {
                        codeBuilder.AppendLine($"                    {param.Name} = {param.Name},");
                    }
                    codeBuilder.AppendLine("                    timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds()");
                    codeBuilder.AppendLine("                };");
                    codeBuilder.AppendLine("                jsonString = JsonSerializer.Serialize(requestData);");
                }
                else
                {
                    codeBuilder.AppendLine("                jsonString = JsonSerializer.Serialize(new { timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds() });");
                }

                codeBuilder.AppendLine("                using var rsa = RSA.Create();");
                codeBuilder.AppendLine("                rsa.ImportFromPem(_apiPrivateKey);");
                codeBuilder.AppendLine("                var signature = rsa.SignData(Encoding.UTF8.GetBytes(jsonString), HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);");
                codeBuilder.AppendLine("                httpClient.DefaultRequestHeaders.Add(\"X-Signature\", Convert.ToBase64String(signature));");
                codeBuilder.AppendLine("            } else {");

                if (parameters.Length > 0)
                {
                    codeBuilder.AppendLine("                var requestData = new {");
                    foreach (var param in parameters)
                    {
                        codeBuilder.AppendLine($"                    {param.Name} = {param.Name},");
                    }
                    codeBuilder.AppendLine("                };");
                    codeBuilder.AppendLine("                jsonString = JsonSerializer.Serialize(requestData);");
                }
                else
                {
                    codeBuilder.AppendLine("                jsonString = \"{}\";");
                }

                codeBuilder.AppendLine("            }");
                codeBuilder.AppendLine("            var jsonContent = new StringContent(jsonString, Encoding.UTF8, \"application/json\");");

                codeBuilder.AppendLine($"            using var response = await httpClient.PostAsync(_apiEntryPoint + \"/{methodName.ToLower()}\", jsonContent).ConfigureAwait(false);");

                if (isVoid)
                {
                    codeBuilder.AppendLine("            return response.IsSuccessStatusCode;");
                }
                else
                {
                    codeBuilder.AppendLine("            var responseData = await response.Content.ReadAsStringAsync();");
                    codeBuilder.AppendLine("            if (string.IsNullOrWhiteSpace(responseData)) return default;");
                    var returnCode = "            return JsonDocument.Parse(responseData)";
                    if (IsPrimitiveType(method.ReturnType))
                    {
                        returnCode += $".RootElement.GetProperty(\"result\").Get{GetJsonElementMethod(method.ReturnType)}()";
                    }
                    returnCode += ";";
                    codeBuilder.AppendLine(returnCode);
                }

                codeBuilder.AppendLine("        }");
                codeBuilder.AppendLine();
            }

            codeBuilder.AppendLine("    }");
            codeBuilder.AppendLine("}");

            return codeBuilder.ToString();
        }

        /// <summary>
        /// Executes the specified method using reflection and returns the result in JSON format.
        /// </summary>
        /// <param name="jsonDocument">JsonDocument containing the command and parameters.</param>
        /// <param name="methodName">Name of the method to execute.</param>   
        /// <param name="type">Class type of method to execute.</param>
        /// <param name="response">Result of the execution in JSON format.</param>
        /// <returns>HttpStatus indicating the result of the operation.</returns>
        private static HttpStatus ExecuteMethod(JsonDocument jsonDocument, string? methodName, Type? type, out string response)
        {
            JsonElement rootElement = jsonDocument.RootElement;

            // Determine the class type if not provided
            type ??= new StackTrace().GetFrames()[1].GetMethod()?.DeclaringType;
            if (type == null)
            {
                response = ErrorJson("Type undefined!", HttpStatus.BadRequest);
                return HttpStatus.BadRequest;
            }
            if (!string.IsNullOrEmpty(methodName))
            {
                if (methodName == "?")
                    methodName = "Help";
                                
                MethodInfo? bestMethod = GetMethodInfo(jsonDocument, ref methodName, type);
                                               
                if (bestMethod == null)
                {
                    response = ErrorJson("No suitable method found", HttpStatus.BadRequest);
                    return HttpStatus.BadRequest;
                }

                // Prepare parameter values for the best method
                var parameterValues = new List<object?>();
                foreach (var p in bestMethod.GetParameters())
                {
                    if (rootElement.TryGetPropertyCaseInsensitive(p.Name, out JsonElement jsonParam))
                    {
                        parameterValues.Add(ConvertJsonToParamValue(jsonParam, p.ParameterType));
                    }
                    else if (p.HasDefaultValue)
                    {
                        parameterValues.Add(p.DefaultValue);
                    }
                    else
                    {
                        parameterValues.Add(p.ParameterType.IsValueType
                            ? Activator.CreateInstance(p.ParameterType)
                            : null);
                    }
                }

                // Invoke the method
                object? result;
                try
                {
                    result = bestMethod.Invoke(null, parameterValues.ToArray());
                }
                catch (Exception ex)
                {
                    response = ErrorJson($"Error executing method: {ex.Message}", HttpStatus.InternalServerError);
                    return HttpStatus.InternalServerError;
                }

                response = ObjToString(result);
                return HttpStatus.OK;
            }

            response = ErrorJson("Missing property 'method' in JSON request!", HttpStatus.BadRequest);
            return HttpStatus.BadRequest;
        }

        /// <summary>
        /// Searches for a method on the specified type that matches the provided method name and whose parameters
        /// correspond to properties in the given JSON document.
        /// </summary>
        /// <remarks>The method selects the candidate with the highest number of parameters for which all
        /// required parameters are present as properties in the JSON document. Parameter matching is case-insensitive.
        /// If multiple methods match, the one with the most parameters is returned.</remarks>
        /// <param name="jsonDocument">The JSON document containing data used to match method parameters and, optionally, the method name.</param>
        /// <param name="methodName">The name of the method to search for. If null or empty, the method attempts to retrieve the name from the
        /// 'Method' property in the JSON document, case-insensitively.</param>
        /// <param name="type">The type on which to search for the method. Only methods declared directly on this type are considered.</param>
        /// <returns>A MethodInfo representing the best matching method if found; otherwise, null.</returns>
        public static MethodInfo? GetMethodInfo(JsonDocument jsonDocument, ref string? methodName, Type? type)
        {
            JsonElement rootElement = jsonDocument.RootElement;
            if (string.IsNullOrEmpty(methodName))
                if (rootElement.TryGetPropertyCaseInsensitive("Method", out JsonElement jsonMethod))
                {
                    methodName = jsonMethod.GetString()?.Trim();
                }
            MethodInfo? bestMethod = null;
            int maxParametersMatched = -1; // -1 so methods with 0 params still match (0 > -1)

            // Find the most suitable method
            foreach (var method in type.GetMethods().Where(m => m.DeclaringType == type))
            {
                if (!string.Equals(method.Name, methodName, StringComparison.OrdinalIgnoreCase))
                    continue;

                var parameters = method.GetParameters();

                // Check if all method parameters exist in rootElement
                int matchedParameters = 0;
                foreach (var param in parameters)
                {
                    // A parameter is considered matched if it's present in the JSON
                    // or if it has a default value (optional parameter)
                    if (rootElement.TryGetPropertyCaseInsensitive(param.Name, out _) || param.HasDefaultValue)
                    {
                        matchedParameters++;
                    }
                }

                // Only consider methods where all parameters (required + optional) are satisfied
                if (matchedParameters == parameters.Length)
                {
                    // Select the method with the highest number of parameters
                    if (matchedParameters > maxParametersMatched)
                    {
                        bestMethod = method;
                        maxParametersMatched = matchedParameters;
                    }
                }
            }
            return bestMethod;
        }

        private static bool TryGetPropertyCaseInsensitive(this JsonElement rootElement, string propertyName, out JsonElement value)
        {
            value = default;
            foreach (var property in rootElement.EnumerateObject())
            {
                if (property.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase))
                {
                    value = property.Value;
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Converts a snake_case string (e.g. "fill_fields") to PascalCase ("FillFields").
        /// </summary>
        private static string SnakeToPascalCase(string snakeCase)
        {
            if (string.IsNullOrEmpty(snakeCase)) return snakeCase;
            var parts = snakeCase.Split('_', StringSplitOptions.RemoveEmptyEntries);
            return string.Concat(parts.Select(p => char.ToUpperInvariant(p[0]) + p[1..]));
        }


        /// <summary>
        /// Converts an object to a JSON-formatted string.
        /// </summary>
        /// <param name="obj">Object to convert.</param>
        /// <returns>JSON-formatted string representing the object.</returns>
        private static string ObjToString(object? obj)
        {
            if (obj == null)
                return JsonValue(null);

            var resultType = obj.GetType();
            if (resultType == typeof(void))
            {
                var responseObject = new
                {
                    success = true,
                    message = "Command executed successfully."
                };
                return JsonSerializer.Serialize(responseObject);
            }

            // Direct serialization if the object is a Tuple
            if (obj is ITuple tuple)
            {
                var tupleData = Enumerable.Range(0, tuple.Length)
                                          .Select(i => tuple[i])
                                          .ToArray();
                return JsonSerializer.Serialize(tupleData);
            }

            var resultTypeInfo = resultType.GetTypeInfo();
            return resultType == typeof(string) || resultTypeInfo.IsPrimitive ? JsonValue(obj) : JsonSerializer.Serialize(obj);
        }

        /// <summary>
        /// Wraps an object in a JSON response structure.
        /// </summary>
        /// <param name="obj">Object to wrap.</param>
        /// <returns>JSON-formatted string with the object.</returns>
        private static string JsonValue(object? obj)
        {
            var resultObject = new { result = obj };
            return JsonSerializer.Serialize(resultObject);
        }

        /// <summary>
        /// Creates a JSON-formatted error response.
        /// </summary>
        /// <param name="message">Error message.</param>
        /// <param name="status">HTTP status code.</param>
        /// <returns>JSON-formatted error response.</returns>
        private static string ErrorJson(string message = null, HttpStatus status = HttpStatus.BadRequest)
        {
            var errorResponse = new ErrorResponse
            {
                Status = status,
                Error = GetErrorDescription(status),
                Message = message,
                Timestamp = DateTime.UtcNow.ToString("o")
            };

            return JsonSerializer.Serialize(errorResponse);
        }

        /// <summary>
        /// Provides a description for an HTTP status code.
        /// </summary>
        /// <param name="status">HTTP status code.</param>
        /// <returns>Description of the HTTP status code.</returns>
        private static string GetErrorDescription(HttpStatus status)
        {
            return status switch
            {
                HttpStatus.BadRequest => "Bad Request",
                HttpStatus.Unauthorized => "Unauthorized",
                HttpStatus.Forbidden => "Forbidden",
                HttpStatus.NotFound => "Not Found",
                HttpStatus.InternalServerError => "Internal Server Error",
                _ => "Error"
            };
        }
    }
}
