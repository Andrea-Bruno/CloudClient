# UISupportGeneric – Developer Guide

## Installation

```bash
dotnet add package UISupportGeneric
```

Or add a project reference when working in the same solution.

## Quick Start

```csharp
using UISupportGeneric;
using UISupportGeneric.UI;

// Obtain the UI model for a live object
MyBackEnd instance = new MyBackEnd();
ClassInfo classInfo = GetClassInfo.Build(instance);

// Iterate over UI elements
foreach (BaseUISupport element in classInfo.Elements)
{
	Console.WriteLine($"{element.Name}: {element.Tooltip}");
}
```

## Controlling What Appears in the UI

### Hide a member entirely
```csharp
[HiddenFromGUI]
public string InternalState { get; set; }
```

### Hide from UI but keep data binding
```csharp
[HiddenBind]
public string CachedValue { get; set; }
```

### Mark a method as callable from the API
```csharp
[IsPublicApi]
public string GetStatus() => "OK";
```

### Add numeric range validation
```csharp
[Range(0, 100)]
public int Progress { get; set; }
```

### Add regex validation
```csharp
[Regex(@"^\d{4}-\d{2}-\d{2}$")]
public string DateString { get; set; }
```

## Ordering UI Elements

Annotate with `System.ComponentModel.DataAnnotations.DisplayAttribute`:

```csharp
[Display(Order = 1)]
public string Name { get; set; }

[Display(Order = 2)]
public string Email { get; set; }
```

Elements without an explicit order appear after ordered ones, in declaration order.

## Localisation

The library ships with built-in translations for EN, DE, ES, FR, IT. To add a new language:

1. Copy `Resources/Dictionary.resx` to `Dictionary.XX.resx` (XX = ISO 639-1 code).
2. Translate the string values.
3. The correct resource is selected automatically via `CultureInfo.CurrentUICulture`.

## Using Icons

```csharp
using UISupportGeneric;

string svg = Icons.GetSvg("cloud-upload"); // returns SVG markup
IEnumerable<string> all = Icons.AllNames;  // lists all 180+ icon names
```

## Monitoring Property Changes

```csharp
var monitor = new MonitoringOnChangeMember(classInfo, "MyProperty",
	onChange: newValue => Console.WriteLine($"Changed to: {newValue}"));
monitor.Start();
```

## Event Redirection

`EventRedirect` allows UI events (button clicks, value changes) to be forwarded to the back-end without platform-specific code:

```csharp
var redirect = new EventRedirect(classInfo);
redirect.FireEvent("OnSave", eventArgs);
```

## Building

```powershell
dotnet build ..\..\UISupportGeneric\UISupportGeneric.csproj
```
