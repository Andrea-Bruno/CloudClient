# UISupportGeneric – System Overview

## Purpose

**UISupportGeneric** is the core, platform-agnostic assembly analyzer that underpins the automatic front-end generation system. It reflects over compiled .NET assemblies at runtime and produces an in-memory, technology-neutral UI model that platform-specific renderers (Blazor, MAUI, WinForms, …) can consume to generate user interfaces automatically.

## Design Philosophy

> *"The programmer must focus only on functionality. The front-end is generated automatically."*

The library follows a **reflection-first** approach: the compiled assembly is the single source of truth. No code-generation step, no scaffolding templates — just runtime introspection.

## Core Concepts

### ClassInfo
Represents a reflected class. Holds the ordered list of `BaseUISupport` elements (properties, methods, etc.) that should appear in the UI.

### UISupport hierarchy

```
BaseUISupport (abstract)
├── PropertyUISupport    – a single property
├── MethodUISupport      – an invocable method
├── ParametersUISupport  – method parameters
├── EditableUIMember     – editable property
├── ArrayElementPrimitiveUI – element of a primitive collection
└── TableUISupport       – collection rendered as a table
```

### Element
Base type carrying: `Name`, `Description`, `Order`, and a reference to the parent `ClassInfo`.

### ObjectsCollection
Manages a collection of objects and their associated `ClassInfo` instances.

## Attributes

| Attribute | Target | Effect |
|---|---|---|
| `[HiddenFromGUI]` | Property / Method | Excludes the member from the generated UI |
| `[HiddenBind]` | Property | Hides from UI but keeps data binding active |
| `[IsPublicApi]` | Method | Marks as callable from the REST API |
| `[Range(min, max)]` | Property | Adds numeric range validation |
| `[Regex(pattern)]` | Property | Adds regex string validation |

## Localisation

Resource files under `Resources/` provide translations for built-in labels:

| File | Language |
|---|---|
| `Dictionary.resx` | English (default) |
| `Dictionary.de.resx` | German |
| `Dictionary.es.resx` | Spanish |
| `Dictionary.fr.resx` | French |
| `Dictionary.it.resx` | Italian |

## Icons

Over 180 SVG icons (from the Open Iconic set) are embedded and referenced via `Icons.cs`.  
Usage: `Icons.GetSvg("cloud-upload")` returns the SVG string.

## Target Framework

**.NET Standard 2.1**
