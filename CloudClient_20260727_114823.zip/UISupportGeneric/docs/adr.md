# UISupportGeneric – Architecture Decision Records

## ADR-001: Assembly as the Source of Truth

**Date**: 2024  
**Status**: Accepted

### Context
UI generation could be driven by source code, configuration files, or compiled assemblies. Source code requires a parser per language; configuration files go out of sync; compiled assemblies are always in sync with the running code.

### Decision
Use the **compiled assembly** (via .NET Reflection) as the sole source of truth for UI generation.

### Consequences
- **Positive**: always in sync with the back-end; no separate UI description file to maintain.
- **Positive**: language-independent: C#, F#, VB.NET all produce the same assembly metadata.
- **Positive**: deterministic: the same assembly always produces the same UI model.
- **Negative**: requires the back-end to be compiled before the UI can be generated.

---

## ADR-002: Attribute-Based UI Customisation

**Date**: 2024  
**Status**: Accepted

### Context
The developer needs a way to influence the generated UI (hide members, add validation, mark API methods) without writing front-end code.

### Decision
Provide a set of **custom attributes** (`[HiddenFromGUI]`, `[HiddenBind]`, `[IsPublicApi]`, `[Range]`, `[Regex]`) applied directly to back-end members.

### Consequences
- **Positive**: UI configuration lives in the back-end source, co-located with the logic it describes.
- **Positive**: refactoring (rename a property) automatically updates the UI configuration.
- **Negative**: attributes bleed UI concerns into the back-end; purists may prefer a separate metadata file.

---

## ADR-003: Platform-Neutral UI Model

**Date**: 2024  
**Status**: Accepted

### Context
The same back-end should be able to generate UIs for Blazor, MAUI, WinForms, and other platforms.

### Decision
`UISupportGeneric` produces only a **technology-neutral object graph** (ClassInfo → BaseUISupport elements). Platform-specific rendering is the responsibility of separate libraries (`UISupportBlazor`, future MAUI/WinForms libraries).

### Consequences
- **Positive**: write the analyzer once; reuse across all target platforms.
- **Positive**: the UI model can be unit-tested independently of any rendering technology.
- **Negative**: each target platform requires a dedicated rendering library.

---

## ADR-004: XML Doc-Comments as UI Metadata

**Date**: 2024  
**Status**: Accepted

### Context
Labels, tooltips, and descriptions for UI elements need to come from somewhere. A separate metadata file creates a maintenance burden.

### Decision
Read `<summary>` and `<param>` XML doc-comments from the assembly's embedded XML documentation. Use them as labels and tooltips in the generated UI.

### Consequences
- **Positive**: documentation = UI metadata: written once, used in both contexts.
- **Positive**: Markdown in doc-comments is parsed and rendered by `MarkdownParser`.
- **Negative**: the back-end project must set `<GenerateDocumentationFile>true</GenerateDocumentationFile>`.
