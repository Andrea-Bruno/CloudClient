# UISupportGeneric – API Reference

## Attributes

### `HiddenFromGUIAttribute`
```csharp
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Method | AttributeTargets.Field)]
public class HiddenFromGUIAttribute : Attribute
```
Excludes the decorated member from the generated UI entirely.

---

### `HiddenBindAttribute`
```csharp
[AttributeUsage(AttributeTargets.Property)]
public class HiddenBindAttribute : Attribute
```
Hides the property from the UI but keeps its value synchronized with the back-end.

---

### `IsPublicApiAttribute`
```csharp
[AttributeUsage(AttributeTargets.Method)]
public class IsPublicApiAttribute : Attribute
```
Marks a method as callable through the `ApiMiddleware` REST endpoint.

---

### `RangeAttribute`
```csharp
[AttributeUsage(AttributeTargets.Property)]
public class RangeAttribute : Attribute
{
	public RangeAttribute(double min, double max);
	public double Min { get; }
	public double Max { get; }
}
```
Adds min/max numeric validation to a property.

---

### `RegexAttribute`
```csharp
[AttributeUsage(AttributeTargets.Property)]
public class RegexAttribute : Attribute
{
	public RegexAttribute(string pattern);
	public string Pattern { get; }
}
```
Adds regex validation to a string property.

---

## UI Model Classes

### `ClassInfo`
```csharp
public class ClassInfo
```
Represents a reflected class and its ordered UI elements.

| Member | Description |
|---|---|
| `Elements` | Ordered list of `BaseUISupport` items |
| `Instance` | The live object instance |
| `Type` | The reflected `System.Type` |

---

### `BaseUISupport`
```csharp
public abstract class BaseUISupport : Element
```

| Member | Type | Description |
|---|---|---|
| `Id` | `string` | Unique hex identifier |
| `Error` | `string?` | Validation error message |
| `ValidationError` | `string?` | Real-time validation error |
| `Tooltip` | `string?` | Help text |
| `Successful` | `bool` | `true` when no error |

---

### `PropertyUISupport`
Extends `BaseUISupport` for a property. Exposes `Get()` / `Set(value)` wrappers with validation.

### `MethodUISupport`
Extends `BaseUISupport` for an invocable method. Exposes `Invoke(args[])`.

### `EditableUIMember`
Extends `PropertyUISupport` for user-editable fields. Handles type conversion, range, and regex validation.

### `TableUISupport`
Extends `BaseUISupport` for `IEnumerable` properties. Provides row/column metadata.

---

## Icons API

```csharp
public static class Icons
{
	public static string GetSvg(string name);
	public static IEnumerable<string> AllNames { get; }
}
```

Returns the SVG markup for the named icon from the embedded Open Iconic set.

---

## Terminal

```csharp
public static class Terminal
```
Utility for executing terminal commands from back-end code and capturing output.

---

## GetClassInfo

```csharp
public static ClassInfo GetClassInfo(object instance, ...)
```
Main entry point. Pass a live object to obtain the corresponding `ClassInfo` populated with its UI model.
