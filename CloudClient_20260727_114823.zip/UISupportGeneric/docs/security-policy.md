# UISupportGeneric – Security Policy

## Reflection-Based UI Generation

UISupportGeneric uses .NET reflection to discover and render public properties and methods of panel objects. Security considerations:

- Only `public` members are exposed. Keep sensitive internal state `private` or `internal`.
- Use `[HiddenFromGUI]` attribute on any public member that must not be rendered in the UI.
- Use `[HiddenBind]` to prevent a property from being written via UI binding.

## Attribute-Driven Validation

Input validation attributes (`RangeAttribute`, `RegexAttribute`) are enforced by `UISupportGeneric` before applying values to the underlying object. Always define appropriate constraints:

```csharp
[Range(1, 65535)]
public int Port { get; set; }

[Regex(@"^[\w.-]+$")]
public string Hostname { get; set; }
```

Do not rely solely on client-side validation — also validate in the setter or the business logic layer.

## API Surface Control

`[IsPublicApi]` marks methods as externally callable. Apply this attribute only to methods that are safe to expose over the network. Methods without this attribute are not exposed via the API layer.

## Terminal Access

`Terminal.cs` provides a command execution interface. Restrict the set of allowed commands to a safe whitelist. Never expose the terminal to unauthenticated users.

## Localisation Resources

String resources (`Resources/Dictionary.*.resx`) are read-only at runtime and do not represent a security risk. Do not store secrets in resource files.

## Reporting Vulnerabilities

Open a private GitHub Security Advisory in the repository. Do not disclose vulnerabilities publicly before a fix is available.
