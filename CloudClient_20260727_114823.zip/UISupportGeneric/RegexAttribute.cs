﻿

namespace System
{
    /// <summary>
    /// Custom attribute to associate field validation via regular expression.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]   
    public class RegexAttribute : Attribute
    {
        /// <summary>
        /// The regular expression associated with the attribute.
        /// </summary>
        public string Pattern { get; }

        /// <summary>
        /// Constructor to initialize the attribute with a regular expression.
        /// </summary>
        /// <param name="pattern">The regular expression to validate input.</param>
        public RegexAttribute(string pattern)
        {
            Pattern = pattern ?? throw new ArgumentNullException(nameof(pattern));
        }
    }
}
