﻿# AI dev support
## Using artificial intelligence to speed up software creation
### Intelligent assembly analyzer (AI), for automatically building the front end of applications

## Purpose of the project

With this project we want to introduce a new programming paradigm that speeds up software development by up to 70% thanks to the help of artificial intelligence.

The idea behind this development system is that the programmer must focus only on the program's functionality, in practice the development focuses on the creation of a library without a graphical interface and protocols that allow the front-end to interact with the back-end. Once the back-end is compiled and the assembly is produced, an AI analyzer examines it and automatically creates the front-end with all the iteration mechanisms with it. This speeds up development considerably. The front-end is created complete with everything, including field validation mechanisms. API and iteration systems between GUI and back-end.
In the various tutorials published, for convenience the front-end project coincides with the back-end, this to facilitate these examples, from the practical side it is possible to create a back-end project as a library (therefore without a GUI), and create separate projects for the generation of Web, Mobile and Desktop applications: We are working on 3 GUI generators that cover all the cases, in this way by writing a single back-end you will have the Web, Mobile and Desktop apps ready in one go.

## Incipit

There are already projects that aim to use artificial intelligence to assist the developer in writing code, for example Microsoft's IntelliSense adds automatic completion and suggestions for code to write to the code editor. Copilot (by Microsoft and OpenAI) also works in the same direction, suggesting the code to write based on the experience of AI algorithms due to the analysis of multiple source codes written in various open source repositories.
These software are a valid programming assistance tool, but they fail when you find yourself in specific niche cases where programming goes out of the ordinary, and at present their help is crude and often vague, sometimes the suggestions are incorrect and the developer must still visually check the logical part.
Our goal is much more ambitious and we position ourselves ahead of competing products by creating precise and reliable software parts, reducing the writing time of the source code by up to 70%, reusing the same programming languages and the same experience that programmers are used to.

## Operation

Classic programming is divided into two parts, front-end and back-end. In general, the most structured software companies have 2 distinct development teams, each specialized in one of these parts.
The developers who deal with the back-end essentially write the logic that makes the project work, i.e. the underlying part that the user does not see and which represents the heart of the application with all its functionality exposed in the form of methods and functions. In most cases, unless you want to build a monolithic software, the back-end is developed separately in the form of libraries, each of which solves specific problems, and which can also be reused in other projects on a recurring basis.
The front-end is the graphical interface, i.e. an interface that allows the user to interact with the application and its mechanisms. Simplifying we can say that every user interaction with the graphical interface involves an interaction between front-end and back-end, a passage of input and output data between the two parts, and the activation of events and other mechanisms for which the application was designed. The interaction between front-end and back-end involves an exchange of data that can occur with APIs, REST APIs, RESTful APIs and various protocols that package data in json, xml or others.
The creation of the front-end with its interfaces and interaction with the back-end involves a considerable effort in terms of development and hours of work, all of which consequently affects the costs of creating an application.
Our technology aims to revolutionize all of this, completely automating the development of the front-end while also taking care of the communication protocols between the parties.
The operation is very simple: Once the back-end has been created and compiled (thereby transformed into a universal assembly code different from the source), an automaton analyzes it in real time during execution and custom-builds the front-end and all the mechanisms of interaction with it. This is very precise and is not susceptible to the inherent approximation of other development tools that make use of artificial intelligence via empirical methods.
Our system, working on the assembly (the compiled part), works independently of the programming language used by the developer, and does not require additional effort compared to the normal writing of the back-end, it is simply necessary to follow the normal rules of "best practices ” in programming, writing clean and commented code.

## Our goal is to reduce human work in writing software to the bare minimum

We can imagine every software project as a set of flow diagrams, where each element describes its operation and interaction with other elements. The programmer does nothing but describe the various software parts and their functioning in a "human friendly" language, in pseudo English, in a minimalist and concise manner, after which the compiler transforms this description into instructions that the CPU can execute. Artificial intelligence cannot be useful in this process because it cannot read your mind to know what you want to achieve, it is still necessary to tell the artificial intelligence in a concise and precise (not ambiguous) way what you intend to achieve, this step in terms corresponds exactly to write programming code in a pseudo-English language. It follows that to explain to the artificial intelligence in an unambiguous way the source code that it must create for you corresponds to exactly the same amount of work as writing the code directly without the aid of the artificial intelligence. Our goal is to minimize the code writing part by concentrating the development only for the conceptual part (the back-end), completely eliminating the front-end development team by completely automating the creation of this software part and the mechanisms of interaction with it, consequently reducing costs and development times.
In addition to this, the front-end for developers represents the most monotonous and repetitive part of the work, it is considered as IT labor work, unfulfilling and boring, and being able to eliminate this phase from the development cycle of an application has a benefit also notable for the quality of the work carried out.

Universal multi platform project

Our project has been engineered to be universal to cover both web, desktop and mobile application development.
At a basic level we have a real time assembly analyzer (UISupportGeneric) which interprets the back-end by creating on the fly the logical structure underlying the graphical interfaces that the application requires.

## Usage

We are working on the implementation of this library in 3 sectors: Web, Mobile and Desktop:

- [Web App auto GUI generator. Examples and documentation](https://github.com/Graphene-Lab/Blazor-Auto-GUI-generator-samples/blob/master/MANUAL.md)

- **Mobile App auto GUI generator. Examples and documentation** (Soon: We are looking for investors to speed up this part)

- **Desktop App auto GUI generator. Examples and documentation** (Soon: We are looking for investors to speed up this part)

Currently only the part for Web applications is completed

