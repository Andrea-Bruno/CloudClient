﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace SystemExtra
{
    public static partial class Util
    {
        /// <summary>
        /// Create a system service for this application. With the system service the application will start automatically when the machine is started and will remain resident.
        /// Currently only Linux is supported.
        /// </summary>
        public static bool SystemService
        {
            get { return ServiceStatus; }
            set
            {
                if (value)
                    CreateService();
            }
        }

        /// <summary>
        /// Create a system service for this application or application specified in fullAppName parameter. With the system service the application will start automatically when the machine is started and will remain resident.
        /// Currently only Linux is supported.
        /// </summary>
        /// <param name="instanceId">Set this value if you plan to have multiple instances of the application that start automatically</param>
        /// <param name="fullAppName">Full application path + name. If the value is omitted, the current application will be referred to</param>
        /// <param name="user">the user being impersonated</param>
        /// <param name="group">Group name (for privileges)</param>
        /// <param name="umask">UMask parameter https://linuxize.com/post/umask-command-in-linux/</param>
        public static void CreateService(int? instanceId = null, string fullAppName = null, string user = "root", string group = null, string umask = null)
        {
            var fullAppNameSet = fullAppName != null;
            if (Debugger.IsAttached)
                return;
            string firstUrl = null;
            if (fullAppName != null && instanceId != null)
            {
                firstUrl = "http://*:" + instanceId;
            }
            else if (IsWebApplication)
            {
                var urls = Environment.GetEnvironmentVariable("ASPNETCORE_URLS");
                if (!string.IsNullOrEmpty(urls))
                {
                    firstUrl = urls.Split(';').FirstOrDefault();
                    if (firstUrl != null)
                    {
                        var scheme = firstUrl.Split("://")[0];
                        string addPort = null;
                        if (int.TryParse(firstUrl.Split(':').Last(), out int port))
                        {
                            addPort = ":" + port;
                        }
                        firstUrl = scheme + "://*" + addPort;
                    }
                }
                else if (instanceId != null)
                {
                    firstUrl = "http://*:" + instanceId;
                }
            }
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux) || RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                try
                {
                    var appName = fullAppName != null ? new FileInfo(fullAppName).Name : CurrentAppName;
                    var appPath = fullAppName != null ? new FileInfo(fullAppName).Directory.FullName : AppDomain.CurrentDomain.BaseDirectory;
                    fullAppName ??= Path.Combine(appPath, appName);
                    var dotnetPathNameFile = GetDotnetFullNameFile();
                    var execStart = File.Exists(fullAppName)
                        ? fullAppName
                        : "\"" + dotnetPathNameFile + "\" \"" + fullAppName +
                          ".dll\""; // If stand alone application or app with dotnet dependencies


                    if (fullAppNameSet && firstUrl != null)
                    {
                        execStart += " --urls=" + firstUrl + "/";
                    }

                    var serviceName = ServiceName(instanceId, appName);
                    var serviceIsCreated = false;
                    if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                        serviceIsCreated = MacOSService.CreateService(serviceName, execStart);
                    else
                    {
                        var systemFile = Path.Combine(SystemPath, serviceName + ".service");
                        if (!File.Exists(systemFile))
                        {
                            var description = "Resident service of" + " " + appName + instanceId;
                            var service = "[Unit]\n" +
                                          "Description={0}\n\n" +
                                          "[Service]\n" +
                                          "WorkingDirectory ={1}\n" +
                                          "ExecStart={2}\n" +
                                          "Restart=always\n" +
                                          "# Restart service after 10 seconds if the app crashes:\n" +
                                          "RestartSec=60\n" +
                                          "KillSignal=SIGINT\n" +
                                          "SyslogIdentifier={3}\n" +
                                          "User=" + user + "\n" +
                                          (group == null ? "" : "Group=" + group + "\n") +
                                          (umask == null ? "" : "UMask=" + umask + "\n") +
                                          "\n" +
                                          "[Install]\n" +
                                          "WantedBy=multi-user.target\n";
                            service = string.Format(service, description, appPath, execStart, appName);
                            File.WriteAllText(systemFile, service);
                            serviceIsCreated = true;
                        }
                        SetService(true, instanceId, appName);
                    }
                }
                catch (Exception)
                {
                }
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                if (fullAppName == null)
                    SetAutoStart(true, instanceId);
            }
            else
            {
                //                    return "Os not supported";
            }
        }

        /// <summary>
        /// Current application is service
        /// </summary>
        /// <returns>True if is a service</returns>
        static public bool IsService(int? instanceId = null)
        {
            var serviceName = ServiceName(instanceId, CurrentAppName);
            if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                var plistPath = $"/Library/LaunchDaemons/{serviceName}.plist";
                return File.Exists(plistPath);
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                var systemFile = Path.Combine(SystemPath, serviceName + ".service");
                return File.Exists(systemFile);
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return File.Exists(AutoStartXmlFileName);
            }
            return false;
        }

        private static string GetDotnetFullNameFile()
        {
            var runtimePath = new DirectoryInfo(RuntimeEnvironment.GetRuntimeDirectory());
            do
            {
                var dotnetFile = Path.Combine(runtimePath.FullName, "dotnet");
                if (File.Exists(dotnetFile))
                {
                    return dotnetFile;
                }
                runtimePath = runtimePath.Parent;
            } while (runtimePath != null);

            return null; // This method should work in every scenario

            var currentUser = CurrentUIUser();
            currentUser ??= Environment.UserName;
            string[] locationsLinux = ["/home/" + currentUser + "/.dotnet/dotnet", "/usr/share/dotnet", "/root/.dotnet/dotnet", "/usr/bin/dotnet"];
            string[] locationsOSX = ["/users/" + currentUser + "/.dotnet/dotnet", "/usr/local/share/dotnet/dotnet", "/usr/local/Cellar/dotnet", "/usr/local/bin/dotnet"];

            string[] locations = RuntimeInformation.IsOSPlatform(OSPlatform.Linux)
                ? locationsLinux
                : locationsOSX;
            foreach (var loc in locations)
            {
                if (File.Exists(loc))
                {
                    return loc;
                }
            }
            var pathVariable = Environment.GetEnvironmentVariable("PATH");
            if (pathVariable != null)
            {
                var paths = pathVariable.Split(':');
                foreach (var path in paths)
                {
                    if (path.EndsWith("dotnet"))
                    {
                        var fullName = Path.Combine(path, "dotnet");
                        if (File.Exists(fullName))
                            return fullName;
                    }
                }
            }


            var dotnetPathNameFile = PathOfSoftware("dotnet");

            if (dotnetPathNameFile != null)
                return dotnetPathNameFile;

            try
            {
                dotnetPathNameFile = Directory.GetFiles("/", "dotnet", SearchOption.AllDirectories).FirstOrDefault();
            }
            catch (Exception)
            {
            }

            return dotnetPathNameFile ?? "/root/.dotnet/dotnet";
        }

        private static string SystemPath
        {
            get
            {
                if (Platform == PlatformCategory.ClearLinux)
                    return "/usr/lib/systemd/system";
                return "/etc/systemd/system/";
            }
        }

        private static string CurrentAppName => AppDomain.CurrentDomain.FriendlyName;

        private static string ServiceName(int? instanceId = null, string appName = null) => (appName ?? CurrentAppName) + instanceId;

        private static bool? _ServiceStatus;

        /// <summary>
        /// Allow/Disallow service
        /// </summary>
        private static bool ServiceStatus
        {
            get { return GetService(); }
            set { SetService(value); }
        }

        private static bool GetService(int? instanceId = null, string appName = null)
        {
            var serviceName = ServiceName(instanceId, appName);
            if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                return MacOSService.IsServiceRunning(serviceName);
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                if (_ServiceStatus == null)
                {
                    var status = ExecuteCommand("systemctl", "status " + serviceName);
                    _ServiceStatus = status != null && status.Contains("active");
                }
                return (bool)_ServiceStatus;
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return File.Exists(nameof(AutoStart) + instanceId) && bool.Parse(File.ReadAllText(nameof(AutoStart) + instanceId));
            }
            return false;
        }

        private static void SetService(bool enable, int? instanceId = null, string appName = null)
        {
            var serviceName = ServiceName(instanceId, appName);
            _ServiceStatus = enable;
            if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                MacOSService.SetService(enable, serviceName);
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    if (enable == true)
                        ExecuteCommand("systemctl", "enable " + serviceName);
                    var cmd = enable ? "start" : "stop";
                    ExecuteCommand("systemctl", cmd + " " + serviceName);
                }
                catch (Exception)
                {
                }
            }
        }

        private static string TaskName(int? InstanceId = null)
        {
            return @"/tn AutoStart" + CurrentAppName + InstanceId;
        }


        /// <summary>
        /// Gets the current state of the application's auto start setting
        /// </summary>
        /// <param name="port">Specifies the port other than the default one, for dotnet services that have a Web interface</param>
        /// <returns>Returns true if auto start has been set, false if it has been disabled.</returns>
        public static bool GetAutoStart(int? port = null) => GetService(port);

        /// <summary>
        /// Set the application to start automatically when the operating system boots
        /// With Linux a service will be created, on Windows a Task Scheduler will be programmed that starts the application when the system starts
        /// </summary>
        /// <param name="active">True to enable auto start, false to disable it</param>
        /// <param name="instanceId">Specifies the instance id</param>
        public static void SetAutoStart(bool active, int? instanceId = null)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux) || RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                if (active)
                {
                    CreateService(instanceId);
                }
                else
                {
                    SetService(false, instanceId); // Stop the service
                }
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                try
                {
                    if (active == GetAutoStart(instanceId))
                        return;
                    File.WriteAllText(nameof(AutoStart) + instanceId, active.ToString());
                    if (active)
                    {
                        // Prevent accidentally setting under developing
                        if (Debugger.IsAttached || AppDomain.CurrentDomain.BaseDirectory.ToLower().Contains(@"\bin\"))
                            return;
                        //if (!File.Exists(xmlFileName))
                        //{
                        // example and documentation: https://learn.microsoft.com/en-us/windows/win32/taskschd/boot-trigger-example--xml-/
                        var xml = @"<?xml version=""1.0"" ?>
<!--
Schedules a task to start {0} when the system is booted.
-->
<Task xmlns=""http://schemas.microsoft.com/windows/2004/02/mit/task"">
    <RegistrationInfo>
        <Author>{0}</Author>
        <Version>1.0.0</Version>
        <Description>Starts {0} on system boot.</Description>
    </RegistrationInfo>
    <Triggers>
        <LogonTrigger>
          <Enabled>true</Enabled>
        </LogonTrigger>
    </Triggers>
    <Principals>
        <Principal>
            <GroupId>S-1-5-32-545</GroupId>
            <RunLevel>HighestAvailable</RunLevel>
        </Principal>
    </Principals>
    <Settings>
        <Enabled>true</Enabled>
        <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
        <AllowStartOnDemand>true</AllowStartOnDemand>
        <AllowHardTerminate>true</AllowHardTerminate>
        <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
        <RestartOnFailure>
            <Interval>PT1M</Interval>
            <Count>3</Count>
        </RestartOnFailure>
    </Settings>
    <Actions>
        <Exec>
            <Command>{1}</Command>
        </Exec>
    </Actions>
</Task>
";
                        var formatted = string.Format(xml, CurrentAppName, FullAppName);
                        File.WriteAllText(AutoStartXmlFileName, formatted);
                        var args = "/XML \"" + AutoStartXmlFileName + "\" " + TaskName(instanceId);
                        ExecuteCommand("cmd.exe", "/C " + "schtasks /delete " + TaskName(instanceId) + " /F");
                        ExecuteCommand("cmd.exe", "/C " + "schtasks /create " + args);
                        //}
                    }
                    else
                    {
                        ExecuteCommand("cmd.exe", "/C " + "schtasks /delete " + TaskName(instanceId) + " /F");
                    }
                }
                catch (Exception ex)
                {
                }
            }
        }
        private static string AutoStartXmlFileName => FullAppName + ".activity.xml";

        /// <summary>
        /// Set to true to set the automatic start of the current application, false to disable it.
        /// When reading, it returns null if the parameter has not been set, or the current state is true/valid
        /// </summary>
        public static bool AutoStart
        {
            get { return GetAutoStart(); }
            set { SetAutoStart(value); }
        }
    }
}
