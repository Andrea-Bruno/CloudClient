﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SystemExtra
{
    public static partial class Util
    {
        /// <summary>
        /// Result of HTTPS configuration operation
        /// </summary>
        public enum HttpsConfigResult
        {
            /// <summary>
            /// HTTPS configured successfully
            /// </summary>
            Success,
            /// <summary>
            /// Certificate already configured and valid
            /// </summary>
            AlreadyConfigured,
            /// <summary>
            /// Certificate has expired
            /// </summary>
            CertificateExpired,
            /// <summary>
            /// Failed to create or configure certificate
            /// </summary>
            Failed,
            /// <summary>
            /// Not supported on this operating system
            /// </summary>
            NotSupported,
            /// <summary>
            /// Invalid domain name
            /// </summary>
            InvalidDomain,
            /// <summary>
            /// Failed to update appsettings.json
            /// </summary>
            FailedToUpdateSettings,
            /// <summary>
            /// Requires root/administrator privileges
            /// </summary>
            RequiresRootPrivileges,
            /// <summary>
            /// Domain DNS does not point to this server
            /// </summary>
            DomainDnsNotPointingHere,
            /// <summary>
            /// Self-signed certificate created successfully (for IP addresses)
            /// </summary>
            SelfSignedCertificate
        }

        // ─── Port configuration ───────────────────────────────────────────────────

        /// <summary>
        /// Internal port on which Kestrel listens.
        /// nginx (or another reverse proxy) terminates external SSL on port 443
        /// and forwards requests to this port.
        /// </summary>
        private const int KestrelPort = 5000;
        private const string KestrelBaseUrl = "http://*:";

        // ─── Logging infrastructure ───────────────────────────────────────────────
        private static string _settingsLogPath;

        /// <summary>
        /// Initialize the settings log file path based on appsettings.json location.
        /// Called automatically by ConfigureHttps.
        /// </summary>
        private static void EnsureSettingsLogPath(string appsettingsPath)
        {
            if (string.IsNullOrEmpty(_settingsLogPath))
            {
                var dir = !string.IsNullOrEmpty(appsettingsPath)
                    ? Path.GetDirectoryName(Path.GetFullPath(appsettingsPath))
                    : AppDomain.CurrentDomain.BaseDirectory;

                _settingsLogPath = Path.Combine(dir, "settings.log");
            }
        }

        /// <summary>
        /// Write a timestamped entry to settings.log. Creates/truncates on first write per process.
        /// </summary>
        /// <param name="level">Log level: INFO, WARN, ERROR</param>
        /// <param name="message">Detailed log message</param>
        /// <param name="logPath">Optional explicit path (auto-detected from appsettingsPath if not set)</param>
        private static void WriteSettingsLog(string level, string message, string logPath = null)
        {
            try
            {
                var path = logPath ?? _settingsLogPath;
                if (string.IsNullOrEmpty(path)) return;

                var timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                var entry = $"[{timestamp}] [{level}] {message}{Environment.NewLine}";

                var header = $"╔══════════════════════════════════════════════════════════════════════╗{Environment.NewLine}" +
                             $"║  DocumentCreator HTTPS Configuration Log                            ║{Environment.NewLine}" +
                             $"║  Started: {DateTime.Now:yyyy-MM-dd HH:mm:ss}                                          ║{Environment.NewLine}" +
                             $"╚══════════════════════════════════════════════════════════════════════╝{Environment.NewLine}";

                var firstWrite = !File.Exists(path);
                File.AppendAllText(path, firstWrite ? header + entry : entry);
            }
            catch
            {
                // Logging must never throw — fail silently
            }
        }

        /// <summary>
        /// Universal HTTPS auto-configuration for .NET web applications on Linux.
        /// Call this method once with all domains from AllowedHosts.
        ///
        /// WHAT IT DOES:
        /// 1. Processes all domains: validates, checks DNS, obtains/renews Let's Encrypt certificates
        /// 2. Creates nginx server blocks for each domain (HTTP→HTTPS redirect + reverse proxy to Kestrel)
        /// 3. Sets up automatic certificate renewal via cron/systemd timers
        /// 4. Configures Kestrel endpoint in appsettings.json once after all domains are processed
        /// 5. Restarts the application once at the end if any changes were made
        ///
        /// Multi-domain safe: all certificates are obtained and all nginx configs are created
        /// before the single restart, preventing partial configuration.
        ///
        /// ARCHITECTURE:
        /// - nginx terminates SSL on port 443 (external reverse proxy)
        /// - Kestrel listens on http://*:{KestrelPort} (all interfaces)
        /// - nginx handles HTTP->HTTPS redirect on port 80
        ///
        /// This method MUST be called BEFORE WebApplication.CreateBuilder() in Program.cs,
        /// otherwise Kestrel will try to bind without proper configuration.
        /// </summary>
        /// <param name="domains">Array of domain names (e.g., ["example.com", "example.org"])</param>
        /// <param name="email">Email address for Let's Encrypt registration (optional, defaults to admin@first-domain)</param>
        /// <param name="appsettingsPath">Path to appsettings.json file (optional, defaults to current directory)</param>
        /// <returns>Result of the configuration operation with details</returns>
        public static (HttpsConfigResult Result, string Message) ConfigureHttps(string[] domains, string email = null, string appsettingsPath = null, string[] addUrls = null)
        {
            // ─── Guard ───────────────────────────────────────────────────────────
            if (domains == null || domains.Length == 0)
            {
                WriteSettingsLog("ERROR", $"X No domains provided");
                return (HttpsConfigResult.InvalidDomain, "No domains provided");
            }

            // ─── Initialize logging ───────────────────────────────────────────────
            if (string.IsNullOrWhiteSpace(appsettingsPath))
                appsettingsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appsettings.json");
            EnsureSettingsLogPath(appsettingsPath);

            WriteSettingsLog("INFO", $"═══════════════════════════════════════════════════════════════");
            WriteSettingsLog("INFO", $"> Starting HTTPS configuration for {domains.Length} domain(s): {string.Join(", ", domains)}");
            WriteSettingsLog("INFO", $"   appsettings.json path: {appsettingsPath}");
            WriteSettingsLog("INFO", $"   Email: {email ?? "(will use default)"}");
            WriteSettingsLog("INFO", $"   Kestrel port: {KestrelPort}");
            WriteSettingsLog("INFO", $"   AddUrls: {(addUrls != null ? string.Join("; ", addUrls) : "none")}");

            if (!OperatingSystem.IsLinux())
            {
                WriteSettingsLog("ERROR", $"X Not supported OS: {Environment.OSVersion.Platform}");
                return (HttpsConfigResult.NotSupported, "This operation is only supported on Linux systems");
            }

            if (!IsAdmin())
            {
                WriteSettingsLog("ERROR", $"X Not running as root/Administrator");
                return (HttpsConfigResult.RequiresRootPrivileges, "This operation requires root privileges. Please run with sudo.");
            }

            // One-time setup: env vars, prerequisites, firewall
            Environment.SetEnvironmentVariable("DEBIAN_FRONTEND", "noninteractive");
            Environment.SetEnvironmentVariable("NEEDRESTART_MODE", "a");

            var prereqResult = InstallPrerequisites();
            if (!prereqResult.Success)
            {
                WriteSettingsLog("ERROR", $"X Prerequisites installation failed: {prereqResult.Message}");
                return (HttpsConfigResult.Failed, $"Failed to install prerequisites: {prereqResult.Message}");
            }
            EnsureFirewallPorts();

            // ─── Process all domains ──────────────────────────────────────────────
            bool anyUpdateNeeded = false;
            var summary = new List<string>();

            foreach (var domain in domains)
            {
                WriteSettingsLog("INFO", $">>> Processing domain: {domain}");
                var (success, _, updateNeeded, message) = ConfigureSingleDomain(domain, email, appsettingsPath, addUrls);
                summary.Add($"{domain}: {message}");
                if (updateNeeded) anyUpdateNeeded = true;
                if (!success)
                    WriteSettingsLog("WARN", $"! Domain {domain}: {message}");
            }

            // ─── Finalize once ────────────────────────────────────────────────────
            // Always check appsettings.json and update if needed (handles the case
            // where an update wiped appsettings.json but certs still exist on disk).
            WriteSettingsLog("INFO", $"   Updating appsettings.json with Kestrel configuration...");
            var updateResult = UpdateAppsettings(domains[0], null, null, appsettingsPath, addUrls);
            if (!updateResult.Success)
            {
                WriteSettingsLog("ERROR", $"X Failed to update appsettings.json: {updateResult.Message}");
                return (HttpsConfigResult.FailedToUpdateSettings, updateResult.Message);
            }
            WriteSettingsLog("INFO", $"/ appsettings.json updated successfully");

            if (anyUpdateNeeded || updateResult.SettingsChanged)
            {
                WriteSettingsLog("INFO", $"   Restarting application...");
                RestartApplication();
            }

            var joinedSummary = string.Join("; ", summary);
            WriteSettingsLog("INFO", $"/HTTPS configuration completed. {joinedSummary}");
            return (HttpsConfigResult.Success, joinedSummary);
        }

        /// <summary>
        /// Process a single domain: validate DNS, check/renew/obtain certificate,
        /// setup auto-renewal, configure nginx reverse proxy.
        /// Does NOT update appsettings.json or restart — the caller handles that once.
        /// </summary>
        private static (bool Success, bool CertConfigured, bool UpdateNeeded, string Message) ConfigureSingleDomain(
            string domain, string email, string appsettingsPath, string[] addUrls)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(domain) || !IsValidDomain(domain))
                {
                    WriteSettingsLog("ERROR", $"X Invalid domain: '{domain}'");
                    return (false, false, false, "Invalid domain");
                }

                // DNS check
                WriteSettingsLog("INFO", $"   Verifying DNS for {domain}...");
                var dnsCheck = VerifyDnsPointsToThisServer(domain);
                if (!dnsCheck.IsValid)
                {
                    WriteSettingsLog("WARN", $"! DNS for {domain}: {dnsCheck.Message}");
                    return (false, false, false, $"DNS: {dnsCheck.Message}");
                }

                // IP address → self-signed cert
                var hostType = Uri.CheckHostName(domain);
                if (hostType == UriHostNameType.IPv4 || hostType == UriHostNameType.IPv6)
                {
                    var ssResult = ConfigureSelfSignedCertificate(domain, appsettingsPath, addUrls);
                    var isNew = ssResult.Result == HttpsConfigResult.SelfSignedCertificate;
                    return (true, isNew, isNew, ssResult.Message);
                }

                var domainEmail = email ?? $"admin@{domain}";
                var certPath = $"/etc/letsencrypt/live/{domain}/fullchain.pem";
                var keyPath = $"/etc/letsencrypt/live/{domain}/privkey.pem";

                // Check existing certificate
                if (File.Exists(certPath) && File.Exists(keyPath))
                {
                    var certCheck = ExecuteSystemCommand($"openssl x509 -checkend 0 -noout -in {certPath}", out bool isValid);

                    if (isValid)
                    {
                        WriteSettingsLog("INFO", $"/ Certificate valid for {domain}");
                        ConfigureNginxReverseProxy(domain);
                        return (true, false, false, "Already configured");
                    }

                    // Expired → renew
                    WriteSettingsLog("WARN", $"! Certificate expired for {domain}, renewing...");
                    var renewResult = RenewCertificate(domain);
                    if (!renewResult.Success)
                        return (false, false, false, $"Renewal failed: {renewResult.Message}");

                    WriteSettingsLog("INFO", $"/ Certificate renewed for {domain}");
                    SetupAutoRenewal(domain);
                    ConfigureNginxReverseProxy(domain);
                    return (true, true, true, "Certificate renewed");
                }

                // No certificate → obtain one
                WriteSettingsLog("INFO", $"   No certificate for {domain}. Acquiring...");
                var obtainResult = ObtainCertificate(domain, domainEmail);
                if (!obtainResult.Success)
                    return (false, false, false, obtainResult.Message);

                WriteSettingsLog("INFO", $"/ Certificate obtained for {domain}");
                SetupAutoRenewal(domain);
                ConfigureNginxReverseProxy(domain);
                return (true, true, true, "Certificate obtained");
            }
            catch (Exception ex)
            {
                WriteSettingsLog("ERROR", $"X Error configuring {domain}: {ex.Message}");
                return (false, false, false, $"Error: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtain a Let's Encrypt certificate for a single domain using the best
        /// available method: nginx plugin → TLS-ALPN-01 → webroot → standalone.
        /// </summary>
        private static (bool Success, string Message) ObtainCertificate(string domain, string email)
        {
            try
            {
                var port80InUse = IsPortInUse(80);
                var port443InUse = IsPortInUse(443);

                if (port80InUse)
                {
                    WriteSettingsLog("WARN", $"! Port 80 occupied for {domain}");

                    // Try certbot nginx plugin
                    var nginxInstalled = SoftwareIsInstalled("nginx");
                    if (nginxInstalled)
                    {
                        if (!SoftwareIsInstalled("python3-certbot-nginx"))
                        {
                            try { InstallPackage("python3-certbot-nginx", false); } catch { }
                        }

                        var emailParam = email.StartsWith("admin@") ? "--register-unsafely-without-email" : $"--email {email}";
                        var cmd = $"certbot certonly --nginx --non-interactive --agree-tos {emailParam} -d {domain}";
                        WriteSettingsLog("INFO", $"   Running: certbot certonly --nginx -d {domain}");
                        var result = ExecuteSystemCommand(cmd, out bool success);
                        if (success)
                        {
                            WriteSettingsLog("INFO", $"/ certbot --nginx succeeded for {domain}");
                            return (true, "OK");
                        }
                        WriteSettingsLog("WARN", $"! certbot --nginx failed for {domain}: {result}");
                    }

                    // Try TLS-ALPN-01
                    if (!port443InUse)
                    {
                        var emailParam = email.StartsWith("admin@") ? "--register-unsafely-without-email" : $"--email {email}";
                        var cmd = $"certbot certonly --standalone --non-interactive --agree-tos {emailParam} -d {domain} --preferred-challenges tls-alpn-01";
                        WriteSettingsLog("INFO", $"   Running: certbot TLS-ALPN-01 for {domain}");
                        var result = ExecuteSystemCommand(cmd, out bool success);
                        if (success)
                        {
                            WriteSettingsLog("INFO", $"/ TLS-ALPN-01 succeeded for {domain}");
                            return (true, "OK");
                        }
                        WriteSettingsLog("WARN", $"! TLS-ALPN-01 failed for {domain}: {result}");
                    }

                    // Try webroot
                    var webrootPath = "/var/www/html";
                    if (Directory.Exists(webrootPath))
                    {
                        var emailParam = email.StartsWith("admin@") ? "--register-unsafely-without-email" : $"--email {email}";
                        var cmd = $"certbot certonly --webroot -w {webrootPath} --non-interactive --agree-tos {emailParam} -d {domain} --preferred-challenges http";
                        WriteSettingsLog("INFO", $"   Running: certbot webroot for {domain}");
                        var result = ExecuteSystemCommand(cmd, out bool success);
                        if (success)
                        {
                            WriteSettingsLog("INFO", $"/ Webroot succeeded for {domain}");
                            return (true, "OK");
                        }
                        WriteSettingsLog("WARN", $"! Webroot failed for {domain}: {result}");
                    }

                    return (false, "All methods failed (nginx, TLS-ALPN-01, webroot). Port 80 is occupied.");
                }

                // Port 80 free → standalone
                {
                    var emailParam = email.StartsWith("admin@") ? "--register-unsafely-without-email" : $"--email {email}";
                    var cmd = $"certbot certonly --standalone --non-interactive --agree-tos {emailParam} -d {domain} --preferred-challenges http";
                    WriteSettingsLog("INFO", $"   Port 80 free, running certbot standalone for {domain}");
                    var result = ExecuteSystemCommand(cmd, out bool success);
                    if (!success)
                    {
                        WriteSettingsLog("ERROR", $"X Certbot standalone failed for {domain}: {result}");
                        return (false, $"Certbot standalone failed: {result}");
                    }
                    WriteSettingsLog("INFO", $"/ Certbot standalone succeeded for {domain}");
                    return (true, "OK");
                }
            }
            catch (Exception ex)
            {
                WriteSettingsLog("ERROR", $"X ObtainCertificate exception for {domain}: {ex.Message}");
                return (false, $"Exception: {ex.Message}");
            }
        }

        // ─── Helper methods ──────────────────────────────────────────────────────
        // InstallPrerequisites, IsPortInUse, EnsureFirewallPorts, IsValidDomain,
        // VerifyDnsPointsToThisServer, GetServerPublicIpAddress, RenewCertificate,
        // SetupAutoRenewal remain unchanged from original.

        /// <summary>
        /// Install required prerequisites for HTTPS configuration
        /// </summary>
        private static (bool Success, string Message) InstallPrerequisites()
        {
            try
            {
                Environment.SetEnvironmentVariable("DEBIAN_FRONTEND", "noninteractive");

                var packagesToInstall = new List<string>();

                if (!SoftwareIsInstalled("openssl"))
                    packagesToInstall.Add("openssl");

                if (!SoftwareIsInstalled("certbot"))
                    packagesToInstall.Add("certbot");

                if (!SoftwareIsInstalled("cron"))
                    packagesToInstall.Add("cron");

                if (packagesToInstall.Count > 0)
                {
                    Console.WriteLine($"Installing prerequisites: {string.Join(", ", packagesToInstall)}");

                    foreach (var package in packagesToInstall)
                    {
                        InstallPackage(package, packagesToInstall.IndexOf(package) == 0);
                    }

                    if (packagesToInstall.Contains("certbot"))
                    {
                        try { InstallPackage("python3-certbot-nginx", false); }
                        catch { }
                    }
                }

                return (true, "All prerequisites installed successfully");
            }
            catch (Exception ex)
            {
                return (false, $"Error installing prerequisites: {ex.Message}");
            }
        }

        /// <summary>
        /// Check if a specific port is in use using native .NET APIs
        /// </summary>
        private static bool IsPortInUse(int port)
        {
            try
            {
                var ipGlobalProperties = System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties();

                var tcpListeners = ipGlobalProperties.GetActiveTcpListeners();
                if (tcpListeners.Any(endpoint => endpoint.Port == port))
                    return true;

                var tcpConnections = ipGlobalProperties.GetActiveTcpConnections();
                if (tcpConnections.Any(conn => conn.LocalEndPoint.Port == port))
                    return true;

                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Ensure firewall ports are open for Let's Encrypt and HTTPS
        /// </summary>
        private static void EnsureFirewallPorts()
        {
            try
            {
                SetFirewall(80, true);
                SetFirewall(443, true);
            }
            catch { }
        }

        /// <summary>
        /// Validate domain name or IP address format using native .NET functions
        /// </summary>
        private static bool IsValidDomain(string domain)
        {
            if (string.IsNullOrWhiteSpace(domain))
                return false;

            var result = Uri.CheckHostName(domain);
            return result == UriHostNameType.Dns || result == UriHostNameType.IPv4 || result == UriHostNameType.IPv6;
        }

        /// <summary>
        /// Verify that the domain DNS points to this server's public IP
        /// </summary>
        private static (bool IsValid, string Message) VerifyDnsPointsToThisServer(string domain)
        {
            try
            {
                var serverPublicIp = GetServerPublicIpAddress();
                if (string.IsNullOrEmpty(serverPublicIp))
                    return (false, "Could not determine server's public IP address");

                var domainIps = System.Net.Dns.GetHostAddresses(domain);
                if (domainIps == null || domainIps.Length == 0)
                    return (false, $"Could not resolve DNS for domain: {domain}");

                foreach (var ip in domainIps)
                {
                    if (ip.ToString() == serverPublicIp)
                        return (true, "DNS verification successful");
                }

                return (false, $"Domain {domain} does not point to this server. Domain IPs: {string.Join(", ", domainIps.Select(x => x.ToString()))}. Server IP: {serverPublicIp}");
            }
            catch (System.Net.Sockets.SocketException)
            {
                return (false, $"DNS resolution failed for domain: {domain}. Ensure the domain exists and DNS is properly configured.");
            }
            catch (Exception ex)
            {
                return (false, $"Error during DNS verification: {ex.Message}");
            }
        }

        /// <summary>
        /// Get the public IP address of this server by querying external services
        /// </summary>
        private static string GetServerPublicIpAddress()
        {
            try
            {
                var services = new[]
                {
                    "https://api.ipify.org",
                    "https://ipinfo.io/ip",
                    "https://icanhazip.com",
                    "https://checkip.amazonaws.com"
                };

                foreach (var service in services)
                {
                    try
                    {
                        using var client = new System.Net.WebClient();
                        client.Headers.Add("User-Agent", "Mozilla/5.0");
                        var ip = client.DownloadString(service).Trim();
                        if (System.Net.IPAddress.TryParse(ip, out _))
                            return ip;
                    }
                    catch { continue; }
                }
            }
            catch { }

            return null;
        }

        /// <summary>
        /// Renew an expired certificate via certbot
        /// </summary>
        private static (bool Success, string Message) RenewCertificate(string domain)
        {
            try
            {
                var renewResult = ExecuteSystemCommand("certbot renew --force-renewal --quiet", out bool renewSuccess);

                if (renewSuccess)
                    return (true, "Certificate renewed successfully");
                else
                    return (false, $"Certificate renewal failed: {renewResult}");
            }
            catch (Exception ex)
            {
                return (false, $"Error during certificate renewal: {ex.Message}");
            }
        }

        /// <summary>
        /// Setup automatic certificate renewal using cron and systemd timer
        /// </summary>
        private static void SetupAutoRenewal(string domain)
        {
            try
            {
                var cronList = ExecuteSystemCommand("crontab -l", out bool cronExists);
                var renewalCommand = "certbot renew --quiet";

                if (!cronExists || !cronList.Contains(renewalCommand))
                {
                    var cronEntry = $"0 0,12 * * * {renewalCommand}";
                    var existingCrons = cronExists ? cronList : string.Empty;
                    var newCronContent = existingCrons + Environment.NewLine + cronEntry;
                    ExecuteSystemCommand($"echo \"{newCronContent}\" | crontab -", out _);
                }

                if (SoftwareIsInstalled("systemctl"))
                {
                    ExecuteSystemCommand("systemctl enable certbot.timer", out _);
                    ExecuteSystemCommand("systemctl start certbot.timer", out _);
                }
            }
            catch { }
        }

        /// <summary>
        /// Create or update nginx server block to reverse-proxy requests to Kestrel.
        /// Skips if nginx is not installed or the config file already exists.
        /// </summary>
        private static void ConfigureNginxReverseProxy(string domain)
        {
            try
            {
                if (!SoftwareIsInstalled("nginx"))
                {
                    WriteSettingsLog("INFO", $"   [Nginx] Not installed — skipping reverse proxy for {domain}");
                    return;
                }

                var sitesAvailable = "/etc/nginx/sites-available";
                var sitesEnabled = "/etc/nginx/sites-enabled";
                var configPath = Path.Combine(sitesAvailable, domain);
                var enabledPath = Path.Combine(sitesEnabled, domain);

                Directory.CreateDirectory(sitesAvailable);
                Directory.CreateDirectory(sitesEnabled);

                if (File.Exists(configPath))
                {
                    WriteSettingsLog("INFO", $"   [Nginx] Config already exists for {domain}");

                    // Ensure the symlink is still present (may have been removed)
                    if (!File.Exists(enabledPath))
                    {
                        WriteSettingsLog("INFO", $"   [Nginx] Re-creating missing symlink: {enabledPath}");
                        File.CreateSymbolicLink(enabledPath, configPath);
                        var symlinkTest = ExecuteSystemCommand("nginx -t", out bool symlinkOk);
                        if (symlinkOk)
                            ExecuteSystemCommand("systemctl reload nginx", out _);
                    }

                    return;
                }

                var certPath = $"/etc/letsencrypt/live/{domain}/fullchain.pem";
                var keyPath = $"/etc/letsencrypt/live/{domain}/privkey.pem";

                var config = $@"server {{
    listen 80;
    server_name {domain} www.{domain};
    return 301 https://$server_name$request_uri;
}}

server {{
    listen 443 ssl;
    http2 on;
    server_name {domain} www.{domain};

    ssl_certificate {certPath};
    ssl_certificate_key {keyPath};

    location / {{
        proxy_pass http://127.0.0.1:{KestrelPort};
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection ""upgrade"";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}
}}
";
                File.WriteAllText(configPath, config);
                WriteSettingsLog("INFO", $"   [Nginx] Config written: {configPath}");

                if (!File.Exists(enabledPath))
                {
                    File.CreateSymbolicLink(enabledPath, configPath);
                    WriteSettingsLog("INFO", $"   [Nginx] Symlink created: {enabledPath}");
                }

                var testResult = ExecuteSystemCommand("nginx -t", out bool testOk);
                if (!testOk)
                {
                    WriteSettingsLog("WARN", $"   [Nginx] Config test FAILED: {testResult} — removing config");
                    File.Delete(configPath);
                    if (File.Exists(enabledPath)) File.Delete(enabledPath);
                    return;
                }

                WriteSettingsLog("INFO", $"   [Nginx] Config test passed");

                ExecuteSystemCommand("systemctl reload nginx", out _);
                WriteSettingsLog("INFO", $"   [Nginx] Reloaded successfully");
            }
            catch (Exception ex)
            {
                WriteSettingsLog("ERROR", $"   [Nginx] Failed: {ex.Message}");
            }
        }

        /// <summary>
        /// Update appsettings.json with Kestrel configuration using the configured port.
        ///
        /// The internal Kestrel endpoint is set to http://*:{KestrelPort} (all interfaces).
        /// An external reverse proxy (nginx / IIS / Caddy) handles SSL termination
        /// and forwards external requests to this internal endpoint.
        /// </summary>
        private static (bool Success, string Message, bool SettingsChanged) UpdateAppsettings(string domain, string certPath, string keyPath, string appsettingsPath, string[] addUrls)
        {
            try
            {
                var kestrelUrl = $"{KestrelBaseUrl}{KestrelPort}";

                WriteSettingsLog("INFO", $"   [UpdateAppsettings] Entering for domain: {domain}");
                WriteSettingsLog("INFO", $"   [UpdateAppsettings] certPath: {certPath}");
                WriteSettingsLog("INFO", $"   [UpdateAppsettings] keyPath: {keyPath}");
                WriteSettingsLog("INFO", $"   [UpdateAppsettings] appsettingsPath: {appsettingsPath}");
                WriteSettingsLog("INFO", $"   [UpdateAppsettings] Target Kestrel URL: {kestrelUrl}");

                if (!File.Exists(appsettingsPath))
                {
                    WriteSettingsLog("ERROR", $"   [UpdateAppsettings] X File not found: {appsettingsPath}");
                    return (false, $"appsettings.json not found at {appsettingsPath}", false);
                }

                WriteSettingsLog("INFO", $"   [UpdateAppsettings] / File exists");

                // Read and parse appsettings.json
                WriteSettingsLog("INFO", $"   [UpdateAppsettings] Reading and parsing appsettings.json...");
                var jsonContent = File.ReadAllText(appsettingsPath);
                using var document = JsonDocument.Parse(jsonContent, new JsonDocumentOptions
                {
                    CommentHandling = JsonCommentHandling.Skip,
                    AllowTrailingCommas = true
                });
                var root = document.RootElement;
                WriteSettingsLog("INFO", $"   [UpdateAppsettings] / JSON parsed successfully");

                // Check if Kestrel endpoint is already correctly configured with the right port
                bool needsUpdate = true;
                if (root.TryGetProperty("Kestrel", out var kestrelCheck))
                {
                    if (kestrelCheck.TryGetProperty("Endpoints", out var existingEndpointsCheck))
                    {
                        foreach (var endpoint in existingEndpointsCheck.EnumerateObject())
                        {
                            if (endpoint.Value.TryGetProperty("Url", out var urlProp))
                            {
                                var endpointUrl = urlProp.GetString();
                                if (endpointUrl == kestrelUrl)
                                {
                                    needsUpdate = false;
                                    break;
                                }
                            }
                        }
                    }
                }

                WriteSettingsLog("INFO", $"   [UpdateAppsettings] Kestrel on {kestrelUrl} needs update: {needsUpdate}");

                if (!needsUpdate)
                {
                    WriteSettingsLog("INFO", $"   [UpdateAppsettings] / Configuration already correct, no changes needed");
                    return (true, "appsettings.json already configured correctly", false);
                }

                WriteSettingsLog("INFO", $"   [UpdateAppsettings] Configuration needs update, building new JSON...");

                // Build new configuration
                WriteSettingsLog("INFO", $"   [UpdateAppsettings] Building new Kestrel configuration...");
                var settings = new Dictionary<string, object>();

                // Copy existing settings, excluding "Urls" to avoid redundancy with Kestrel configuration
                foreach (var property in root.EnumerateObject())
                {
                    if (property.Name != "Urls")
                    {
                        settings[property.Name] = JsonSerializer.Deserialize<object>(property.Value.GetRawText());
                    }
                }

                // Kestrel listens only on an internal HTTP endpoint on the configured port.
                // The external reverse proxy (nginx) handles SSL termination on port 443.
                var endpoints = new Dictionary<string, object>
                {
                    ["Http"] = new Dictionary<string, object>
                    {
                        ["Url"] = kestrelUrl
                    }
                };

                var kestrelConfig = new Dictionary<string, object> { ["Endpoints"] = endpoints };
                settings["Kestrel"] = kestrelConfig;
                WriteSettingsLog("INFO", $"   [UpdateAppsettings] / Kestrel configured on {kestrelUrl}");

                // Write updated configuration
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                };
                var updatedJson = JsonSerializer.Serialize(settings, options);

                // Write new configuration
                try
                {
                    File.WriteAllText(appsettingsPath, updatedJson);
                    WriteSettingsLog("INFO", $"   [UpdateAppsettings] / appsettings.json written successfully");
                    return (true, "appsettings.json updated successfully", true);
                }
                catch (Exception writeEx)
                {
                    WriteSettingsLog("ERROR", $"   [UpdateAppsettings] X Write failed: {writeEx.Message}");
                    throw new Exception($"Failed to write appsettings.json: {writeEx.Message}");
                }
            }
            catch (Exception ex)
            {
                WriteSettingsLog("ERROR", $"   [UpdateAppsettings] X Outer exception: {ex.GetType().Name}: {ex.Message}");
                if (ex.InnerException != null)
                    WriteSettingsLog("ERROR", $"   [UpdateAppsettings]   InnerException: {ex.InnerException.GetType().Name}: {ex.InnerException.Message}");
                return (false, $"Failed to update appsettings.json: {ex.Message}", false);
            }
        }

        /// <summary>
        /// Exits the current process so that systemd (or the process supervisor)
        /// can restart the application with the updated configuration.
        ///
        /// Designed to be called after appsettings.json has been modified.
        /// The application will be restarted by the process supervisor (systemd).
        /// No direct service manipulation is performed from this code.
        /// </summary>
        private static void RestartApplication()
        {
            try
            {
                var currentProcess = Process.GetCurrentProcess();
                var assemblyLocation = Assembly.GetEntryAssembly()?.Location;

                WriteSettingsLog("INFO", $"   [RestartApplication] Process ID: {currentProcess.Id}, Assembly: {assemblyLocation ?? "unknown"}");

                if (string.IsNullOrEmpty(assemblyLocation))
                {
                    assemblyLocation = currentProcess.MainModule?.FileName;
                    WriteSettingsLog("INFO", $"   [RestartApplication] Fallback assembly path: {assemblyLocation ?? "still null"}");
                }

                WriteSettingsLog("INFO", $"   [RestartApplication] Exiting process. systemd or supervisor will restart automatically.");

                Console.WriteLine("Application is restarting to apply HTTPS configuration...");
            }
            catch (Exception ex)
            {
                WriteSettingsLog("ERROR", $"   [RestartApplication] Failed: {ex.GetType().Name}: {ex.Message}");
                Console.WriteLine($"Warning: {ex.Message}");
            }

            // On Linux, ensure the systemd service exists before exiting so systemd
            // restarts the app with the updated configuration automatically.
            if (OperatingSystem.IsLinux() && !IsService())
            {
                WriteSettingsLog("INFO", $"   [RestartApplication] Service not found — creating it before exit...");
                Console.WriteLine("Creating systemd service before restart...");
                CreateService();
            }

            WriteSettingsLog("INFO", $"   [RestartApplication] Calling Environment.Exit(0)...");
            Environment.Exit(0);
        }

        // ─── Self-signed certificate for IP addresses ─────────────────────────────

        /// <summary>
        /// Configure HTTPS with self-signed certificate for IP addresses.
        /// Follows the same architecture: Kestrel listens on internal port {KestrelPort},
        /// and the reverse proxy handles external SSL.
        /// </summary>
        private static (HttpsConfigResult Result, string Message) ConfigureSelfSignedCertificate(string ipAddress, string appsettingsPath, string[] addUrls)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(appsettingsPath))
                {
                    appsettingsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appsettings.json");
                }

                var certDir = "/etc/ssl/certs";
                var keyDir = "/etc/ssl/private";
                var certPath = Path.Combine(certDir, $"selfsigned-{ipAddress}.crt");
                var keyPath = Path.Combine(keyDir, $"selfsigned-{ipAddress}.key");

                if (File.Exists(certPath) && File.Exists(keyPath))
                {
                    var certCheck = ExecuteSystemCommand($"openssl x509 -checkend 2592000 -noout -in {certPath}", out bool isValid);

                    if (isValid)
                    {
                        Console.WriteLine("Self-signed certificate already exists and is valid for at least 30 more days.");

                        var updateResult = UpdateAppsettings(ipAddress, certPath, keyPath, appsettingsPath, addUrls);
                        if (!updateResult.Success)
                            return (HttpsConfigResult.FailedToUpdateSettings, updateResult.Message);

                        if (updateResult.SettingsChanged)
                        {
                            RestartApplication();
                            return (HttpsConfigResult.SelfSignedCertificate, $"Self-signed certificate for {ipAddress} is valid. Kestrel configuration updated. Restarting...");
                        }

                        return (HttpsConfigResult.AlreadyConfigured, $"Self-signed certificate and Kestrel configuration for {ipAddress} are already correct");
                    }
                    else
                    {
                        Console.WriteLine("Self-signed certificate expired or near expiration. Regenerating...");
                    }
                }

                Directory.CreateDirectory(certDir);
                Directory.CreateDirectory(keyDir);

                Console.WriteLine($"Generating self-signed certificate for {ipAddress}...");

                var opensslCommand = $"openssl req -x509 -nodes -days 365 -newkey rsa:2048 " +
                    $"-keyout {keyPath} -out {certPath} " +
                    $"-subj \"/C=US/ST=State/L=City/O=Organization/CN={ipAddress}\" " +
                    $"-addext \"subjectAltName=IP:{ipAddress}\"";

                var result = ExecuteSystemCommand(opensslCommand, out bool success);

                if (!success)
                    return (HttpsConfigResult.Failed, $"Failed to generate self-signed certificate: {result}");

                ExecuteSystemCommand($"chmod 644 {certPath}", out _);
                ExecuteSystemCommand($"chmod 600 {keyPath}", out _);

                Console.WriteLine("Self-signed certificate generated successfully.");

                SetupSelfSignedAutoRenewal(ipAddress, certPath, keyPath, appsettingsPath);

                var settingsUpdateResult = UpdateAppsettings(ipAddress, certPath, keyPath, appsettingsPath, addUrls);
                if (!settingsUpdateResult.Success)
                    return (HttpsConfigResult.FailedToUpdateSettings, settingsUpdateResult.Message);

                RestartApplication();

                return (HttpsConfigResult.SelfSignedCertificate,
                    $"Self-signed certificate configured successfully for {ipAddress}. Certificate will auto-renew annually.");
            }
            catch (Exception ex)
            {
                return (HttpsConfigResult.Failed, $"Error during self-signed certificate configuration: {ex.Message}");
            }
        }

        /// <summary>
        /// Setup automatic renewal for self-signed certificates via cron
        /// </summary>
        private static void SetupSelfSignedAutoRenewal(string ipAddress, string certPath, string keyPath, string appsettingsPath)
        {
            try
            {
                var scriptPath = "/usr/local/bin/renew-selfsigned-cert.sh";
                var scriptContent = $@"#!/bin/bash
# Auto-renewal script for self-signed certificate

CERT_PATH=""{certPath}""
KEY_PATH=""{keyPath}""
IP_ADDRESS=""{ipAddress}""
APPSETTINGS_PATH=""{appsettingsPath}""

# Check if certificate expires in less than 30 days
if ! openssl x509 -checkend 2592000 -noout -in ""$CERT_PATH"" 2>/dev/null; then
    echo ""Certificate expiring soon. Regenerating...""

    # Generate new certificate
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout ""$KEY_PATH"" -out ""$CERT_PATH"" \
        -subj ""/C=US/ST=State/L=City/O=Organization/CN=$IP_ADDRESS"" \
        -addext ""subjectAltName=IP:$IP_ADDRESS"" 2>&1

    # Set permissions
    chmod 644 ""$CERT_PATH""
    chmod 600 ""$KEY_PATH""

    echo ""Self-signed certificate renewed successfully for $IP_ADDRESS""
fi
";

                File.WriteAllText(scriptPath, scriptContent);
                ExecuteSystemCommand($"chmod +x {scriptPath}", out _);

                var cronList = ExecuteSystemCommand("crontab -l", out bool cronExists);
                var renewalCommand = scriptPath;

                if (!cronExists || !cronList.Contains(renewalCommand))
                {
                    var cronEntry = $"0 0 1 * * {renewalCommand}";
                    var existingCrons = cronExists ? cronList : string.Empty;
                    var newCronContent = existingCrons + Environment.NewLine + cronEntry;
                    ExecuteSystemCommand($"echo \"{newCronContent}\" | crontab -", out _);
                    Console.WriteLine("Self-signed certificate auto-renewal configured (monthly check).");
                }
            }
            catch { }
        }
    }
}
