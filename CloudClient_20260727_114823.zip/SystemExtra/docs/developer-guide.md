# SystemExtra – Developer Guide

## Installation

```bash
dotnet add package SystemExtra
```

## Checking Administrator Privileges

```csharp
using SystemExtra;

if (!Util.IsAdmin())
{
    Console.Error.WriteLine("This application requires administrator privileges.");
    Environment.Exit(1);
}
```

## Single-Instance Guard

```csharp
if (Util.AppIsAlreadyRunning())
{
    Console.WriteLine("Another instance is already running.");
    Environment.Exit(0);
}
```

## Installing as a System Service

### Windows (SCM)

```csharp
using SystemExtra;

Service.Install(
    name:        "MyCloudService",
    displayName: "My Cloud Service",
    exe:         @"C:\Program Files\MyApp\MyApp.exe",
    args:        "--service"
);

Service.Start("MyCloudService");
```

### Linux (systemd)

`Service.Install` generates and installs a `.service` unit file in `/etc/systemd/system/` and calls `systemctl daemon-reload`.

### Uninstall

```csharp
Service.Stop("MyCloudService");
Service.Uninstall("MyCloudService");
```

## Disk Space Check

```csharp
long free = Disk.GetFreeSpace(@"C:\");   // bytes
long total = Disk.GetTotalSpace(@"C:\"); // bytes

if (free < 1_073_741_824) // < 1 GB
    Console.WriteLine("Low disk space!");
```

## Running Shell Commands

```csharp
var (exitCode, stdout, stderr) = Execute.Run("git", "status");
Console.WriteLine(stdout);
```

## User Management

```csharp
if (!UserManager.Exists("backupuser"))
    UserManager.Create("backupuser", "SecurePassword123!");
```

## HTTPS Certificate Configuration (ASP.NET Core)

```csharp
// In Program.cs, before app.Run()
ConfigureHttps.Apply(app, certPath: "/etc/ssl/my.pfx", certPassword: "secret");
```

## Kiosk Mode

```csharp
KioskMode.Enable();   // hides taskbar, locks to current window
// ...
KioskMode.Disable();  // restores normal desktop
```

## Persistent Settings

```csharp
var settings = new Settings("MyApp");

settings.Set("lastSyncTime", DateTime.UtcNow);
DateTime last = settings.Get<DateTime>("lastSyncTime");
```

Settings are stored as JSON in the application's data directory.

## Building

```powershell
dotnet build ..\..\SystemExtra\SystemExtra.csproj
```
