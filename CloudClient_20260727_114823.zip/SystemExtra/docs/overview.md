# SystemExtra – System Overview

## Purpose

**SystemExtra** is a cross-platform utility library that supplements the standard .NET class library with OS-level operations commonly needed by server and desktop applications running on both Windows and Linux.

## Features

| Module | Description |
|---|---|
| `Util.cs` | General utilities: admin check, single-instance guard, app path helpers |
| `Service.cs` | Install / uninstall / start / stop the application as a system service (Windows: SCM, Linux: systemd) |
| `UserManager.cs` | OS user management (create, delete, list users) |
| `Permission.cs` | File and directory permission management across platforms |
| `Disk.cs` | Disk information: free space, mount points, drive type |
| `Execute.cs` | Shell command execution with output capture |
| `Settings.cs` | Persistent application settings backed by the file system |
| `KioskMode.cs` | Lock the display to a single application (kiosk / digital signage) |
| `ConfigureHttps.cs` | Programmatic HTTPS certificate configuration for ASP.NET Core |
| `MacOSService.cs` | macOS-specific launchd service management |

## Typical Use Cases

- Checking for administrator/root privileges before performing privileged operations.
- Installing the application as a background service on Linux or Windows.
- Adjusting file permissions after installation.
- Querying available disk space before a backup or sync operation.
- Running the application in kiosk mode on embedded/dedicated hardware.

## Target Framework

**.NET Standard 2.1** (with platform-conditional implementations for Windows / Linux / macOS)
