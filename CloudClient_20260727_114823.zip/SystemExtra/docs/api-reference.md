# SystemExtra – API Reference

## Util

```csharp
public static class Util
```

| Method | Returns | Description |
|---|---|---|
| `IsAdmin()` | `bool` | `true` if the current process has admin/root privileges |
| `AppIsAlreadyRunning()` | `bool` | `true` if another instance of this application is running |
| `BaseDirectory` | `string` | Path to the application's base directory |

---

## Service

```csharp
public static class Service
```

| Method | Description |
|---|---|
| `Install(name, displayName, exe, args)` | Installs the application as a system service |
| `Uninstall(name)` | Removes the service |
| `Start(name)` | Starts the service |
| `Stop(name)` | Stops the service |
| `IsInstalled(name)` | Returns `true` if the service is installed |
| `IsRunning(name)` | Returns `true` if the service is running |

---

## UserManager

```csharp
public static class UserManager
```

| Method | Description |
|---|---|
| `Create(username, password)` | Creates a new OS user |
| `Delete(username)` | Deletes an OS user |
| `Exists(username)` | Returns `true` if the user exists |
| `ListUsers()` | Returns the list of OS users |

---

## Disk

```csharp
public static class Disk
```

| Method / Property | Description |
|---|---|
| `GetFreeSpace(path)` | Returns free bytes on the drive containing `path` |
| `GetTotalSpace(path)` | Returns total bytes on the drive |
| `GetDrives()` | Returns available drive information |

---

## Execute

```csharp
public static class Execute
```

| Method | Description |
|---|---|
| `Run(command, args)` | Executes a shell command; returns (exitCode, stdout, stderr) |
| `RunAsync(command, args)` | Async version |

---

## Settings

```csharp
public class Settings
```

| Method | Description |
|---|---|
| `Get<T>(key, defaultValue)` | Reads a persistent setting |
| `Set<T>(key, value)` | Writes a persistent setting |
| `Delete(key)` | Removes a setting |

---

## KioskMode

```csharp
public static class KioskMode
```

| Method | Description |
|---|---|
| `Enable()` | Enables kiosk mode (hides taskbar, locks to current app) |
| `Disable()` | Disables kiosk mode |

---

## ConfigureHttps

```csharp
public static class ConfigureHttps
```

Helpers to programmatically bind a certificate to an ASP.NET Core `WebApplication`:

```csharp
ConfigureHttps.Apply(app, certPath, certPassword);
```
