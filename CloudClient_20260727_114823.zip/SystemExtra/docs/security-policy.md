# SystemExtra – Security Policy

## Privilege Management

`SystemExtra` performs OS-level operations that may require elevated privileges: user creation (`UserManager.cs`), service installation (`Service.cs`), permission changes (`Permission.cs`), disk operations (`Disk.cs`), and HTTPS configuration (`ConfigureHttps.cs`).

**Principle of least privilege:**

- Only call `SystemExtra` methods that require elevation from an already-elevated context.
- Do not run the entire application as root/Administrator. Use `sudo`-specific calls or Windows privilege escalation for individual operations only.

## HTTPS Configuration

`ConfigureHttps.cs` runs certbot to obtain Let's Encrypt certificates. Ensure:

- Port 80 is only open during the certificate provisioning phase (or configure certbot with DNS challenge to avoid opening port 80).
- The certbot binary is obtained from the official distribution channel and verified.
- Certificate renewal is automated (certbot installs a renewal timer/cron job automatically).

## User Management (`UserManager.cs`)

Creating and locking OS user accounts (`LockUser`, `AddUser`) affects system security:

- Locked users cannot log in interactively — verify this is enforced by your OS configuration.
- Regularly audit the list of OS users created by the application and remove those no longer needed.

## Settings Persistence (`Settings.cs`)

Settings files may contain sensitive configuration. Apply appropriate file permissions (readable only by the service account) to the settings directory.

## Kiosk Mode (`KioskMode.cs`)

Kiosk mode restricts the desktop environment. Ensure the kiosk process does not run as root and cannot be escaped by the end user to access a privileged shell.

## External Process Execution (`Execute.cs`)

`Execute.cs` runs external processes. Never pass unsanitised user input as arguments to external processes. Validate all parameters with an allowlist before use.

## Reporting Vulnerabilities

Open a private GitHub Security Advisory in the repository. Do not disclose vulnerabilities publicly before a fix is available.
