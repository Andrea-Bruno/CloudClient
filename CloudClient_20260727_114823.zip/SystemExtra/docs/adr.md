# SystemExtra – Architecture Decision Records

## ADR-001: Cross-Platform OS Abstraction

**Date**: 2024  
**Status**: Accepted

### Context
The main applications (Cloud, CloudClient) run on Windows, Linux, and macOS. OS-specific operations (service install, user management, file permissions) use different APIs on each platform.

### Decision
Implement each feature in a single class with **`RuntimeInformation.IsOSPlatform`** guards. Callers use the same API on all platforms; the library handles the branching internally.

### Consequences
- **Positive**: calling code is platform-neutral.
- **Positive**: new platforms can be added by extending the guards in one place.
- **Negative**: all platform implementations live in the same assembly, increasing binary size slightly.

---

## ADR-002: Require Admin Check at Call Site

**Date**: 2024  
**Status**: Accepted

### Context
OS-level operations (service install, user management, permission changes) silently fail or throw cryptic exceptions if called without elevated privileges.

### Decision
`Util.IsAdmin()` is provided as a lightweight check. The calling application is responsible for verifying admin status before calling privileged methods, and for presenting a clear error to the user.

### Consequences
- **Positive**: separation of concerns: `SystemExtra` does not enforce elevation; the application decides how to handle the lack of it.
- **Negative**: callers that forget to check will receive OS-level exceptions rather than a clean library error.

---

## ADR-003: Shell Command Execution via `Execute`

**Date**: 2024  
**Status**: Accepted

### Context
Some OS operations (e.g., creating systemd units, running platform scripts) are most reliably done via shell commands rather than .NET P/Invoke.

### Decision
Provide `Execute.Run` / `Execute.RunAsync` as thin wrappers around `System.Diagnostics.Process` with captured stdout/stderr and exit code.

### Consequences
- **Positive**: simple, flexible; can run any OS command.
- **Negative**: shell injection risk if user-supplied strings are passed unsanitised to `args`; callers must sanitise inputs.
