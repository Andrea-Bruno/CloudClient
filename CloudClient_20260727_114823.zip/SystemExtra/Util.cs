﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace SystemExtra
{
    /// <summary>
    /// Add extra system functions, for cross-platform application development
    /// </summary>
    public static partial class Util
    {
        private static string GetFile(string scope)
        {
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                nameof(SystemExtra));
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            return scope != null ? Path.Combine(path, scope) : path;
        }

        private static string[] GetNetworks(string searchPattern)
        {
            var net = new DirectoryInfo("/sys/class/net");
            return !net.Exists
                ? Array.Empty<string>()
                : net.GetDirectories(searchPattern).Select(x => x.Name).ToArray();
        }

        private static string GetWiFiDeviceName() => GetNetworks("w*").LastOrDefault();

        /// <summary>
        /// Check if the WiFi module is present
        /// </summary>
        /// <returns></returns>
        public static bool WiFiExists()
        {
            return GetWiFiDeviceName() != null;
        }

        /// <summary>
        /// Configure WiFi Access Points and turn on the hotspot
        /// </summary>
        /// <param name="ssid">Network name</param>
        /// <param name="password">Hotspot password</param>
        /// <param name="enabled">If set to true/false, turn the hotspot on/off</param>
        /// <returns>Textual information on the execution of the command/returns>
        public static string SetHotspot(string ssid, string password, bool? enabled = null)
        {
            string result = null;
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                var ifname = GetWiFiDeviceName();
                if (ifname != null)
                {
                    Hotspot = true;
                    result += ExecuteCommand("nmcli",
                        "d wifi hotspot ifname " + ifname + " ssid \"" + ssid + "\" password \"" + password + "\"");
                    if (enabled != null)
                        result += Environment.NewLine + SetHotspot((bool)enabled);
                }
            }

            return result;
        }

        /// <summary>
        /// Turn hotspot on/off
        /// </summary>
        public static bool Hotspot
        {
            set { SetHotspot(value); }
        }

        /// <summary>
        /// Set hotspot status (on/off)
        /// </summary>
        /// <param name="status">on/true - off/false radio module status</param>
        /// <returns></returns>
        public static string SetHotspot(bool status)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                return ExecuteCommand("nmcli", "r wifi " + (status ? "on" : "off"));
            }

            return "OS not supported";
        }

        /// <summary>
        /// Get the list of devices that are connected to the hotspot, with their properties
        /// </summary>
        /// <returns>The list of devices connected to the hotspot</returns>
        public static List<Device> GetConnectedDevices()
        {
            var result = new List<Device>();
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    var ifname = GetWiFiDeviceName();
                    if (ifname != null)
                    {
                        var path = "/var/lib/NetworkManager/";
                        if (Directory.Exists(path))
                        {
                            var leasesFile = new DirectoryInfo(path).GetFiles("*" + ifname + ".leases")
                                .FirstOrDefault();
                            if (leasesFile != null)
                            {
                                var lines = File.ReadAllLines(leasesFile.FullName);
                                foreach (var line in lines)
                                {
                                    var parts = line.Split([' ']);
                                    var device = new Device() { IP = parts[2], Name = parts[3], MAC = parts[4] };
                                    result.Add(device);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(ex.StackTrace);
                }
            }

            return result;
        }

        /// <summary>
        /// Device data class
        /// </summary>
        public class Device
        {
            /// <summary>
            /// Device IP
            /// </summary>
            public string IP;

            /// <summary>
            /// Device name
            /// </summary>
            public string Name;

            /// <summary>
            /// Device MAC address
            /// </summary>
            public string MAC;
        }

        /// <summary>
        /// Open firewall port
        /// </summary>
        /// <param name="port">Port</param>
        /// <param name="allow">Set status: true = enable, false = disable</param>
        public static string SetFirewall(int port, bool allow)
        {
            if (Platform == PlatformCategory.Debian)
            {
                return ExecuteCommand("ufw " + (allow == false ? "delete " : "") + "allow " + port);

                //                var result = Bash("firewall-cmd --add-port " + port + "/tcp --permanent");
                //                Bash("firewall - cmd--reload");
            }
            else if (Platform == PlatformCategory.Windows)
            {
                // netsh advfirewall firewall add rule name="WHITELIST TCP" dir=in action=allow protocol=TCP localport=80,8080,8090
                return ExecuteCommand("netsh",
                    "advfirewall firewall add rule name=\"WHITELIST TCP\" dir=in action=" +
                    (allow ? "allow" : "block") + " protocol=tcp localport=" + port);
            }

            return "SetFirewall not supported in this OS";
        }

        /// <summary>
        /// Customize the operating system boot logo
        /// </summary>
        /// <param name="logoFullFileName">The path of the logo file to be set at boot, if null the default logo will be reset</param>
        public static void SetStartupLogo(string logoFullFileName)
        {
            var targetPath = new DirectoryInfo("/usr/share/plymouth/");
            var watermark = "/usr/share/plymouth/themes/spinner/watermark.png";
            if (targetPath.Exists)
            {
                if (logoFullFileName == null)
                {
                    _StartupLogoIsCustomized = false;
                    RestoreFile(targetPath.GetFiles("*._").FirstOrDefault());
                    RestoreFile(new FileInfo(watermark + "._"));
                }
                else
                {
                    var customLogo = new FileInfo(logoFullFileName);
                    if (customLogo.Exists)
                    {
                        var logoFile = targetPath.GetFiles("*.png").FirstOrDefault();
                        if (logoFile != null)
                            _StartupLogoIsCustomized = true;
                        ReplaceFile(logoFile, customLogo);
                        ReplaceFile(new FileInfo(watermark), customLogo);
                    }
                }
            }
        }

        private static bool? _StartupLogoIsCustomized;

        /// <summary>
        /// Returns true if the logo showing the operating system on boot has been customized
        /// </summary>
        /// <returns>True if the logo has been customized, otherwise false</returns>
        public static bool StartupLogoIsCustomized()
        {
            var targetPath = new DirectoryInfo("/usr/share/plymouth/");
            if (!targetPath.Exists)
                return false;
            if (_StartupLogoIsCustomized == null)
            {
                _StartupLogoIsCustomized = targetPath.GetFiles("*._").FirstOrDefault() != null;
            }

            return (bool)_StartupLogoIsCustomized;
        }

        private static void RestoreFile(FileInfo original)
        {
            if (original != null && original.Exists)
            {
                var name = new FileInfo(original.FullName.Substring(0, original.FullName.Length - 2));
                name.Delete();
                original.MoveTo(name.FullName);
            }
        }

        private static void ReplaceFile(FileInfo file, FileInfo newFile)
        {
            if (file != null && file.Exists && newFile.Exists)
            {
                var name = new FileInfo(file.FullName + "._");
                if (!name.Exists)
                {
                    File.Move(file.FullName, name.FullName);
                    File.Copy(newFile.FullName, file.FullName);
                }
            }
        }

        /// <summary>
        /// Ask for the location of a package
        /// </summary>
        /// <param name="fileName">The package name case sensitive</param>
        /// <returns>The location + packageName, or null if the package is not installed</returns>
        public static string PathOfSoftware(string fileName)
        {
            var result = ExecuteSystemCommand("type -P " + fileName);
            if (!result.Successful || string.IsNullOrEmpty(result.Output))
                return null;
            return result.Output;
        }

        /// <summary>
        /// Check if a software package has already been installed.
        /// </summary>
        /// <param name="packageName"></param>
        /// <returns>True id has already installed</returns>
        public static bool SoftwareIsInstalled(string packageName)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                var path = PathOfSoftware(packageName);
                return !string.IsNullOrEmpty(path);
            }

            return false;
        }

        private static PlatformCategory? _Platform;

        /// <summary>
        /// Returns the platform category in use (the mother distro)
        /// </summary>
        /// <returns>The mother distro</returns>
        public static PlatformCategory Platform
        {
            get
            {
                if (_Platform != null)
                    return (PlatformCategory)_Platform;
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    _Platform = PlatformCategory.Windows;
                }
                else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                {
                    _Platform = PlatformCategory.OSX;
                }
                else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                {
                    // https://linuxize.com/post/how-to-check-linux-version/
                    // var os = ExecuteCommand("cat", "/etc/*-release")?.ToLower();
                    FileInfo file = new FileInfo("/usr/lib/os-release");
                    if (!file.Exists)
                        file = new FileInfo("/etc/os-release");
                    if (!file.Exists)
                        file = new DirectoryInfo("/etc").GetFiles("*-release").FirstOrDefault();
                    if (file != null)
                    {
                        var os = File.ReadAllText(file.FullName);
                        if (os != null)
                        {
                            if (os.Contains("ubuntu") || os.Contains("debian") || os.Contains("ubuntu") ||
                                os.Contains("mint"))
                            {
                                _Platform = PlatformCategory.Debian;
                            }
                            else if (os.Contains("centos") || os.Contains("redhat"))
                            {
                                _Platform = PlatformCategory.Centos;
                            }
                            else if (os.Contains("clear-linux"))
                            {
                                _Platform = PlatformCategory.ClearLinux;
                            }
                        }
                    }
                }

                _Platform = _Platform ?? PlatformCategory.Unrecognized;
                return (PlatformCategory)_Platform;
            }
        }

        /// <summary>
        /// Mother distro
        /// </summary>
        public enum PlatformCategory
        {
            /// <summary>
            /// Unrecognized OS
            /// </summary>
            Unrecognized,

            /// <summary>
            /// Microsoft Windows
            /// </summary>
            Windows,

            /// <summary>
            /// Apple OSX
            /// </summary>
            OSX,

            /// <summary>
            /// Linux generic
            /// </summary>
            Linux,

            /// <summary>
            /// Debian and its derivatives
            /// </summary>
            Debian,

            /// <summary>
            /// Distros derived from centos
            /// </summary>
            Centos,

            /// <summary>
            /// Linux by Intel
            /// </summary>
            ClearLinux,
        }

        /// <summary>
        /// Check if a software package has already been installed and install a software package if necessary
        /// </summary>
        /// <param name="packageName">The name of the package to install</param>
        /// <param name="updateSystem">Run the system update before proceeding with the installation</param>
        public static void InstallPackage(string packageName, bool updateSystem = false)
        {
            if (!SoftwareIsInstalled(packageName))
            {
                if (Platform == PlatformCategory.Debian)
                {
                    // Bash("apt install " + packageName + " -y");
                    if (!Updated && updateSystem)
                    {
                        ExecuteCommand("apt", "update");
                        Updated = true;
                    }
                    Environment.SetEnvironmentVariable("DEBIAN_FRONTEND", "noninteractiv");
                    ExecuteCommand("apt", "install -y " + packageName);
                }
                else if (Platform == PlatformCategory.ClearLinux)
                {
                    if (!Updated && updateSystem)
                    {
                        ExecuteCommand("swupd", "update");
                        Updated = true;
                    }

                    // To install ffmpeg use: sudo swupd bundle-add kde-frameworks5-dev
                    var result = ExecuteCommand(packageName);
                    if (result != null && result.Contains(" sudo swupd "))
                    {
                        var parts = result.Split([" sudo swupd "], StringSplitOptions.None);
                        ExecuteCommand("swupd", parts[1] + " -y ");
                    }
                    else
                    {
                        ExecuteCommand("swupd", "bundle-add -y " + packageName);
                    }
                }
                else
                {
                    Console.WriteLine("Install package not supported for " + Platform.ToString());
                }
            }
        }

        private static bool Updated;

        /// <summary>
        /// Enable or disable local user access to files and directories
        /// </summary>
        /// <param name="allow">Set status</param>
        /// <param name="path">Path of file or directory</param>
        public static void SetUserAccess(bool allow, string path)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                var dir = new DirectoryInfo(path);
                var encrypted = dir.Attributes.HasFlag(FileAttributes.Encrypted);
                if (!encrypted)
                    dir.Attributes &= FileAttributes.Encrypted;

                var access = dir.GetAccessControl();
                // var identity = acces?.GetOwner(typeof(SecurityIdentifier));
                var identity = Environment.UserDomainName + @"\" + Environment.UserName;
                if (allow)
                {
                    access?.RemoveAccessRule(new FileSystemAccessRule(identity,
                        FileSystemRights.Read | FileSystemRights.DeleteSubdirectoriesAndFiles, AccessControlType.Deny));
                }
                else
                {
                    access?.AddAccessRule(new FileSystemAccessRule(identity,
                        FileSystemRights.Read | FileSystemRights.DeleteSubdirectoriesAndFiles, AccessControlType.Deny));
                }

                dir.SetAccessControl(access);
            }
        }

        private static string FullAppName => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, AppDomain.CurrentDomain.FriendlyName);



        /// <summary>
        /// Add a script to a file (if the script hasn't already been added)
        /// </summary>
        /// <param name="fullFileName">Script file</param>
        /// <param name="script">Script</param>
        /// <param name="onBottom">True to add it to the bottom, or false to add it to the beginning of the file</param>
        private static void AddScripts(string fullFileName, string script, bool onBottom = true)
        {
            script = Environment.NewLine + script + Environment.NewLine;
            string text = null;
            var file = new FileInfo(fullFileName);
            if (file.Exists)
            {
                text = File.ReadAllText(fullFileName);
            }
            else
            {
                file.Directory.Create();
            }

            if (text == null || !text.Contains(script))
            {
                if (onBottom)
                    text += script;
                else
                    text = script + text;
            }

            File.WriteAllText(fullFileName, text);
        }

        private static void RemoveScripts(string fullFileName, string script)
        {
            var file = new FileInfo(fullFileName);
            if (file.Exists)
            {
                script = Environment.NewLine + script + Environment.NewLine;
                string text = File.ReadAllText(fullFileName);
                text = text.Replace(script, "");
                File.WriteAllText(fullFileName, text);
            }
        }

        private static string AppPath()
        {
            var entry = new FileInfo(Assembly.GetEntryAssembly().Location);
            return entry.Directory.FullName;
        }

        /// <summary>
        /// The ssh key to verify on the client
        /// </summary>
        /// <returns></returns>
        /// <exception cref="PlatformNotSupportedException"></exception>
        public static string GetSSHKey()
        {
            if (!RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                throw new PlatformNotSupportedException();
            var text = ExecuteCommand("ssh-keygen", "-lf /etc/ssh/ssh_host_ed25519_key.pub", out int result);
            if (!string.IsNullOrEmpty(text))
                return text.Split(' ')[1];
            return null;
        }

        private static List<string> Grep(string textList, string searchString)
        {
            List<string> matchingLines = [];
            try
            {
                // Dividi il testo in righe
                string[] lines = textList.Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries);

                // Cerca la stringa in ogni riga
                foreach (string line in lines)
                {
                    if (line.Contains(searchString))
                    {
                        matchingLines.Add(line);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Errore: {e.Message}");
            }

            return matchingLines;
        }

        /// <summary>
        /// Show a system notification
        /// </summary>
        /// <param name="title">Title</param>
        /// <param name="message">Message</param>
        public static void Notify(string title, string message)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                var notyfy = $"\"notify-send\" \"{EscapeNameFile(title)}\" \"{EscapeNameFile(message)}\"";
                var cmd = $"runuser -l {CurrentUIUser()} -c \"{notyfy.Replace("\"", "\\\"")}\"";
                ExecuteCommand(cmd);
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                //string appleScript = $"display notification \"{message}\" with title \"{title}\"";
  
                // Escape the title and message
                string escapedTitle = title.Replace("\"", "\\\"").Replace("'", "\\'");
                string escapedMessage = message.Replace("\"", "\\\"").Replace("'", "\\'");

                // Create the AppleScript command
                string appleScript = $"display dialog \"{escapedMessage}\" with title \"{escapedTitle}\" buttons {{\"OK\"}} default button \"OK\"";
                var cmd = $"osascript -e '{appleScript}'"; // Use single quotes for cmd
                var result = ExecuteSystemCommand(cmd);
                if (!result.Successful)
                    Debugger.Break();
            }
            else
            {
                var cmd = $"notify-send \"{title}\" \"{message}\"";
                ExecuteCommand(cmd);
            }
        }

        /// <summary>
        /// Check if the current application is already running
        /// </summary>
        /// <returns>True if is already running</returns>
        static public bool AppIsAlreadyRunning()
        {
            var fullPathName = Assembly.GetEntryAssembly().Location;
            var appUniqueID = GetMd5HashHex(fullPathName);
            using var mutex = new Mutex(true, appUniqueID, out var createdNewMutex);
            return !createdNewMutex;
        }
        private static string GetMd5HashHex(string asciiInput)
        {
            using var md5 = MD5.Create();
            byte[] bytes = md5.ComputeHash(Encoding.ASCII.GetBytes(asciiInput));
            return BitConverter.ToString(bytes).Replace("-", "").ToLower();
        }

        /// <summary>
        /// TRue is the current application is a web application
        /// </summary>
        public static bool IsWebApplication => !RuntimeInformation.FrameworkDescription.Contains("Framework") && !RuntimeInformation.FrameworkDescription.Contains("Native");
    }
}