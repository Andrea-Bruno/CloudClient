﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Threading;

namespace SystemExtra
{
    public static partial class Util
    {
        /// <summary>
        /// Create a virtual disk and mount it at the specified location
        /// </summary>
        /// <param name="virtualDiskFullName">Path end name file name of Virtual Disk file</param>
        /// <param name="mountTo">Path o device letter</param>
        /// <param name="blockAccess">Blocks all users from using the directory which contains the virtual disk</param>
        public static void CreateVirtualDisk(string virtualDiskFullName, string mountTo, string password = null, string volumeName = "VirtualDisk", bool blockAccess = false)
        {
            if (!Directory.Exists(mountTo))
            {
                throw new Exception("Mount point not found!: " + mountTo);
            }
            var vdFile = new FileInfo(virtualDiskFullName);
            vdFile.Directory?.Create();
            var drive = new DriveInfo(vdFile.Directory.Root.FullName);
            var freeSpaceMB = drive.AvailableFreeSpace / 1000000;
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                if (!new string[] { ".vhdx", ".vhd" }.Contains(vdFile.Extension.ToLower()))
                    throw new Exception("File extension not allowed:" + virtualDiskFullName);
                var create = "create vdisk file=\"" + virtualDiskFullName + "\" maximum=" + freeSpaceMB +
                             " type=expandable";
                var attach = "attach vdisk";
                var partition = "create partition primary";
                var format = $"format fs=ntfs quick compress label={volumeName}";
                string assign;
                if (mountTo.Length <= 2)
                    assign = "assign letter=" + mountTo.ToCharArray()[0];
                else
                {
                    assign = "assign mount=" + mountTo;
                    //                    Directory.CreateDirectory(mountTo);
                }

                var commands = new string[] { create, attach, partition, format, assign };
                var script = Path.GetTempFileName();
                File.WriteAllLines(script, commands);
                ExecuteCommand("diskpart", "/s " + script);
                File.Delete(script);
                if (vdFile.DirectoryName != null)
                {
                    if (blockAccess)
                        BlockDirectoryAccess(vdFile.DirectoryName, true);
                }
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                if (!virtualDiskFullName.ToLower().EndsWith(".sparsebundle"))
                    throw new Exception("File extension not allowed: " + virtualDiskFullName);
                string createDiskCommand = $"hdiutil create -size {freeSpaceMB}m -type SPARSEBUNDLE -fs HFS+ -volname \"{volumeName}\" -encryption AES-256 -passphrase \"{password}\" \"{EscapeNameFile(virtualDiskFullName)}\"";

                static void enterPassword(bool successful, string output, Action<string> input)
                {
                    // Debugger.Break();
                    // input.Invoke(password);
                }

                var createResult = ExecuteCommand(true, createDiskCommand, null, enterPassword);
                if (!createResult.Successful)
                {
                    throw new Exception("Error create virtual disk: " + createResult.Output);
                }

                //Directory.CreateDirectory(mountTo);
                if (!MountVirtualDisk(virtualDiskFullName, mountTo, password))
                {
                    throw new Exception("Error mount virtual disk: " + virtualDiskFullName);
                }
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                if (!SoftwareIsInstalled("encfs"))
                    InstallPackage("encfs");

                Directory.CreateDirectory(virtualDiskFullName);
                Chmod(755, virtualDiskFullName);
                //Directory.CreateDirectory(mountTo);
                if (!MountVirtualDisk(virtualDiskFullName, mountTo, password))
                {
                    throw new Exception("Error mount virtual disk: " + virtualDiskFullName);
                }

                if (!IsMounted(mountTo))
                    throw new Exception("Error mount virtual disk: " + virtualDiskFullName);
                Thread.Sleep(1000); // in some case SetPermissions("755", mountTo) don't have effect!
                Chmod(755, mountTo);
            }
        }

        public static string EscapeNameFile(string nameFile)
        {
            var specialCharacters = @"\$&;'<>?*|:";
            foreach (char c in specialCharacters)
            {
                nameFile = nameFile.Replace(c.ToString(), @"\" + c.ToString());
            }

            return nameFile;
        }


        /// <summary>
        /// Deny access or remove the lock on a specified directory
        /// </summary>
        /// <param name="directory">Directory di block/unblock</param>
        /// <param name="block">True to block, false to unblock</param>
        public static void BlockDirectoryAccess(string directory, bool block = true)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                if (Debugger.IsAttached)
                    return;
                var dir = new DirectoryInfo(directory);
                var access =
                    dir.GetAccessControl(); // https://learn.microsoft.com/en-us/previous-versions/orphan-topics/ws.11/dn789205(v=ws.11)?redirectedfrom=MSDN
                //var identity = acces?.GetOwner(typeof(SecurityIdentifier));
                //var identity = Environment.UserDomainName + @"\" + Environment.UserName;
                var identity = "Users";

                var rights = FileSystemRights.ChangePermissions | FileSystemRights.TakeOwnership |
                             FileSystemRights.DeleteSubdirectoriesAndFiles | FileSystemRights.ListDirectory;
                access?.RemoveAccessRule(new FileSystemAccessRule(identity, rights, AccessControlType.Allow));
                if (block)
                {
                    access?.AddAccessRule(new FileSystemAccessRule(identity, rights, AccessControlType.Deny));
                    dir.Attributes = FileAttributes.System | FileAttributes.Hidden | FileAttributes.Encrypted |
                                     FileAttributes.NotContentIndexed;
                }
                else
                    access?.RemoveAccessRule(new FileSystemAccessRule(identity, rights, AccessControlType.Deny));

                dir.SetAccessControl(access);
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX) || RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                Chmod(600, directory);
            }
        }

        /// <summary>
        /// Returns true if a disk is mounted at a certain location
        /// </summary>
        /// <param name="mountPath">Location to search if the disk is mounted</param>
        /// <returns></returns>
        public static bool IsMounted(string mountPath)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                var directoryInfo = new DirectoryInfo(mountPath);
                if (!directoryInfo.Exists)
                    return false;
                FileSystemInfo target = null;
                for (int attempt = 0; attempt < 5; attempt++)
                {
                    try
                    {
                        target = directoryInfo.ResolveLinkTarget(true);
                        break;
                    }
                    catch (Exception)
                    {
                        Thread.Sleep(1000);
                    }
                }

                return target != null && target.Exists;
            }
            else
            {
                DriveInfo[] allDrives = DriveInfo.GetDrives();
                foreach (DriveInfo d in allDrives)
                {
                    if (d.IsReady && d.RootDirectory.FullName == mountPath)
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        /// <summary>
        /// Mount a directory to a specific path. You get a clone of the directory
        /// </summary>
        /// <param name="source">Old directory</param>
        /// <param name="target">New directory</param>
        /// <returns>True if the operation was performed correctly, otherwise false</returns>
        /// <exception cref="PlatformNotSupportedException"></exception>
        public static bool MountBind(string source, string target)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                // https://www.man7.org/linux/man-pages/man8/mount.8.html
                if (!RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                    throw new PlatformNotSupportedException();
                ExecuteCommand("mount --bind " + source + " " + target, out int result);
                return result == 0;
            }

            return false;
        }

        /// <summary>
        /// Unmount mount point
        /// </summary>
        /// <param name="target">Path where it was mounted</param>
        /// <returns>True if the operation was performed correctly, otherwise false</returns>
        /// <exception cref="PlatformNotSupportedException"></exception>
        public static bool Unmount(string target)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                if (!RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                    throw new PlatformNotSupportedException();
                ExecuteCommand("unmount " + target, out int result);
                return result == 0;
            }

            return false;
        }

        /// <summary>
        /// Mount a virtual disk at the specified location
        /// </summary>
        /// <param name="virtualDiskFullName">Path end name file name of Virtual Disk file</param>
        /// <param name="mountTo">Path o device letter</param>
        /// <param name="password">Password for encryption</param>
        public static bool MountVirtualDisk(string virtualDiskFullName, string mountTo, string password = null)
        {
            if (IsMounted(mountTo))
                return false;
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                var VhdFile = new FileInfo(virtualDiskFullName);
                if (!new string[] { ".vhdx", ".vhd" }.Contains(VhdFile.Extension.ToLower()))
                    throw new Exception("File not allowed:" + virtualDiskFullName);
                var select = "select vdisk file=\"" + virtualDiskFullName + "\"";
                //var detach = "detach vdisk";
                var attach = "attach vdisk noerr"; // prevent error if is already attached
                var selectPartition = "select partition 1"; // if already attached, select the partition to assign a letter or mount point (otherwise it wont work)
                string assign;
                if (mountTo.Length <= 2)
                    assign = "assign letter=" + mountTo.ToCharArray()[0];
                else
                {
                    assign = "assign mount=" + mountTo;
                    Directory.CreateDirectory(mountTo);
                }

                var commands = new string[] { select, attach, select, selectPartition, assign };
                var script = Path.GetTempFileName();
                File.WriteAllLines(script, commands);
                ExecuteCommand("diskpart", "/s " + script);
                File.Delete(script);
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                var dir = Directory.CreateDirectory(mountTo);
                dir.Refresh();
                if (!Directory.Exists(mountTo))
                {
                    Debug.WriteLine("Path noth exist for:" + mountTo);
                    Debugger.Break();
                }

                string mountDiskCommand = $"hdiutil attach \"{EscapeNameFile(virtualDiskFullName)}\" -mountpoint \"{EscapeNameFile(mountTo)}\" -passphrase \"{password}\"";
                var mountResult = ExecuteSystemCommand(mountDiskCommand);
                if (!mountResult.Successful)
                    Debugger.Break();
                return mountResult.Successful;
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                var dir = Directory.CreateDirectory(mountTo);
                dir.Refresh();
                if (!Directory.Exists(mountTo))
                {
                    Debug.WriteLine("Path not exist for:" + mountTo);
                    Debugger.Break();
                }

                // note: --public allow all user to access, otherwise it is accessible only to the root user (if is mounted by root user)
                string mountDiskCommand = $"encfs --public --standard --extpass=\"echo {password}\" \"{EscapeNameFile(virtualDiskFullName)}\" \"{EscapeNameFile(mountTo)}\"";
                var mountResult = ExecuteSystemCommand(mountDiskCommand);
                if (!mountResult.Successful)
                    Debugger.Break();
                return mountResult.Successful;
            }

            return true;
        }

        /// <summary>
        /// Unmount a virtual disk
        /// </summary>
        /// <param name="mountPoint">Path of mount point</param>
        public static bool UnmountVirtualDisk(string mountPoint)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                throw new Exception("Unsupported OS: use UnmountVirtualDiskWindows");
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                string unmountCommand = $"hdiutil detach \"{EscapeNameFile(mountPoint)}\"";
                var result = ExecuteSystemCommand(unmountCommand);
                return result.Successful;
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                string unmountCommand = $"fusermount -u \"{EscapeNameFile(mountPoint)}\"";
                var result = ExecuteSystemCommand(unmountCommand);
                return result.Successful;
            }

            return false;
        }

        /// <summary>
        /// Unmount a virtual disk
        /// </summary>
        /// <param name="virtualDiskFullName">Path of mount point</param>
        public static bool UnmountVirtualDiskWindow(string virtualDiskFullName)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                var VhdFile = new FileInfo(virtualDiskFullName);
                if (!new string[] { ".vhdx", ".vhd" }.Contains(VhdFile.Extension.ToLower()))
                    throw new Exception("File not allowed:" + virtualDiskFullName);
                var select = "select vdisk file=\"" + virtualDiskFullName + "\"";
                var detach = "detach vdisk";
                var commands = new string[] { select, detach };
                var script = Path.GetTempFileName();
                File.WriteAllLines(script, commands);
                ExecuteCommand("diskpart", "/s " + script);
                File.Delete(script);
                return true;
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                throw new Exception("Unsupported OS: use UnmountVirtualDisk");
            }

            return false;
        }
    }
}