﻿using System;
using System.Diagnostics;
using System.IO;

namespace SystemExtra
{
    internal class MacOSService
    {
        public static bool CreateService(string serviceName, string appFullPath)
        {
            var array = appFullPath.Split(' ');
            var arrayTags = "";
            foreach (var item in array)
            {
                arrayTags += "<string>" + item.Replace("\"", "").Replace("*", "\"*\"") + "</string>\n";
            }

            string plistContent = $@"<?xml version=""1.0"" encoding=""UTF-8""?>
<!DOCTYPE plist PUBLIC ""-//Apple//DTD PLIST 1.0//EN"" ""http://www.apple.com/DTDs/PropertyList-1.0.dtd"">
<plist version=""1.0"">
<dict>
    <key>Label</key>
    <string>{serviceName}</string>
    <key>ProgramArguments</key>
    <array>
{arrayTags}
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>UserName</key>
    <string>root</string>
</dict>
</plist>
";

            string plistPath = $"/Library/LaunchDaemons/{serviceName}.plist";
            var serviceIsCreated = !File.Exists(plistPath);
            File.WriteAllText(plistPath, plistContent);

            SetService(true, serviceName);

            //var process = new Process
            //{
            //    StartInfo = new ProcessStartInfo
            //    {
            //        FileName = "sudo",
            //        Arguments = $"launchctl load {plistPath}",
            //        RedirectStandardOutput = true,
            //        UseShellExecute = false,
            //        CreateNoWindow = true
            //    }
            //};
            //process.Start();
            //process.WaitForExit();
            return serviceIsCreated;
        }

        public static bool IsServiceRunning(string serviceName)
        {
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "launchctl",
                    Arguments = "list",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };
            process.Start();
            var output = process.StandardOutput.ReadToEnd();
            process.WaitForExit();
            return output.Contains(serviceName);
        }

        public static void SetService(bool enable, string serviceName)
        {
            string action = null;
            string param = null; 
            for (int step = 0; step <= 1; step++)
            {
                if (step == 0)
                {
                    action = enable ? "enable" : "disable";
                    param = $"system/{serviceName}";
                }
                else if (step == 1) 
                {
                    action = enable ? "load" : "unload";
                    param = $"/Library/LaunchDaemons/{serviceName}.plist";
                }
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = "sudo",
                        Arguments = $"launchctl {action} {param}",
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        UseShellExecute = false,
                        CreateNoWindow = true
                    }
                };
                process.Start();
                var output = process.StandardOutput.ReadToEnd();
                var error = process.StandardError.ReadToEnd();
                process.WaitForExit();

                if (process.ExitCode == 0)
                {
                    // Successful
                }
                else
                {
                    // Error
                }
            }       
        }
    }
}