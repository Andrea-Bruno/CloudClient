﻿using System;
using System.Linq;
using System.Runtime.InteropServices;
using System.IO;
using System.Threading.Tasks;

namespace SystemExtra
{
    public static partial class Util
    {

        //[DllImport("libc", SetLastError = true)]
        //private static extern int chmod(string path, uint mode);

        /// <summary>
        /// Simulate a Unix chmod terminal command
        /// </summary>
        /// <param name="permissionsMode">Permissions mode to set (e.g., "755", "644", "+x", "u=rw")</param>
        /// <param name="filePath">Full file name to set</param>
        /// <returns>True if the operation was successful, otherwise false</returns>
        public static bool Chmod(string permissionsMode, string filePath)
        {
            // Check if the operating system is Unix-like
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return false; // OS not supported
            }
            try
            {
#if NET6_0
                throw new NotSupportedException();
#else

                var uintMode = PermissionsLiteralToUnixOctal(permissionsMode);
                File.SetUnixFileMode(filePath, (UnixFileMode)uintMode);
#endif
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }


        /// <summary>
        /// Simulate a Unix chmod terminal command
        /// </summary>
        /// <param name="permissionsMode">Permissions mode to set (e.g., 755, 644)</param>
        /// <param name="filePath">Full file name to set</param>
        /// <returns>True if the operation was successful, otherwise false</returns>
        public static bool Chmod(int permissionsMode, string filePath)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return false; // OS not supported
            }
            try
            {
                var uintMode = PermissionsBase10ToUnixOctal(permissionsMode);
                File.SetUnixFileMode(filePath, (UnixFileMode)uintMode);
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Convert a Unix permissions mode string to a uint representation
        /// </summary>
        /// <param name="permissionsMode">Permissions mode string (e.g., "755", "644", "+x", "u=rw")</param>
        /// <returns>uint representation of the permissions mode</returns>
        public static uint PermissionsLiteralToUnixOctal(string permissionsMode)
        {
            if (string.IsNullOrEmpty(permissionsMode))
            {
                throw new ArgumentException("Permission mode cannot be null or empty.");
            }

            // If the mode is numeric (3 or 4 digits)
            if (permissionsMode.All(char.IsDigit) && (permissionsMode.Length == 3 || permissionsMode.Length == 4))
            {
                return ParseNumericMode(permissionsMode);
            }

            // If the mode is a symbolic command (e.g., "+x", "u=rw")
            return ParseSymbolicMode(permissionsMode);
        }

        /// <summary>
        /// Converts Unix permissions from decimal (base 10) to their octal (base 8) representation.
        /// </summary>
        /// <param name="base10Permissions">Permissions in decimal format (e.g., 511, 420).</param>
        /// <returns>The octal representation of the permissions as a uint (e.g., 777, 644).</returns>
        public static uint PermissionsBase10ToUnixOctal(int base10Permissions)
        {
            var o = base10Permissions % 10;
            base10Permissions /= 10;
            var g = base10Permissions % 10;
            base10Permissions /= 10;
            var a = base10Permissions % 10;
            var result = o | g << 3 | a << 6;
            return (uint)result;
        }

        /// <summary>
        /// Converts Unix permissions from octal (base 8) to their decimal (base 10) representation.
        /// </summary>
        /// <param name="octalPermissions">Permissions in octal format (e.g., 777, 644).</param>
        /// <returns>The decimal representation of the permissions as an int (e.g., 511, 420).</returns>
        public static int UnixOctalToPermissionsBase10(uint octalPermissions)
        {
            octalPermissions = octalPermissions & 0xFFF; // Consider only the permission bits
            var o = octalPermissions & 7;
            var g = (octalPermissions >> 3) & 7;
            var a = (octalPermissions >> 6) & 7;
            var result = o + g * 10 + a * 100;
            return (int)result;
        }

        /// <summary>
        /// Parse a numeric permission mode (e.g., "755", "0640")
        /// </summary>
        /// <param name="permissionsMode">Numeric permission mode string</param>
        /// <returns>uint representation of the permission mode in Unix octal format</returns>
        private static uint ParseNumericMode(string permissionsMode)
        {
            uint mode = 0;

            // If the mode is 4 digits, the first digit represents special flags
            if (permissionsMode.Length == 4)
            {
                mode |= (uint)(permissionsMode[0] - '0') << 9; // Special flags (setuid, setgid, sticky bit)
            }

            // Convert the last 3 digits into standard permissions
            int offset = permissionsMode.Length == 4 ? 1 : 0;
            mode |= (uint)(permissionsMode[offset + 0] - '0') << 6; // Owner permissions
            mode |= (uint)(permissionsMode[offset + 1] - '0') << 3; // Group permissions
            mode |= (uint)(permissionsMode[offset + 2] - '0');      // Others permissions
            return mode;
        }

        /// <summary>
        /// Parse a symbolic permissions mode (e.g., "+x", "u=rw")
        /// </summary>
        /// <param name="permissionsMode">Symbolic permissions mode string</param>
        /// <returns>uint representation of the permissions mode</returns>
        private static uint ParseSymbolicMode(string permissionsMode)
        {
            uint mode = 0;

            // Example support for "+x" (add execute permission for all)
            if (permissionsMode == "+x")
            {
                mode |= 0x49; // Set execute bits for owner, group, and others (--x--x--x)
            }
            // Example support for "u=rw" (set read and write permissions for owner)
            else if (permissionsMode == "u=rw")
            {
                mode |= 0x180; // Set read and write bits for owner (rw-------)
            }
            // Add more cases here...
            else
            {
                throw new ArgumentException($"Unsupported permissions mode: {permissionsMode}");
            }
            return mode;
        }


        /// <summary>
        /// Reads the permissions of a file or directory on Unix-like systems.
        /// </summary>
        /// <param name="filePath">Full path of the file or directory.</param>
        /// <returns>A string representing the permissions in Unix format (e.g., "rwxr-xr--"), or null if the operation fails.</returns>
        public static string GetFilePermissionsLiteral(string filePath)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                return null; // OS not supported
            if (!File.Exists(filePath))
                return null; // Error while reading file information 
            var octal = GetFilePermissionsOctal(filePath);
            return PermissionsToLiteral(octal);
        }


        /// <summary>
        /// Reads the permissions of a file or directory on Unix-like systems.
        /// </summary>
        /// <param name="filePath">Full path of the file or directory.</param>
        /// <returns>A number representing the permissions in Unix format (e.g., 777, 644), or -1 if the operation fails.</returns>
        public static int GetFilePermissions(string filePath)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                return -1; // OS not supported
            if (!File.Exists(filePath))
                return -1; // Error while reading file information
            var octal = GetFilePermissionsOctal(filePath);
            // Convert permissions to Base 10
            return UnixOctalToPermissionsBase10(octal);
        }

        /// <summary>
        /// Reads the permissions of a file or directory on Unix-like systems.
        /// </summary>
        /// <param name="filePath">Full path of the file or directory.</param>
        /// <returns>An octal value representing the permissions.</returns>
        public static uint GetFilePermissionsOctal(string filePath)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                return 0;
#if NET6_0
            throw new NotSupportedException();
#else
            var fileMode = File.GetUnixFileMode(filePath);
            var octal = (uint)fileMode;
            return octal;
#endif
        }

        /// <summary>
        /// Converts permissions from a numeric value to a human-readable string.
        /// </summary>
        /// <param name="permissions">Permissions in numeric format.</param>
        /// <returns>A string representing the permissions (e.g., "rwxr-xr--").</returns>
        private static string PermissionsToLiteral(uint permissions)
        {
            char[] permChars =
            [
                // Owner permissions
                (permissions & 0x100) != 0 ? 'r' : '-',
                (permissions & 0x80) != 0 ? 'w' : '-',
                (permissions & 0x40) != 0 ? 'x' : '-',
                // Group permissions
                (permissions & 0x20) != 0 ? 'r' : '-',
                (permissions & 0x10) != 0 ? 'w' : '-',
                (permissions & 0x8) != 0 ? 'x' : '-',
                // Others permissions
                (permissions & 0x4) != 0 ? 'r' : '-',
                (permissions & 0x2) != 0 ? 'w' : '-',
                (permissions & 0x1) != 0 ? 'x' : '-',
            ];
            return new string(permChars);
        }
    }
}
