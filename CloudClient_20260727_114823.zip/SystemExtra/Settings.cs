﻿
using System;
using System.Collections.Generic;
using System.IO;

namespace SystemExtra
{
    /// <summary>
    /// Class for handling settings files
    /// </summary>
    public class Settings
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="fullFileName">File setting to handling</param>
        public Settings(string fullFileName)
        {
            FullFileName = fullFileName;
        }
        private readonly string FullFileName;
        private void Save(string[] lines)
        {
            var path = new FileInfo(FullFileName).Directory;
            if (path.Exists)
            {
                Directory.CreateDirectory(path.FullName);
            }
            File.WriteAllLines(FullFileName, lines);
        }

        private string[] Lines { get { return File.Exists(FullFileName) ? File.ReadAllLines(FullFileName) : Array.Empty<string>(); } }
        private static void CheckLine(string line, out string key, out string value, out bool isEnabled)
        {
            if (line.StartsWith("#"))
            {
                isEnabled = false;
                line = line.Substring(1);
            }
            else
            {
                isEnabled = true;
            }
            if (!line.Contains("="))
                line += "=";
            var separator = line.IndexOf('=');
            key = line.Substring(0, separator).Trim();
            value = line.Substring(separator + 1).Trim();
        }
        private static string CreateLine(string key, object value, bool isEnabled = true)
        {
            return (isEnabled ? "" : "# ") + key + "=" + value;
        }

        private bool FindLine(string key, out string[] lines, out int index, out string value, out bool isEnabled)
        {
            key = key.Trim();
            lines = Lines;
            index = -1;
            value = null;
            isEnabled = false;
            for (int i = 0; i < lines.Length; i++)
            {
                var line = lines[i];
                CheckLine(line, out string xkey, out string xValue, out bool xIsEnabled);
                if (xkey == key)
                {
                    index = i;
                    value = xValue;
                    isEnabled = xIsEnabled;
                    if (isEnabled)
                        return true;
                }
            }
            return index != -1;
        }

        /// <summary>
        /// Get a key value of setup text file
        /// </summary>
        /// <param name="key">Key</param>
        /// <param name="lines">Return file splited by lines</param>
        /// <param name="index">Return Line index of this setting</param>
        /// <param name="isEnabled">Return true if this parameter is enabled</param>
        /// <returns>Value of key</returns>
        public string GetValue(string key, out string[] lines, out int index, out bool isEnabled)
        {
            FindLine(key, out lines, out index, out string value, out isEnabled);
            return value;
        }

        /// <summary>
        /// Set a specific line of the settings file
        /// </summary>
        /// <param name="index">Index of line to setting</param>
        /// <param name="key">Key to set</param>
        /// <param name="value">Value of key</param>
        /// <param name="isEnabled">True if you want to enable this setting</param>
        public void SetLine(int index, string key, object value, bool isEnabled = true)
        {
            var lines = Lines;
            lines[index] = CreateLine(key, value, isEnabled);
            Save(lines);
        }

        /// <summary>
        /// Set a key value in a setup text file
        /// </summary>
        /// <param name="key">Key to set</param>
        /// <param name="value">Value of key</param>
        /// <param name="isEnabled">True if you want to enable this setting</param>
        public void SetValue(string key, object value, bool isEnabled = true)
        {

            string line = CreateLine(key, value, isEnabled);
            if (FindLine(key, out string[] lines, out int index, out string _, out _))
            {
                lines[index] = line;
            }
            else
            {
                Array.Resize(ref lines, lines.Length + 1);
                lines[lines.Length - 1] = line;
            }
            Save(lines);
        }

        /// <summary>
        /// Add a parameter to the value
        /// </summary>
        /// <param name="key">Kay</param>
        /// <param name="parameter">Parameter to add</param>
        /// <param name="paramValue">Parameter value to add</param>
        /// <param name="isEnabled">True if you want to enable this setting</param>
        public void AddParameter(string key, string parameter, object paramValue = null, bool isEnabled = true)
        {
            var value = GetValue(key, out _, out _, out _);
            var keyValue = KeyValueCollection(value);
            if (keyValue.ContainsKey(parameter))
            {
                keyValue.Remove(parameter);
            }
            keyValue.Add(parameter, paramValue.ToString());
            value = KeyValueCollectionToString(keyValue);
            SetValue(key, value, isEnabled);

        }

        /// <summary>
        /// Remove a parameter to the value
        /// </summary>
        /// <param name="key">Kay</param>
        /// <param name="parameter">Parameter to remove</param>
        public void RempoveParameter(string key, string parameter)
        {
            var value = GetValue(key, out _, out _, out bool isEnabled);
            var keyValue = KeyValueCollection(value);
            if (keyValue.ContainsKey(parameter))
            {
                keyValue.Remove(parameter);
            }
            value = KeyValueCollectionToString(keyValue);
            SetValue(key, value, isEnabled);
        }

        private static Dictionary<string, string> KeyValueCollection(string parameters)
        {
            var result = new Dictionary<string, string>();
            if (parameters == null)
                return result;
            parameters = parameters.Trim('"');
            var parts = parameters.Split(' ');
            foreach (var part in parts)
            {
                if (!part.Contains("="))
                    result.Add(part, null);
                else
                {
                    var kv = part.Split('=');
                    result.Add(kv[0], kv[1]);
                }
            }
            return result;
        }

        private static string KeyValueCollectionToString(Dictionary<string, string> keyValueCollection)
        {
            var result = "";
            foreach (var kv in keyValueCollection)
            {
                result += " " + kv.Key + (kv.Value == null ? "" : "=" + kv.Value);
            }
            return '"' + result.Trim() + '"';
        }
    }
}
