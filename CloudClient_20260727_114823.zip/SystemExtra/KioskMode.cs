﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace SystemExtra
{
    public static partial class Util
    {
        /// <summary>
        /// Browser engine
        /// </summary>
        public enum Browser
        {
            Firefox,
            Chromium_browser,
        }

        /// <summary>
        /// Browser to use in kiosk mode
        /// </summary>
        public static Browser CurrentBrowser = (Platform == PlatformCategory.ClearLinux || Platform == PlatformCategory.Debian) ? Browser.Firefox : Browser.Chromium_browser;

        /// <summary>
        /// Set the application in stand alone mode (Kiosk mode)
        /// </summary>
        public static bool KioskMode
        {
            get => File.Exists(GetFile(nameof(KioskMode))) && bool.Parse(File.ReadAllText(GetFile(nameof(KioskMode))));
            set
            {
                if (value != KioskMode)
                {
                    var isFirstStartup = !File.Exists(GetFile(nameof(KioskMode)));
                    if (Debugger.IsAttached)
                        return;
                    // Create a specific session
                    if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                    {
                        // ===== Fixes block on boot: https://askubuntu.com/questions/1321968/ubuntu-server-20-04-2-lts-hangs-after-bootup-cloud-init-1781-yyyy-mm-dd-h
                        var disabledCloudInit = new FileInfo("/etc/cloud/cloud-init.disabled");
                        if (disabledCloudInit.Directory.Exists)
                            File.WriteAllText(disabledCloudInit.FullName, null);
                        if (value && isFirstStartup)
                        {
                            // Disallow error message at startup [CRASH SYSTEM ON UBUNTU SERVER]
                            //var grubSettings = new Settings("/etc/default/grub");
                            //grubSettings.AddParameter("GRUB_CMDLINE_LINUX_DEFAULT", "acpi", "off");
                            //grubSettings.AddParameter("GRUB_CMDLINE_LINUX_DEFAULT", "loglevel", 0);
                            //ExecuteCommand("update-grub");
                            if (Platform == PlatformCategory.Debian)
                            {
                                // ExecuteSystemCommand(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "install-firefox.sh"));
                            }
                            else
                            {
                                var browserPackage = CurrentBrowser.ToString().Replace('_', '-').ToLower();
                                InstallPackage(browserPackage);
                            }
                            BrowserSetForKioskMode(StartupPage);
                        }

                        var splashMp4 = "splash.mp4";
                        var splash = File.Exists(splashMp4);
                        string homePage;
                        if (splash)
                        {
                            var splashHtml = "splash.html";
                            var htmlFile = Path.Combine(FirstHome(), splashHtml);
                            if (isFirstStartup)
                            {
                                var html = File.ReadAllText(Path.Combine(AppPath(), splashHtml));
                                html = html.Replace("http://localhost:5000", StartupPage);
                                File.WriteAllText(htmlFile, html);
                                var homeSplashPath = Path.Combine(FirstHome(), splashMp4);
                                if (!File.Exists(homeSplashPath))
                                    File.Copy(Path.Combine(AppPath(), splashMp4), homeSplashPath);
                            }
                            homePage = "file://" + htmlFile;
                        }
                        else
                        {
                            homePage = StartupPage;
                        }

                        var resX = "$resx"; // 1280;
                        var resY = "$resy"; // 1024;
                        string runBrowser;
                        if (CurrentBrowser == Browser.Firefox)
                        {
                            runBrowser = "firefox --setDefaultBrowser -width " + resX + " -height " + resY + " --kiosk --private-window " + homePage;
                        }
                        else
                        {
                            runBrowser = "chromium-browser " + homePage + " --window-size=" + resX + "," + resY + " --start-fullscreen --kiosk --incognito --noerrdialogs --disable-translate --no-first-run --fast --fast-start --disable-infobars --disable-features=TranslateUI --disk-cache-dir=/dev/null  --password-store=basic";
                        }

                        if (Directory.Exists(SystemEnvironment.AccountServicesUsers))
                        {
                            // ============== LINUX DESKTOP ================
                            var desktopAutoStart = new FileInfo(SystemEnvironment.DesktopEnvironment + CurrentAppName + ".desktop");
                            if (!value)
                            {
                                if (desktopAutoStart.Exists)
                                    desktopAutoStart.Delete();
                            }
                            else if (!desktopAutoStart.Exists)
                            {
                                runBrowser.Replace(resX, "1280");
                                runBrowser.Replace(resY, "1024");
                                var configuration = "[Desktop Entry]\n" +
                                                    "Type=Application\n" +
                                                    "Exec=" + runBrowser + "\n" +
                                                    "Name=" + CurrentAppName + "\n" +
                                                    "Comment=Start \" + AppName + \" in kiosk mode\n";

                                // add 5 sec. delay (Wait for service start)
                                var redirectCode = "data:text/html,<meta http-equiv='refresh' content='5; url=" + homePage + "'>"; // This trick adds a redirect into the url that pauses 
                                redirectCode = redirectCode.Replace(" ", "%20");
                                File.WriteAllText(desktopAutoStart.FullName, configuration);
                                SetStartupSessionForCurrentUser(value);
                            }
                        }
                        else // ============== LINUX SERVER ================
                        {
                            // install Server X
                            if (isFirstStartup)
                            {
                                if (Platform == PlatformCategory.ClearLinux)
                                {
                                    InstallPackage("x11-server");
                                    InstallPackage("x11-tools"); // add xset & xdpyinfo commands (used do disallow screensaver & set screen resolution)
                                }
                                else
                                {
                                    InstallPackage("xinit"); // start manually xserver https://wiki.debian.org/xinit
                                    InstallPackage("x11-xserver-utils"); // add xset commands (used do disallow screensaver)
                                    InstallPackage("x11-utils"); // add xdpyinfo commands (set screen resolution)
                                }
                            }

                            // https://sylvaindurand.org/launch-chromium-in-kiosk-mode/

                            // start xserver on startup 
                            var home = FirstHome();
                            var executeOnstartupFile = home + "/.bash_profile";
                            if (!File.Exists(executeOnstartupFile))
                            {
                                File.WriteAllText(executeOnstartupFile, "startx");
                            }
                            // launch browser on startx running
                            var autoDetectResolution = "# Auto-detect resolution and store in variables\n" +
                                                       "res=$(xdpyinfo -d :0 | grep dimensions | sed -r 's/^[^0-9]*([0-9]+x[0-9]+).*$/\\1/')\n" +
                                                       "resx=$(echo $res | awk '{split($0,array,\"x\")} END{print array[1]}')\n" +
                                                       "resy=$(echo $res | awk '{split($0,array,\"x\")} END{print array[2]}')\n";


                            var echoOff = "set +x;\n";


                            var hp = new UriBuilder(homePage);
                            var waitServiceStart = "while ! nc -z " + hp.Host + " " + hp.Port + "; do\n" +
                                                   " sleep 1s\n" +
                                                   "done\n";
                            var loop = true;
                            if (loop)
                                runBrowser = "while true; do\n" +
                                              runBrowser + "\n" +
                                             "sleep 1s\n" +
                                             "done\n";

                            var onStartxScript = echoOff + autoDetectResolution + waitServiceStart + "\n" + runBrowser + "\n";
                            // new FileInfo(X11OnStartFileEvent).Directory.Create();
                            File.WriteAllText(X11OnStartFileEvent, onStartxScript);
                        }
                    }
                    else
                    {
                        if (value)
                            throw new Exception("OS Platform not supported!");
                    }

                    // kiosk mode configuration: https://gist.github.com/hrr/1a8d769255fdedc7f0b6a18e7fab2e2a 

                    DisallowScreensaver(value);
                    DisallowSpecialKeys(value);
                    DisallowUnnecessaryServices();
                    AutoLogin = value;
                    File.WriteAllText(GetFile(nameof(KioskMode)), value.ToString());
                }
            }
        }

        private static string StartupPage
        {
            get
            {
                {
                    var ASPNETCORE_URLS = Environment.GetEnvironmentVariable("ASPNETCORE_URLS") ?? "http://localhost:5000";
                    if (string.IsNullOrEmpty(ASPNETCORE_URLS))
                        throw new Exception("The environment variable ASPNETCORE_URLS has not been set!");
                    var urls = ASPNETCORE_URLS.Split(';').ToList();
                    var url = urls.FirstOrDefault(x => x.StartsWith("http:"));
                    if (url != null)
                    {
                        var ub = new UriBuilder(url);
                        ub.Host = "localhost";
                        url = ub.Uri.AbsoluteUri;
                    }
                    return url;
                }
            }
        }

        private static void DisallowUnnecessaryServices()
        {
            if (Platform == PlatformCategory.ClearLinux)
            {
                ExecuteCommand("systemctl disable swupd-overdue.service");
                ExecuteCommand("systemctl disable swupd-update.timer");
            }
            else if (Platform == PlatformCategory.Debian)
            {
                ExecuteCommand("systemctl disable apt-daily.timer");
                ExecuteCommand("systemctl stop NetworkManager-wait-online.service");
                ExecuteCommand("systemctl mask NetworkManager-wait-online.service");
                ExecuteCommand("systemctl stop --now snapd.seeded");
                ExecuteCommand("systemctl mask --now snapd.seeded");
            }
        }

        /// <summary>
        /// Turn screensaver off permanently (on/off)
        /// </summary>
        /// <param name="status">on/off (status true = on)</param>
        public static void DisallowScreensaver(bool status = true)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                var onStartxScript = "xset -dpms\n" +
                                     "xset s off\n" +
                                     "xset s noblank\n";
                if (status)
                    AddScripts(X11OnStartFileEvent, onStartxScript, false);
                else
                    RemoveScripts(X11OnStartFileEvent, onStartxScript);
            }
        }

        /// <summary>
        /// Add custom settings to the browser, intended to run in kiosk mode
        /// </summary>
        public static void BrowserSetForKioskMode(string homePage)
        {
            if (Platform == PlatformCategory.ClearLinux && CurrentBrowser == Browser.Firefox)
            {

                var autoconfig = new FileInfo(Path.Combine(FirstHome(), ".firefox/defaults/pref/autoconfig.js"));

                // Disallow hardware acceleration (FIX white page rendering)
                // https://support.mozilla.org/en-US/kb/customizing-firefox-using-autoconfig
                // config settings: https://searchfox.org/mozilla-release/source/modules/libpref/init/all.js
                var disabledAcceleration = @"pref(""layers.acceleration.disabled"", true);";

                var browserSettings = @"pref(""toolkit.telemetry.infoURL"", """");" + "\n"
                + @"pref(""toolkit.telemetry.cachedClientID"", """");" + "\n"
                + @"pref(""toolkit.telemetry.server"", """");" + "\n"
                + @"pref(""browser.search.update"", false);" + "\n"
                + @"pref(""browser.aboutwelcome.enabled"", false);" + "\n"
                + @"pref(""trailhead.firstrun.didSeeAboutWelcome"", true);" + "\n"
                + @"pref(""startup.homepage_welcome_url"", """");" + "\n"
                + @"pref(""extensions.pocket.enabled"", false);" + "\n"
                + @"pref(""browser.startup.homepage"", """ + homePage + @""");" + "\n"
                + @"pref(""browser.tabs.firefox-view"", false);" + "\n";

                AddScripts(autoconfig.FullName, "// Disabled hardware accelleration (is not supported)\n" + browserSettings + disabledAcceleration);
                ExecuteCommand("chmod", "777 " + autoconfig.FullName);
                ExecuteCommand("chmod", "777 " + autoconfig.Directory.FullName);
                ExecuteCommand("chmod", "777 " + autoconfig.Directory.Parent.FullName);
                ExecuteCommand("chmod", "777 " + autoconfig.Directory.Parent.Parent.FullName);
            }
        }

        /// <summary>
        /// Disables key combinations that allow you to exit kiosk mode or interact with the browser for unauthorized purposes
        /// </summary>
        /// <param name="status"></param>
        public static void DisallowSpecialKeys(bool status = true)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                if (status && Platform == PlatformCategory.ClearLinux)
                {
                    InstallPackage("x11-tools"); // install also "keycode" command
                }
                var onStartxScript = "numlockx on\n" +
                                        "#Lock out right-click and menu button on keyboard\n" +
                                        "xmodmap -e \"pointer = 1 2 32 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31\"\n" +
                                        "xmodmap -e \"keycode 135 =\"\n" +
                                        "#Lock out other special keys\n" +
                                        "xmodmap -e \"keycode 64 =\"       #L-alt\n" +
                                        "xmodmap -e \"keycode 108 =\"      #R-alt\n" +
                                        "xmodmap -e \"keycode 37 =\"       #L-ctrl\n" +
                                        "xmodmap -e \"keycode 105 =\"      #R-ctrl\n" +
                                        "xmodmap -e \"keycode 133 =\"      #L-windows (meta key)\n" +
                                        "xmodmap -e \"keycode 134 =\"      #R-windows (meta key)\n" +
                                        "xmodmap -e \"keycode 107 =\"      #print-screen\n" +
                                        "xmodmap -e \"keycode 127 =\"      #page-break\n" +
                                        "xmodmap -e \"keycode 77 =\"       #num-lock\n" +
                                        "xmodmap -e \"keycode 78 =\"       #scroll-lock\n" +
                                        "xmodmap -e \"keycode 118 =\"      #insert\n" +
                                        "xmodmap -e \"keycode 9 =\"        #esc\n" +

                                        "xmodmap -e \"keycode 217 =\"      #Search\n" +
                                        "xmodmap -e \"keycode 158 =\"      #Back\n" +
                                        "xmodmap -e \"keycode 159 =\"      #Forward\n" +
                                        "xmodmap -e \"keycode 144 =\"      #MyComputer\n" +
                                        "xmodmap -e \"keycode 172 =\"      #BrowserHome\n" +
                                        "xmodmap -e \"keycode 156 =\"      #Favorities\n" +
                                        "xmodmap -e \"keycode 99 =\"       #print-screen\n" +
                                        "xmodmap -e \"keycode 70 =\"       #scrool-lock\n" +
                                        "xmodmap -e \"keycode 119 =\"      #pause\n" +

                                        "xmodmap -e \"keycode 59 =\"       #F1\n" +
                                        "xmodmap -e \"keycode 60 =\"       #F2\n" +
                                        "xmodmap -e \"keycode 61 =\"       #F3\n" +
                                        "xmodmap -e \"keycode 62 =\"       #F4\n" +
                                        "xmodmap -e \"keycode 63 =\"       #F5\n" +
                                        "xmodmap -e \"keycode 64 =\"       #F6\n" +
                                        "xmodmap -e \"keycode 65 =\"       #F7\n" +
                                        "xmodmap -e \"keycode 66 =\"       #F8\n" +
                                        "xmodmap -e \"keycode 67 =\"       #F9\n" +
                                        "xmodmap -e \"keycode 68 =\"       #F10\n" +
                                        "xmodmap -e \"keycode 87 =\"       #F11\n" +
                                        "xmodmap -e \"keycode 88 =\"       #F12\n" +


                                        "xmodmap -e \"keycode 67 =\"       #F1\n" +
                                        "xmodmap -e \"keycode 68 =\"       #F2\n" +
                                        "xmodmap -e \"keycode 69 =\"       #F3\n" +
                                        "xmodmap -e \"keycode 70 =\"       #F4\n" +
                                        "xmodmap -e \"keycode 71 =\"       #F5\n" +
                                        "xmodmap -e \"keycode 72 =\"       #F6\n" +
                                        "xmodmap -e \"keycode 73 =\"       #F7\n" +
                                        "xmodmap -e \"keycode 74 =\"       #F8\n" +
                                        "xmodmap -e \"keycode 75 =\"       #F9\n" +
                                        "xmodmap -e \"keycode 76 =\"       #F10\n" +
                                        "xmodmap -e \"keycode 95 =\"       #F11\n" +
                                        "xmodmap -e \"keycode 96 =\"       #F12\n";


                if (status)
                    AddScripts(X11OnStartFileEvent, onStartxScript, false);
                else
                    RemoveScripts(X11OnStartFileEvent, onStartxScript);
            }
        }

        private static FileInfo AutoLoginFile = new FileInfo("/etc/systemd/system/getty@tty1.service.d/override.conf");

        /// <summary>
        /// Set up automatic login in the operating system
        /// </summary>
        public static bool AutoLogin
        {
            get { return AutoLoginFile.Exists; }
            set
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                {

                    if (value)
                    {
                        AutoLoginFile.Directory.Create();
                        if (!AutoLoginFile.Exists)
                        {
                            File.WriteAllText(AutoLoginFile.FullName, @"[Service]
ExecStart=
ExecStart=-/sbin/agetty --noissue --autologin " + FirstUsername() + @" %I $TERM
Type=idle");
                        }
                    }
                    else
                    {
                        if (AutoLoginFile.Exists)
                        {
                            AutoLoginFile.Delete();
                        }
                    }
                }
            }
        }


        /// <summary>
        /// Add current application in boot menu 
        /// </summary>
        /// <param name="automaticEntry"></param>
        /// <exception cref="Exception"></exception>
        private static void SetStartupSessionForCurrentUser(bool automaticEntry)
        {
            // Set startup session for current user 
            var userPath = new DirectoryInfo(SystemEnvironment.AccountServicesUsers);
            if (!userPath.Exists)
                throw new Exception("Path '" + userPath.FullName + "' directory does not exist");
            var userFileName = Path.Combine(userPath.FullName, Environment.UserName);
            if (!File.Exists(userFileName))
            {
                var findUserFileName = userPath.GetFiles().FirstOrDefault();
                if (findUserFileName != null)
                    userFileName = findUserFileName.FullName;
                else
                {
                    var config = @"
[User]
Session=
Icon=
SystemAccount=false

[InputSource0]
xkb=gb+intl
";
                    File.WriteAllText(userFileName, config);
                }
            }
            var doc = File.ReadAllLines(userFileName);
            var key = "Session=";
            for (var i = 0; i < doc.Length; i++)
            {
                var docLine = doc[i];
                if (docLine.StartsWith(key))
                {
                    var saveFileName = GetFile("DefaultDesktopEnvironment");
                    var currentDesktopEnvironment = docLine.Substring(key.Length).Trim();
                    if (currentDesktopEnvironment != CurrentAppName)
                    {
                        File.WriteAllText(saveFileName, currentDesktopEnvironment);
                    }
                    if (automaticEntry)
                    {
                        doc[i] = key + CurrentAppName;
                    }
                    else
                    {
                        var defaultDesktopEnvironment = File.Exists(saveFileName) ? File.ReadAllText(saveFileName) : null;
                        if (defaultDesktopEnvironment != null)
                        {
                            if (defaultDesktopEnvironment == "")
                            {
                                File.Delete(userFileName);
                                return;
                            }
                            doc[i] = key + defaultDesktopEnvironment;
                        }
                    }
                    break;
                }
            }
            File.WriteAllLines(userFileName, doc);
        }

        private static string FirstUsername() => new DirectoryInfo("/home").GetDirectories().FirstOrDefault().Name;
        private static string FirstHome() => Directory.GetDirectories("/home").FirstOrDefault();

        /// <summary>
        /// Script file that runs when the X11 graphics manager starts
        /// </summary>
        private static string X11OnStartFileEvent
        {
            get
            {
                // return SystemEnvironment.X11Enviroment + "xinit/xinitrc";
                return FirstHome() + "/.xinitrc";
            }
        }

        internal static class SystemEnvironment
        {
            public const string AccountServicesUsers = "/var/lib/AccountsService/users";
            public const string DesktopEnvironment = "/usr/share/xsessions/";
            public const string X11Environment = "/etc/X11/";

        }
    }

}
