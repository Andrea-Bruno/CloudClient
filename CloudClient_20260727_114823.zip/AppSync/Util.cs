﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml.Serialization;

namespace AppSync
{
    /// <summary>
    /// Class that disables all the specific functions useful to support cloud data synchronization
    /// </summary>
    public static class Util
    {
        /// <summary>
        /// Compute a hash for the file, without loading it into memory
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        internal static ulong HashFile(FileInfo file)
        {
            var result = (ulong)file.Length;
            if (file.Exists)
            {
                using var fs = new FileStream(file.FullName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                var bits = new byte[8];
                while (fs.Read(bits, 0, 8) != 0)
                {
                    result ^= BitConverter.ToUInt64(bits, 0);
                }
            }
            return result;
        }

        /// <summary>
        /// Get the cml structure of the specified directory
        /// </summary>
        /// <param name="dir">The root of the structure</param>
        /// <param name="copyTo">If specified, it indicates that the structure must be copied to a destination directory where the repository for the installation is located</param>
        /// <param name="excludeJsonFile">Is true exclude Json File</param>
        /// <param name="fileList">Internal parameter</param>
        /// <param name="baseDir">Internal parameter</param>
        /// <returns></returns>
        internal static string CreateFileStructure(DirectoryInfo dir, DirectoryInfo copyTo = null, bool excludeJsonFile = true, List<HashFileInfo> fileList = null, DirectoryInfo baseDir = null)
        {
            baseDir = baseDir ?? dir;

            var isFirst = fileList == null;
            if (isFirst)
            {
                fileList = new List<HashFileInfo>();
            }
            foreach (var item in dir.GetFileSystemInfos())
            {
                if (item is FileInfo file)
                {
                    if (!file.Attributes.HasFlag(FileAttributes.Hidden) && !file.Name.StartsWith("_"))
                        if (file.Name != structureFileName)
                            if (!excludeJsonFile || !item.Name.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
                            {
                                var hashFile = new HashFileInfo(baseDir, file);
                                fileList.Add(hashFile);
                                if (copyTo != null)
                                {
                                    var targetFullName = Path.Combine(copyTo.FullName, hashFile.RelativePath);
                                    var targetPath = new FileInfo(targetFullName).Directory;
                                    if (!targetPath.Exists)
                                        Directory.CreateDirectory(targetPath.FullName);
                                    file.CopyTo(targetFullName, true);
                                }
                            }
                }
                else if (item is DirectoryInfo subDir)
                {
                    var hashFile = new HashFileInfo(baseDir, subDir);
                    fileList.Add(hashFile);
                    CreateFileStructure(subDir, copyTo, excludeJsonFile, fileList, baseDir);
                }
            }
            if (isFirst)
            {
                var xmlStructure = Serialize(fileList);
                if (copyTo == null)
                    copyTo = dir;
                File.WriteAllText(Path.Combine(copyTo.FullName, structureFileName), xmlStructure);
                return xmlStructure;
            }
            return null;
        }
        internal const string structureFileName = "structure.xml";

        internal static string Serialize(List<HashFileInfo> fileList)
        {
            var memoryStream = new MemoryStream();
            var x = new XmlSerializer(typeof(HashFileInfo[]));
            x.Serialize(memoryStream, fileList.ToArray());
            var xml = Encoding.UTF8.GetString(memoryStream.ToArray());
            return xml.Trim('\uFEFF', '\u200B'); // remove BOM char 
        }
        internal static List<HashFileInfo> Deserialize(string xml)
        {
            HashFileInfo[] array;
            using (TextReader reader = new StringReader(xml))
            {
                var serializer = new XmlSerializer(typeof(HashFileInfo[]));
                array = (HashFileInfo[])serializer.Deserialize(reader);
            }
            return new List<HashFileInfo>(array);
        }

        internal static string NameToText(string name)
        {
            int n = 0;
            var text = "";
            foreach (var c in name)
            {
                if (char.IsUpper(c) && n != 0)
                {
                    text += ' ';
                    text += c.ToString().ToLower();
                }
                else
                    text += c;
                n++;
            }
            return text;
        }

        /// <summary>
        /// An identifier of the structure of a path, useful to see if there has been a change to a file
        /// </summary>
        /// <param name="files"></param>
        /// <returns></returns>
        internal static ulong HashStructure(List<HashFileInfo> files)
        {
            ulong hash = 0;
            foreach (var file in files)
            {
                if (file.Hash != null)
                    hash ^= (ulong)file.Hash;
                else
                    hash ^= HashDirectoryName(file.RelativePath);
            }
            return hash;
        }

        private static ulong HashDirectoryName(string relativeName)
        {
            var bytes = Encoding.Unicode.GetBytes(relativeName);
            return FastHash(0u, bytes);
        }

        internal static ulong FastHash(ulong startValue, byte[] bytes)
        {
            var bl = (ulong)bytes.Length;
            Array.Resize(ref bytes, (int)Math.Ceiling(bytes.Length / 8d) * 8);
            startValue += bl;
            for (var i = 0; i < bytes.Length; i += 8)
            {
                var v = BitConverter.ToUInt64(bytes, i);
                startValue += v; // prevents zero value of startValue
                startValue *= (v + (ulong)i);
            }
            return startValue;
        }

        //internal class ZipNameFileEncoding : UTF8Encoding
        //{
        //    public ZipNameFileEncoding()
        //    {

        //    }
        //    public override byte[] GetBytes(string s)
        //    {
        //        s = s.Replace("\\", "/");
        //        return base.GetBytes(s);
        //    }
        //}

        /// <summary>
        /// Create a compressed archive file
        /// </summary>
        /// <param name="sourcePath"></param>
        /// <param name="zipFullNameFile"></param>
        internal static void Zip(string sourcePath, string zipFullNameFile)
        {
            //ZipFile.CreateFromDirectory(sourcePath, zipFullNameFile, CompressionLevel.Optimal, false, new ZipNameFileEncoding());
            ZipFile.CreateFromDirectory(sourcePath, zipFullNameFile, CompressionLevel.Optimal, false);
        }


        /// <summary>
        /// Unpack a compressed archive file
        /// </summary>
        /// <param name="zipFullNameFile"></param>
        /// <param name="targetPath"></param>
        internal static void Unzip(string zipFullNameFile, string targetPath)
        {
            var tmp = GetTempName();
            Directory.CreateDirectory(tmp);
            ZipFile.ExtractToDirectory(zipFullNameFile, targetPath);
            CopyFilesRecursively(new DirectoryInfo(tmp), new DirectoryInfo(targetPath), false, true);
        }

        /// <summary>
        /// Copy the files to another directory (and rename any existing files if specified)
        /// If set to rename existing files, it can overwrite files that are already open.
        /// </summary>
        /// <param name="source"></param>
        /// <param name="target"></param>
        /// <param name="renameExistingFiles">If true, rename any existing files</param>
        /// <param name="move">If true, the file will be moved instead of being copied</param>
        internal static void CopyFilesRecursively(DirectoryInfo source, DirectoryInfo target, bool renameExistingFiles = false, bool move = false)
        {
            foreach (var dir in source.GetDirectories())
            {
                var TargetSubDir = target.CreateSubdirectory(dir.Name);
                CopyFilesRecursively(dir, TargetSubDir, renameExistingFiles, move);
            }
            foreach (var file in source.GetFiles())
            {
                var targetFile = new FileInfo(Path.Combine(target.FullName, file.Name));
                if (renameExistingFiles)
                    RenameExistingFiles(targetFile.FullName);
                if (move)
                    file.MoveTo(targetFile.FullName);
                else
                    file.CopyTo(targetFile.FullName, true); //Copy and Overwrite
            }
            if (move)
                Directory.Delete(source.FullName, true);
        }

        /// <summary>
        /// Rename the file if it exists
        /// </summary>
        /// <param name="file">Full file name</param>
        private static void RenameExistingFiles(string file)
        {
            var fileInfo = new FileInfo(file);
            if (fileInfo.Exists)
            {
                var newName = new FileInfo(Path.Combine(fileInfo.Directory.FullName, "_" + fileInfo.Name));
                if (newName.Exists)
                    newName.Delete();
                fileInfo.MoveTo(newName.FullName);
            }
        }

        internal static string GetTempName()
        {
            var bytes = new byte[16];
            new Random().NextBytes(bytes);
            return Path.Combine(Path.GetTempPath(), BitConverter.ToString(bytes).Replace("-", ""));
        }

        /// <summary>
        /// Restart current application
        /// </summary>
        public static void Restart()
        {
            bool isAServices; // If it is a service application, the app will simply be closed (the system will take care of restarting it according to the pre-established rules)</param>
            // isAServices = !Environment.UserInteractive; // https://stackoverflow.com/questions/36285125/checking-if-an-application-is-running-using-windows-service
            isAServices = RuntimeInformation.IsOSPlatform(OSPlatform.Linux) || RuntimeInformation.IsOSPlatform(OSPlatform.OSX);
         
            if (isAServices) // The services restart automatically, so there is no need to restart.
            {
                Environment.Exit(0);
                return;
            }
            var executable = GetExecutableFile();
            var run = executable.EndsWith(".dll") ? "dotnet " + executable : executable;
            Process.Start(run);
        }

        /// <summary>
        /// Returns the executable file of the current application
        /// </summary>
        /// <returns></returns>
        internal static string GetExecutableFile()
        {
            var entry = new FileInfo(Assembly.GetEntryAssembly().Location);
            var exe = new FileInfo(Path.ChangeExtension(entry.FullName, "exe"));
            if (exe.Exists)
                return exe.FullName;
            var unix = new FileInfo(Path.GetFileNameWithoutExtension(entry.FullName));
            if (unix.Exists)
                return unix.FullName;
            return entry.FullName;
        }

        /// <summary>
        /// Send a file to the remote host
        /// </summary>
        /// <param name="filename">File to be sent</param>
        /// <param name="toUrl">Target Url</param>
        /// <returns></returns>
        internal static HttpStatusCode UploadOld(string filename, string toUrl)
        {
            var request = WebRequest.Create(toUrl);
            request.Timeout = 1000 * 60 * 10; // ms
            request.Method = "POST";
            var byteArray = File.ReadAllBytes(filename);
            request.ContentType = "application/octet-stream";
            request.ContentLength = byteArray.Length;
            request.Headers.Add("Content-Disposition", "filename*=UTF-8''data.zip");
            var dataStream = request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            //dataStream.Flush();
            //dataStream.Close();
            var response = request.GetResponse();
            var status = ((HttpWebResponse)response).StatusCode;
            response.Close();
            response.Dispose();
            return status;
        }

        internal static void Upload(string filename, string toUrl)
        {
            var chunkSize = 20000000;
            var fileInfo = new FileInfo(filename);
            var parts = (int)Math.Ceiling(fileInfo.Length / (double)chunkSize);
            var data = File.ReadAllBytes(filename);
            var ub = new UriBuilder(toUrl);
            var ip = Dns.GetHostEntry(ub.Uri.Host);
            ub.Host = ip.AddressList[0].ToString();
            var query = ub.Query;
            for (var chunk = 1; chunk <= parts; chunk++)
            {
                ub.Query = query + "&p=" + parts + "&c=" + chunk; // parts & current part
                var fileOffset = (chunk - 1) * chunkSize;
                var end = fileOffset + chunkSize;
                if (end > fileInfo.Length)
                    end = (int)fileInfo.Length;
                var size = end - fileOffset;
                //var dataPart = data.Skip(fileOffset).Take(size).ToArray();
                WebRequest wReq;
                WebResponse wResp;
                wReq = WebRequest.Create(ub.Uri);
                wReq.Method = "POST";
                wReq.ContentType = "application/octet-stream";

                //byte[] byteArray = File.ReadAllBytes(filename);
                //wReq.ContentLength = byteArray.Length;

                wReq.ContentLength = size;
                using (var dataStream = wReq.GetRequestStream())
                {

                    dataStream.Write(data, fileOffset, size);
                }

                //var dataStream = wReq.GetRequestStream();
                //dataStream.Write(byteArray, 0, byteArray.Length);
                //dataStream.Close();
                try
                {
                    wResp = wReq.GetResponse();
                }
                catch (Exception ex)
                {
                    ub.Query = null;
                    ub.Path = null;
                    if (ex.HResult == -2147467259)
                    {
                        throw new Exception("The publishing store is offline at " + ub.Uri);
                    }

                    if (ex.HResult == -2146233079)
                    {
                        throw ex;
                    }
                    if (ex.HResult == -2146232800)
                    {
                        throw new Exception("No server at destination address and port " + ub.Uri + " (" + ex.Message + ")");
                    }

                    throw ex;
                }
                var dataRespStream = wResp.GetResponseStream();
                string response = null;
                if (dataRespStream != null)
                {
                    var streamReader = new StreamReader(dataRespStream);
                    response = streamReader.ReadToEnd();
                }
                dataRespStream.Close();
            }
        }
    }
}