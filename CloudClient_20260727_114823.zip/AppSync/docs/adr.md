# AppSync – Architecture Decision Records

## ADR-001: Hash-Based Delta Updates

**Date**: 2024  
**Status**: Accepted

### Context
Distributing a full application archive on every update wastes bandwidth, especially for large applications where only a few files change between releases.

### Decision
Generate a **file manifest** (list of relative paths + SHA-256 hashes) at publish time. The client compares the remote manifest with its local file hashes and downloads only files whose hash differs.

### Consequences
- **Positive**: minimal download size; only changed files are transferred.
- **Positive**: update is idempotent: interrupted updates can be safely resumed.
- **Negative**: the manifest must be kept in sync with the published artefacts.

---

## ADR-002: Any HTTPS Host as Repository

**Date**: 2024  
**Status**: Accepted

### Context
Requiring a dedicated update server would create an operational dependency and hosting cost.

### Decision
The `WebRepository` class only requires an HTTPS-accessible directory that serves the manifest and binary files as static content. Any host (GitHub Releases, Azure Blob Storage, nginx static server) is compatible.

### Consequences
- **Positive**: no proprietary update server; zero hosting cost with a CDN.
- **Positive**: the update files can be inspected in a browser.
- **Negative**: no server-side logic (e.g., staged rollouts) without a custom host.

---

## ADR-003: Self-Update via Restart

**Date**: 2024  
**Status**: Accepted

### Context
On Windows and Linux, a running executable cannot replace itself in memory. The update must be applied while the application is not running.

### Decision
Downloaded files are staged in a temporary directory. `RestartApplication()` launches a helper that waits for the main process to exit, copies the staged files over the installation directory, then relaunches the application.

### Consequences
- **Positive**: reliable update even on Windows (no file-in-use errors).
- **Negative**: the update is not applied until the application restarts.
