# AppSync – System Overview

## Purpose

**AppSync** is a lightweight library that provides **automatic application update** functionality for .NET applications. It handles both sides of the update lifecycle:

- **Publishing side**: prepare and publish a new release to a web-accessible repository.
- **Client side**: detect available updates and apply them (automatically or on demand).

## Architecture

```
Release Server (web host)
	│
	├── WebRepository  (serves file manifest + binaries)
	└── HashFileInfo   (per-file hash + version metadata)

Client Application
	│
	├── Prepare.cs     (build & publish a new release)
	├── Update.cs      (check for updates, download, apply)
	└── Util.cs        (helpers)
```

## Update Flow

1. Developer calls `Prepare` to generate a file manifest (list of file hashes) and uploads artefacts to the web repository.
2. The running application periodically calls `Update.Check(repositoryUrl)`.
3. If a newer manifest is detected, `Update.Apply()` downloads only the changed files and restarts the application.

## Key Properties

- **Delta updates**: only modified files are downloaded (hash comparison).
- **Self-updating**: the library can replace the running executable on the next restart.
- **No central update server required**: any HTTPS-accessible file host works (GitHub Releases, Azure Blob, nginx, etc.).
- **Cross-platform**: works on Windows, Linux, and macOS.

## Target Framework

**.NET Standard 2.1**
