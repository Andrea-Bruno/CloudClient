# AppSync – Security Policy

## Purpose

AppSync downloads and applies application updates from a remote web repository. This makes it a security-sensitive component: a compromised update could execute arbitrary code on the host.

## Update Integrity

- Each file in the update package is identified by a **hash** (`HashFileInfo.cs`). The downloader (`WebRepository.cs`) verifies that each downloaded file matches its expected hash before applying it.
- Tampered or corrupted files are rejected and the update is aborted.

## Update Source Trust

The update repository URL is configured at application startup. Ensure:

- The URL uses **HTTPS** with a valid certificate.
- The repository is hosted on a server you control.
- Only authorised personnel can publish new releases to the repository.

A future improvement would add digital signatures over the update manifest, so the client can verify the publisher identity in addition to file hashes.

## Privilege Considerations

AppSync replaces files in the application directory, which may require elevated privileges on some operating systems. Run AppSync in a context with the minimum privileges needed — ideally limited to the application directory.

## Update Window

Updates are applied only during a maintenance window or at application restart to avoid replacing in-use files. Never apply updates while the application is serving requests, unless a graceful restart mechanism is in place.

## Reporting Vulnerabilities

Open a private GitHub Security Advisory in the repository. Do not disclose vulnerabilities publicly before a fix is available.
