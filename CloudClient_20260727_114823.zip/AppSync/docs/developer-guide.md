# AppSync – Developer Guide

## Installation

```bash
dotnet add package AppSync
```

## Publishing a New Release

```csharp
using AppSync;

// After building your project, prepare the release manifest
Prepare.PublishRelease(
	sourceDirectory: @"publish\",          // dotnet publish output
	repositoryUrl:   "https://my-server.example.com/myapp/",
	localUploadPath: @"C:\wwwroot\myapp\"  // where to write the manifest + files
);
```

`Prepare` hashes every file in `sourceDirectory`, writes a `manifest.json`, and copies artefacts to `localUploadPath`. Upload `localUploadPath` to your web host.

## Checking and Applying Updates (Client)

```csharp
using AppSync;

// Check for updates (non-blocking)
bool updateAvailable = await Update.CheckAsync("https://my-server.example.com/myapp/");

if (updateAvailable)
{
	// Download and stage the update
	await Update.ApplyAsync("https://my-server.example.com/myapp/");

	// Restart the application to complete the update
	Update.RestartApplication();
}
```

## Automatic Background Checking

```csharp
// Call at application startup
Update.StartAutoCheck(
	repositoryUrl: "https://my-server.example.com/myapp/",
	interval: TimeSpan.FromHours(1),
	onUpdateAvailable: () => { /* notify user */ }
);
```

## HashFileInfo

`HashFileInfo` carries metadata for a single file in the manifest:

| Property | Type | Description |
|---|---|---|
| `RelativePath` | `string` | File path relative to the application root |
| `Hash` | `string` | SHA-256 hex hash of the file content |
| `Size` | `long` | File size in bytes |

## WebRepository

`WebRepository` is a helper that wraps HTTP access to the manifest and binary files:

```csharp
var repo = new WebRepository("https://my-server.example.com/myapp/");
var manifest = await repo.GetManifestAsync();
byte[] fileBytes = await repo.DownloadFileAsync("Cloud.exe");
```

## Building

```powershell
dotnet build ..\..\AppSync\AppSync.csproj
```
