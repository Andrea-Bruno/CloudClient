# AppSync – API Reference

## Namespace: `AppSync`

### `Prepare`

Prepares the local application directory for update by computing the current file hash table.

#### `Prepare.GetCurrentHashTable(string appDirectory) → List<HashFileInfo>`
Returns a list of `HashFileInfo` records describing each file in the application directory.

---

### `Update`

Downloads and applies available updates from the remote web repository.

#### `Update.CheckAndApply(string repositoryUrl, string appDirectory, bool restartAfterUpdate = true) → UpdateResult`
Checks the remote repository for a newer version. If found, downloads changed files and applies the update.

| Parameter | Type | Description |
|---|---|---|
| `repositoryUrl` | `string` | HTTPS URL of the update repository |
| `appDirectory` | `string` | Local application directory path |
| `restartAfterUpdate` | `bool` | Restart the process after applying the update |

**Returns:** `UpdateResult` with fields:
- `Updated` (`bool`) – whether an update was applied
- `Version` (`string`) – the new version string (if updated)
- `Error` (`string`) – error message (if failed)

---

### `WebRepository`

Low-level HTTP access to the update repository.

#### `WebRepository.GetManifest(string repositoryUrl) → List<HashFileInfo>`
Downloads the remote file manifest (hash table) from the repository.

#### `WebRepository.DownloadFile(string repositoryUrl, string relativePath, string destinationPath)`
Downloads a single file from the repository to the local destination path, verifying its hash after download.

---

### `HashFileInfo`

Represents a file entry in the hash table.

| Property | Type | Description |
|---|---|---|
| `RelativePath` | `string` | File path relative to the application directory |
| `Hash` | `byte[]` | SHA-256 hash of the file content |
| `Size` | `long` | File size in bytes |

---

### `Util`

#### `Util.GetAppDirectory() → string`
Returns the directory containing the current executable.

#### `Util.RestartApplication()`
Restarts the current process.
