﻿# App sync (update the application)
## Library for application synchronization (automatic update).

This library provides both the functions for the app that needs to be updated and for publishing.

This library allows you to have all the necessary functions to create an application repository that is updated with new versions and provides applications with the ability to update themselves (receive automatic or on-demand updates).
