﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace AppSync
{
    /// <summary>
    /// Support for the website to act as a repository for the app update files
    /// </summary>
    public static class WebRepository
    {

        /// <summary>
        /// The IPs of the machines authorized to upload the application update.
        /// Leave null if no machine is authorized.
        /// </summary>
        public static List<string> IpAllowedToUpload;

        /// <summary>
        /// The root location of the repository: To be set at the start of the web application
        /// </summary>
        public static string WebRootPath { get; set; } = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wwwroot");


        /// <summary>
        /// Used for download files for upgrade, on systems that don't have access to static files in WebRoot
        /// In the web application you need to add the entry point in this way: endpoints.MapGet("/update/{**slug}", async context => await WebRepository.AppUpdate(context));
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static async Task AppUpdate(HttpContext context)
        {            
            var path = context.Request.Path.Value.Trim('/').Replace('/', Path.DirectorySeparatorChar);
            var localPath = Path.Combine(WebRootPath, path);
            var filrInfo = new FileInfo(localPath);
            if (!path.StartsWith("/update/") && File.Exists(localPath))
            {
                context.Response.Headers.Add("Content-Disposition", "attachment;filename=" + filrInfo.Name);
                context.Response.Headers.Add("Content-Length", filrInfo.Length.ToString());
                context.Response.Headers.Add("Content-Transfer-Encoding", "binary");
                context.Response.ContentType = "application/octet-stream";
                using var fs = new FileStream(localPath, FileMode.Open);
                context.Response.Body = fs;
            }
            //else
            //{
            //    context.Response.StatusCode = StatusCodes.Status404NotFound;
            //}
        }

        /// <summary>
        /// Usually assigned to the POST "/upload" method, set the entry point of the web application, to upload the zipped application so that it is made available online for updates
        /// In the web application you need to add the entry point in this way: endpoints.MapPost("/upload", async context => await AppSync.WebRepository.AppUpload(context));
        /// Remember to enable the IPs authorized for upload by inserting them in the IpAllowedToUpload list
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns> 
        public static async Task AppUpload(HttpContext context)
        {

            if (context.Request.Query.TryGetValue("appid", out var appid))
            {
                if (WebRootPath != null)
                {
                    var ip = new List<byte>(context.Connection.RemoteIpAddress.GetAddressBytes());
                    if (IpAllowedToUpload != null && (IpAllowedToUpload.Find(x => { var a = IPAddress.Parse(x).GetAddressBytes(); var i = ip.ToArray(); Array.Reverse(i); Array.Resize(ref i, a.Length); Array.Reverse(i); return Equals(i, a); }) == null))
                    {
                        var pathRepository = Path.Combine(WebRootPath, "update", appid);


                        if (context.Request.ContentLength != null && context.Request.ContentLength > 0)
                        {
                            var chunk = 1;
                            if (context.Request.Query.TryGetValue("c", out var c))
                                chunk = int.Parse(c);
                            var parts = 1;
                            if (context.Request.Query.TryGetValue("p", out var p))
                                parts = int.Parse(p);

                            try
                            {
                                var dataLength = (int)context.Request.ContentLength;
                                var data = new byte[dataLength];
                                var readed = 0;
                                do
                                {
                                    var arRead = context.Request.Body.BeginRead(data, readed, dataLength - readed, null, null);
                                    if (!arRead.AsyncWaitHandle.WaitOne(600000))
                                    {
                                        context.Response.StatusCode = StatusCodes.Status408RequestTimeout;
                                        return;
                                    }
                                    readed += context.Request.Body.EndRead(arRead);
                                } while (readed < dataLength);
                                if (chunk == 1)
                                {
                                    TmpZipFile[appid] = Util.GetTempName();
                                }
                                using (var stream = new FileStream(TmpZipFile[appid], FileMode.Append))
                                {
                                    stream.Write(data, 0, data.Length);
                                }
                                if (chunk == parts)
                                    new Task(() =>
                                    {
                                        if (Directory.Exists(pathRepository))
                                            Directory.Delete(pathRepository, true);
                                        Directory.CreateDirectory(pathRepository);
                                        Util.Unzip(TmpZipFile[appid], pathRepository);
                                        File.Delete(TmpZipFile[appid]);
                                        TmpZipFile.Remove(appid);
                                        Util.CreateFileStructure(new DirectoryInfo(pathRepository));
                                    }).Start();

                            }
                            catch (Exception ex)
                            {
                                if (ex.HResult == -2146232800)
                                    Debugger.Break();    // To fix this bug is cecessary increase body size at startup in program.cs with this code snippet:
                                                         //builder.Services.Configure<HubOptions>(options =>
                                                         //{
                                                         //    options.MaximumReceiveMessageSize = 1024 * 1024 * 1000; // 1Gb 
                                                         //});

                                throw ex;
                            }
                        }
                    }
                    else
                    {
                        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    }
                }
            }
            else
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
            }
            await context.Response.WriteAsync(context.Response.StatusCode.ToString());
        }
        private static readonly Dictionary<string, string> TmpZipFile = new Dictionary<string, string>();
    }
}
