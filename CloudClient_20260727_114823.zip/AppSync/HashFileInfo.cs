﻿using System.IO;

namespace AppSync
{
    /// <summary>
    /// Class that allows you to assign a file identifier Hash and save it via serialization
    /// </summary>
    public class HashFileInfo
    {
        /// <summary>
        /// Empty instance constructor for serialization
        /// </summary>
        public HashFileInfo() { } // empty constructor for serialization
        /// <summary>
        /// Constructor to create an instance
        /// </summary>
        /// <param name="root">Root position</param>
        /// <param name="fileSystemInfo">File info about the file to hashing</param>
        public HashFileInfo(DirectoryInfo root, FileSystemInfo fileSystemInfo)
        {
            if (fileSystemInfo is FileInfo fileInfo)
                Hash = Util.HashFile(fileInfo);
            var rootLength = root.FullName.Length;
            if (!root.FullName.EndsWith(Path.DirectorySeparatorChar.ToString()) && !root.FullName.EndsWith(Path.AltDirectorySeparatorChar.ToString()))
                rootLength++;
            RelativePath = fileSystemInfo.FullName.Substring(rootLength).Replace('\\', '/');
        }
        /// <summary>
        /// 8 bytes File Hash
        /// </summary>
        public ulong? Hash;
        /// <summary>
        /// Full name relative from root
        /// </summary>
        public string RelativePath;
        /// <summary>
        /// TRue if the file is a directory
        /// </summary>
        public bool IsDirectory => Hash == null;
    }
}
