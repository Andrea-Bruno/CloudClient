﻿using System;
using System.IO;

namespace AppSync
{
    /// <summary>
    /// Class to be used on the application development computer to generate and publish an update
    /// </summary>
    public static class Prepare
    {
        /// <summary>
        /// Create an update, in particular all the files of the current installation will be copied and an XML file will be added that specifies the file map with their hash. This XML file can be loaded from the device that needs updates and used to check if there are updates to be made
        /// </summary>
        /// <param name="uploadUrl">If specified, it generates the compressed package and sends it to the web host which makes it available for updates</param>
        /// <param name="copyTo">Get the xml structure of the specified directory (ithe copy will be generated in a temporary folder and then deleted)</param>
        /// <param name="publicationPath">The current file package position. Default value is the current base directory of application</param>
        /// <returns>Returns the description of an error, or null if the operation was successful</returns>
        public static void PublishCurrentApplication(string uploadUrl = null, string copyTo = null, string publicationPath = null)
        {
            uploadUrl += "/upload?appid=" + AppDomain.CurrentDomain.FriendlyName;
            publicationPath = publicationPath ?? AppDomain.CurrentDomain.BaseDirectory;
            if (!Directory.Exists(publicationPath))
                throw new Exception("The path to the publication does not exist");
            if (!PackageIsReady(publicationPath))
                throw new Exception("The publication is not recent enough to be published");
            var useTemp = copyTo == null;
            if (useTemp)
                copyTo = Util.GetTempName();
            var target = (string.IsNullOrEmpty(copyTo)) ? null : new DirectoryInfo(copyTo);
            Util.CreateFileStructure(new DirectoryInfo(publicationPath), target);
            if (uploadUrl != null)
            {
                var zipFile = Util.GetTempName();
                Util.Zip(copyTo, zipFile);
                Util.Upload(zipFile, uploadUrl);
                File.Delete(zipFile);
            }
            if (useTemp)
            {
                Directory.Delete(copyTo, true);
            }
        }

        /// <summary>
        /// Returns true if a new package was recently created.
        /// </summary>
        /// <returns>True if the package for publishing is ready</returns>
        public static bool PackageIsReady(string publicationPath)
        {
            if (Directory.Exists(publicationPath))
            {
                var files = Directory.GetFiles(publicationPath);
                foreach (var file  in files)
                {
                    var fileInfo = new FileInfo(file);
                    if ((DateTime.UtcNow - fileInfo.LastAccessTimeUtc).TotalMinutes < 30) // Check if the last build is recent
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
