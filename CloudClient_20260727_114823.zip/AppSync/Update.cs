﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;

namespace AppSync
{
    /// <summary>
    /// Provides support for an application that wants to self-update via a private repository
    /// </summary>
    public static class Update
    {
        /// <summary>
        /// Start a timer that periodically checks for app updates
        /// </summary>
        static public void MonitoringUpdates(string url, Func<bool> isReadyForReboot)
        {
            if (Debugger.IsAttached)
                return;
            StopMonitoringUpdates();
            CheckUpdate = new Timer((s) => CheckAndUpdate(url, isReadyForReboot), null, TimeSpan.FromHours(1), TimeSpan.FromHours(25));
        }

        /// <summary>
        /// Stops the timer that periodically checks for updates
        /// </summary>
        static public void StopMonitoringUpdates()
        {
            CheckUpdate?.Change(Timeout.Infinite, Timeout.Infinite);
            CheckUpdate?.Dispose();
            CheckUpdate = null;
        }
        static private Timer CheckUpdate;


        /// <summary>
        /// Check if there is an update available, and if so, run the update, IsReadyForReboot
        /// </summary>
        /// <param name="url">Repository url where to look for the update. The address of the server that acts as a repository for new versions of applications (new versions are published to this address and apps that need to be updated get the new version from here)</param>
        /// <param name="isReadyForReboot">Function that returns true when restart is possible (when application is not working)</param>
        /// <returns>Outcome of the operation</returns>
        public static string CheckAndUpdate(string url, Func<bool> isReadyForReboot)
        {
            lock (CheckForReboot)
            {
                try
                {
                    bool update;
                    var uri = new Uri(url);
                    IPHostEntry ip;
                    try
                    {
                        ip = Dns.GetHostEntry(uri.Host);
                    }
                    catch (Exception)
                    {
                        return "No internet connection";
                    }
                    var builder = new UriBuilder(uri)
                    {
                        Host = ip.AddressList[0].ToString()
                    };
#if DEBUG
                    // builder.Host = IPAddress.Loopback.ToString();
#endif
                    uri = builder.Uri;
                    url = uri.ToString();
                    if (!url.EndsWith("/"))
                        url += "/";
                    url += "update/" + AppDomain.CurrentDomain.FriendlyName + "/";
                    var indexUrl = url + Util.structureFileName;
                    string fileContent;
                    try
                    {
                        fileContent = new WebClient().DownloadString(indexUrl); // if error raise here, then the repository server is offline
                    }
                    catch (Exception)
                    {
                        return "Repository server is offline!";
                    }
                    if (string.IsNullOrEmpty(fileContent))
                    {
                        return "This application is not present on the repository on " + uri.Host;
                    }
                    var remoteFile = Util.Deserialize(fileContent);
                    var appDir = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
                    var localXML = Path.Combine(appDir.FullName, Util.structureFileName);
                    string xml = CreateLocalFileStructure();
                    var localFiles = Util.Deserialize(xml);
                    // Check if there is an update available
                    update = Util.HashStructure(remoteFile) != Util.HashStructure(localFiles);
                    if (update)
                    {
                        var temp = Util.GetTempName();
                        Directory.CreateDirectory(temp);
#if !DEBUG
                    try
                    {
#endif
                        var updated = false;
                        foreach (var file in remoteFile)
                        {
                            // Check if the file has changed
                            if (localFiles.FirstOrDefault(x => file.RelativePath == x.RelativePath && file.Hash == x.Hash) == null)
                            {
                                updated = true;
                                if (file.IsDirectory)
                                    Directory.CreateDirectory(Path.Combine(temp, file.RelativePath).Replace("\\", "/"));
                                else if (!ExcludeFiles.Contains(Path.GetFileName(file.RelativePath).ToLower()))
                                {
                                    using var client = new WebClient();
                                    var downloadUrl = new Uri(new Uri(url), file.RelativePath.Replace("\\", "/"));
                                    var targetName = new FileInfo(Path.Combine(temp, file.RelativePath));
                                    if (!targetName.Directory.Exists)
                                        Directory.CreateDirectory(targetName.Directory.FullName);
                                    client.DownloadFile(downloadUrl, targetName.FullName);
                                    var crc = Util.HashFile(targetName);
                                    if (crc != file.Hash)
                                    {
                                        Directory.Delete(temp, true);
                                        return Util.NameToText(Response.RepositoryCorrupt.ToString());
                                    }
                                }
                            }
                        }
                        if (!updated)
                        {
                            Directory.Delete(temp, true);
                            return Util.NameToText(Response.AlreadyUpdated.ToString());
                        }
#if !DEBUG
                    }
                    catch (Exception ex)
                    {
                        // un case of error, jump here and delete temp file
                        Directory.Delete(temp, true);
                        throw ex;
                    }
#endif
                        // Move the files: This perform also delete of temp directory 
                        Util.CopyFilesRecursively(new DirectoryInfo(temp), appDir, true, true);
                        CreateLocalFileStructure();
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux) || RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                        {
                            // makes the file executable again on Linux and OSX
                            var executable = Util.GetExecutableFile();
                            //Execute: "/usr/bin/chmod u+x \"" + executable + "\"";
                            Process.Start("chmod", "u+x \"" + executable + "\"");
                        }
                    }
                    // It does not restart the application in the development environment
#if !DEBUG
                if (update)
                {
                    if (isReadyForReboot != null)
                    {

                        IsReadyForReboot = isReadyForReboot;
                        CheckForReboot.Change(500, 60000);
                    }
                    return Response.Successfully.ToString();
                }
#endif
                    return Util.NameToText((update ? Response.Successfully : Response.AlreadyUpdated).ToString());
                }
                catch (Exception ex)
                {
                    return "Error: " + ex.Message;
                }
            }
        }

        /// <summary>
        /// Files that will be excluded from the update. For example, the configuration and customization files, which can be changed, will not be updated with those present in the distribution
        /// </summary>
        private static readonly string[] ExcludeFiles = { "appsettings.json" };

        /// <summary>
        /// Create a description file of the current package which is installed on the machine and save it
        /// </summary>
        /// <returns>Structure in XML format</returns>
        internal static string CreateLocalFileStructure()
        {
            return Util.CreateFileStructure(new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory));
        }
        /// <summary>
        /// Function that is called when the system is ready to restart, i.e. during a period of inactivity
        /// </summary>
        private static Func<bool> IsReadyForReboot;
        private static readonly Timer CheckForReboot = new Timer(e =>
        {
            if (IsReadyForReboot?.Invoke() == true)
            {
                Util.Restart();
            }
        }, null, Timeout.Infinite, Timeout.Infinite);

        public enum Response
        {
            Successfully,
            AlreadyUpdated,
            Error,
            RepositoryCorrupt,
        }
    }
}
